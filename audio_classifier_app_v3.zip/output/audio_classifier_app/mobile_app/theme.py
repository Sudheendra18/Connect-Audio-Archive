"""
Theme, design tokens, and shared UI components — Flet 0.85.3.

Visual identity: NEON DEEP SPACE
──────────────────────────────────────────────────────────────────
• Surfaces: Near-black with warm midnight tones (#080C14, #0F1520, #161E2E)
• Primary:  Vivid violet-to-magenta gradient feel (#8B5CF6 → #EC4899)
• Accent:   Electric cyan / neon green for highlights (#22D3EE / #4ADE80)
• Danger:   Vivid coral-red (#F87171)
• All type colors: luminous neon for maximum legibility on dark
──────────────────────────────────────────────────────────────────
"""
import flet as ft

# ── Core palette ────────────────────────────────────────────────

VIOLET        = "#8B5CF6"
VIOLET_LIGHT  = "#A78BFA"
VIOLET_DIM    = "#6D28D9"
MAGENTA       = "#EC4899"
CYAN          = "#22D3EE"
CYAN_DIM      = "#06B6D4"
GREEN         = "#4ADE80"

SPEECH_COLOR  = "#60A5FA"   # sky blue
MUSIC_COLOR   = "#34D399"   # emerald
NOISE_COLOR   = "#FBBF24"   # amber

SURFACE_0     = "#080C14"   # deepest bg — almost pure black with blue tint
SURFACE_1     = "#0F1520"   # card / bottom nav bg
SURFACE_2     = "#161E2E"   # elevated card / input bg
SURFACE_3     = "#1E2A40"   # chip / selected bg

ON_PRIMARY    = "#FFFFFF"
ON_SURFACE    = "#F1F5F9"   # near-white text
ON_SURFACE_2  = "#94A3B8"   # muted / label
DIVIDER       = "#1E2A40"

DANGER        = "#F87171"

# ── Convenience aliases ─────────────────────────────────────────

PRIMARY       = VIOLET
PRIMARY_LIGHT = VIOLET_LIGHT
ACCENT        = CYAN
ACCENT_DIM    = CYAN_DIM

# ── Semantic maps ────────────────────────────────────────────────

TYPE_COLORS = {
    "Speech": SPEECH_COLOR,
    "Music":  MUSIC_COLOR,
    "Noise":  NOISE_COLOR,
}

TYPE_ICONS = {
    "Speech": ft.Icons.RECORD_VOICE_OVER_ROUNDED,
    "Music":  ft.Icons.MUSIC_NOTE_ROUNDED,
    "Noise":  ft.Icons.GRAPHIC_EQ_ROUNDED,
}

NAV_ROUTES = ["/", "/history", "/analytics", "/settings"]

LANGUAGE_PALETTE = [
    "#8B5CF6", "#22D3EE", "#4ADE80", "#FBBF24",
    "#EC4899", "#60A5FA", "#F87171", "#A78BFA",
    "#34D399", "#FB923C", "#38BDF8", "#E879F9",
]


# ── Theme ────────────────────────────────────────────────────────

def make_theme() -> ft.Theme:
    return ft.Theme(
        color_scheme_seed=VIOLET,
        use_material3=True,
    )


# ── Color helpers ────────────────────────────────────────────────

def type_color(audio_type: str | None) -> str:
    return TYPE_COLORS.get(audio_type or "", ON_SURFACE_2)


def type_icon(audio_type: str | None):
    return TYPE_ICONS.get(audio_type or "", ft.Icons.HELP_OUTLINE_ROUNDED)


def hex_with_alpha(hex_color: str, alpha_hex: str) -> str:
    """e.g. hex_with_alpha('#8B5CF6', '22') → '#8B5CF622'"""
    return f"{hex_color}{alpha_hex}"


# ── Navigation bar ───────────────────────────────────────────────

def build_nav_bar(page: ft.Page, selected_index: int) -> ft.NavigationBar:
    def on_change(e: ft.ControlEvent):
        page.go(NAV_ROUTES[e.control.selected_index])

    return ft.NavigationBar(
        selected_index=selected_index,
        bgcolor=SURFACE_1,
        indicator_color=f"{VIOLET}55",
        on_change=on_change,
        destinations=[
            ft.NavigationBarDestination(
                icon=ft.Icons.HOME_OUTLINED,
                selected_icon=ft.Icons.HOME_ROUNDED,
                label="Home",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.HISTORY_ROUNDED,
                label="History",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.INSIGHTS_OUTLINED,
                selected_icon=ft.Icons.INSIGHTS_ROUNDED,
                label="Stats",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.SETTINGS_OUTLINED,
                selected_icon=ft.Icons.SETTINGS_ROUNDED,
                label="Settings",
            ),
        ],
    )


# ── Shared widgets ───────────────────────────────────────────────

def glass_card(
    content: ft.Control,
    padding: int | ft.Padding = 16,
    border_radius: int = 20,
    glow_color: str | None = None,
) -> ft.Container:
    """Premium card with optional neon glow shadow."""
    shadow = None
    if glow_color:
        shadow = ft.BoxShadow(
            spread_radius=0,
            blur_radius=24,
            color=f"{glow_color}44",
            offset=ft.Offset(0, 4),
        )
    return ft.Container(
        content=content,
        padding=padding,
        border_radius=border_radius,
        bgcolor=SURFACE_1,
        border=ft.border.all(1, DIVIDER),
        shadow=shadow,
    )


def neon_divider() -> ft.Container:
    return ft.Container(
        height=1,
        bgcolor=DIVIDER,
    )


def stat_card(title: str, value: str, icon, color: str) -> ft.Container:
    return ft.Container(
        content=ft.Column(
            spacing=8,
            horizontal_alignment=ft.CrossAxisAlignment.START,
            controls=[
                ft.Container(
                    content=ft.Icon(icon, color=color, size=18),
                    width=36,
                    height=36,
                    border_radius=10,
                    bgcolor=f"{color}20",
                    alignment=ft.alignment.center,
                ),
                ft.Text(
                    value,
                    size=24,
                    weight=ft.FontWeight.BOLD,
                    color=ON_SURFACE,
                ),
                ft.Text(
                    title,
                    size=10,
                    color=ON_SURFACE_2,
                    weight=ft.FontWeight.W_500,
                    letter_spacing=0.5,
                ),
            ],
        ),
        padding=ft.padding.all(14),
        border_radius=16,
        bgcolor=SURFACE_1,
        border=ft.border.all(1, DIVIDER),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=16,
            color=f"{color}22",
            offset=ft.Offset(0, 2),
        ),
    )


def section_label(text: str, color: str = ON_SURFACE_2) -> ft.Text:
    return ft.Text(
        text.upper(),
        size=10,
        weight=ft.FontWeight.W_700,
        color=color,
        letter_spacing=1.5,
    )


def accent_button(
    label: str,
    icon,
    on_click,
    expand: bool = False,
    color: str = VIOLET,
) -> ft.Container:
    """Gradient-feel primary action button with neon glow."""
    return ft.Container(
        expand=expand,
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=20,
            color=f"{color}55",
            offset=ft.Offset(0, 4),
        ),
        content=ft.ElevatedButton(
            content=ft.Row(
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=10,
                controls=[
                    ft.Icon(icon, color=ON_PRIMARY, size=18),
                    ft.Text(
                        label,
                        color=ON_PRIMARY,
                        weight=ft.FontWeight.W_700,
                        size=14,
                        letter_spacing=0.3,
                    ),
                ],
            ),
            style=ft.ButtonStyle(
                bgcolor=color,
                shape=ft.RoundedRectangleBorder(radius=14),
                padding=ft.padding.symmetric(horizontal=24, vertical=16),
                elevation=0,
            ),
            on_click=on_click,
            expand=expand,
        ),
    )


def ghost_button(
    label: str,
    icon,
    on_click,
    expand: bool = False,
    color: str = VIOLET_LIGHT,
) -> ft.Container:
    return ft.Container(
        expand=expand,
        content=ft.OutlinedButton(
            content=ft.Row(
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=10,
                controls=[
                    ft.Icon(icon, color=color, size=18),
                    ft.Text(
                        label,
                        color=color,
                        weight=ft.FontWeight.W_600,
                        size=14,
                    ),
                ],
            ),
            style=ft.ButtonStyle(
                side=ft.BorderSide(1.5, f"{color}88"),
                shape=ft.RoundedRectangleBorder(radius=14),
                padding=ft.padding.symmetric(horizontal=24, vertical=16),
            ),
            on_click=on_click,
            expand=expand,
        ),
    )


def type_badge(audio_type: str, large: bool = False) -> ft.Container:
    color = type_color(audio_type)
    size  = 13 if large else 11
    icon_size = 16 if large else 12
    return ft.Container(
        content=ft.Row(
            spacing=6,
            tight=True,
            controls=[
                ft.Icon(type_icon(audio_type), color=color, size=icon_size),
                ft.Text(
                    audio_type,
                    color=color,
                    size=size,
                    weight=ft.FontWeight.W_700,
                ),
            ],
        ),
        padding=ft.padding.symmetric(horizontal=12, vertical=5),
        border_radius=20,
        bgcolor=f"{color}18",
        border=ft.border.all(1, f"{color}44"),
    )


def neon_icon_container(
    icon,
    color: str,
    size: int = 24,
    container_size: int = 48,
    border_radius: int = 14,
) -> ft.Container:
    """Glowing icon box."""
    return ft.Container(
        content=ft.Icon(icon, color=color, size=size),
        width=container_size,
        height=container_size,
        border_radius=border_radius,
        bgcolor=f"{color}18",
        border=ft.border.all(1, f"{color}44"),
        alignment=ft.alignment.center,
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=12,
            color=f"{color}33",
        ),
    )


def app_bar(
    title: str,
    page: ft.Page,
    back_route: str = "/",
    actions: list | None = None,
) -> ft.AppBar:
    """Consistent AppBar with optional back button and actions."""
    return ft.AppBar(
        title=ft.Text(
            title,
            color=ON_SURFACE,
            weight=ft.FontWeight.W_700,
            size=17,
        ),
        bgcolor=SURFACE_1,
        elevation=0,
        leading=ft.IconButton(
            icon=ft.Icons.ARROW_BACK_IOS_NEW_ROUNDED,
            icon_color=ON_SURFACE_2,
            icon_size=20,
            on_click=lambda e: page.go(back_route),
        ),
        actions=actions or [],
        center_title=True,
    )
