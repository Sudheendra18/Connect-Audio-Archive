"""Analytics screen — custom neon bar charts and stats (no flet_charts dependency)."""
import flet as ft
from models import AppState
import theme as th


def _type_bar(label: str, count: int, total: int, color: str, icon) -> ft.Container:
    pct = int((count / total * 100)) if total > 0 else 0

    return ft.Container(
        content=ft.Column(
            spacing=10,
            controls=[
                ft.Row(
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10,
                    controls=[
                        th.neon_icon_container(
                            icon, color, size=14, container_size=30, border_radius=8
                        ),
                        ft.Text(label, size=13, color=th.ON_SURFACE, weight=ft.FontWeight.W_500,
                                expand=True),
                        ft.Text(
                            f"{count}",
                            size=13,
                            color=color,
                            weight=ft.FontWeight.W_700,
                        ),
                        ft.Text(
                            f"{pct}%",
                            size=12,
                            color=th.ON_SURFACE_2,
                            weight=ft.FontWeight.W_500,
                        ),
                    ],
                ),
                ft.Container(
                    height=8,
                    border_radius=4,
                    bgcolor=th.SURFACE_3,
                    clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                    content=ft.Row(
                        spacing=0,
                        controls=[
                            ft.Container(
                                height=8,
                                border_radius=4,
                                bgcolor=color,
                                expand=pct if pct > 0 else 0,
                                shadow=ft.BoxShadow(
                                    spread_radius=0,
                                    blur_radius=6,
                                    color=f"{color}88",
                                ),
                            ),
                            ft.Container(expand=max(100 - pct, 1)),
                        ],
                    ),
                ),
            ],
        ),
        padding=ft.padding.symmetric(vertical=6),
    )


def _lang_row(lang: str, count: int, total: int, color: str) -> ft.Container:
    pct = int((count / total * 100)) if total > 0 else 0
    return ft.Container(
        content=ft.Column(
            spacing=8,
            controls=[
                ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        ft.Row(
                            spacing=8,
                            controls=[
                                ft.Container(
                                    width=10,
                                    height=10,
                                    border_radius=3,
                                    bgcolor=color,
                                    shadow=ft.BoxShadow(
                                        spread_radius=0,
                                        blur_radius=6,
                                        color=f"{color}88",
                                    ),
                                ),
                                ft.Text(lang, size=13, color=th.ON_SURFACE,
                                        weight=ft.FontWeight.W_500),
                            ],
                        ),
                        ft.Row(
                            spacing=6,
                            controls=[
                                ft.Text(str(count), size=13, color=color,
                                        weight=ft.FontWeight.W_700),
                                ft.Text(f"({pct}%)", size=12, color=th.ON_SURFACE_2),
                            ],
                        ),
                    ],
                ),
                ft.Container(
                    height=4,
                    border_radius=2,
                    bgcolor=th.SURFACE_3,
                    clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                    content=ft.Row(
                        spacing=0,
                        controls=[
                            ft.Container(
                                height=4,
                                border_radius=2,
                                bgcolor=color,
                                expand=pct if pct > 0 else 0,
                            ),
                            ft.Container(expand=max(100 - pct, 1)),
                        ],
                    ),
                ),
            ],
        ),
        padding=ft.padding.symmetric(vertical=4),
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    counts    = state.counts()
    total     = len(state.history)
    lang_dist = state.language_distribution()

    # ── Summary stat row ──────────────────────────────────────────
    stats_row = ft.Row(
        spacing=8,
        controls=[
            ft.Expanded(flex=1, content=th.stat_card(
                "Total", str(total), ft.Icons.ANALYTICS_ROUNDED, th.VIOLET_LIGHT)),
            ft.Expanded(flex=1, content=th.stat_card(
                "Speech", str(counts.get("Speech", 0)), ft.Icons.RECORD_VOICE_OVER_ROUNDED, th.SPEECH_COLOR)),
            ft.Expanded(flex=1, content=th.stat_card(
                "Music", str(counts.get("Music", 0)), ft.Icons.MUSIC_NOTE_ROUNDED, th.MUSIC_COLOR)),
            ft.Expanded(flex=1, content=th.stat_card(
                "Noise", str(counts.get("Noise", 0)), ft.Icons.GRAPHIC_EQ_ROUNDED, th.NOISE_COLOR)),
        ],
    )

    # ── Type distribution ─────────────────────────────────────────
    type_section = th.glass_card(
        content=ft.Column(
            spacing=4,
            controls=[
                ft.Row(
                    spacing=10,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        th.neon_icon_container(
                            ft.Icons.PIE_CHART_ROUNDED, th.VIOLET_LIGHT,
                            size=16, container_size=32, border_radius=10
                        ),
                        th.section_label("Type Distribution", th.ON_SURFACE),
                    ],
                ),
                ft.Container(height=4),
                _type_bar("Speech", counts.get("Speech", 0), total, th.SPEECH_COLOR,
                          ft.Icons.RECORD_VOICE_OVER_ROUNDED),
                _type_bar("Music",  counts.get("Music",  0), total, th.MUSIC_COLOR,
                          ft.Icons.MUSIC_NOTE_ROUNDED),
                _type_bar("Noise",  counts.get("Noise",  0), total, th.NOISE_COLOR,
                          ft.Icons.GRAPHIC_EQ_ROUNDED),
            ],
        ),
        padding=ft.padding.all(18),
        glow_color=th.VIOLET,
    )

    # ── Language section ──────────────────────────────────────────
    if lang_dist:
        sorted_langs = sorted(lang_dist.items(), key=lambda kv: -kv[1])
        lang_total   = sum(lang_dist.values())
        lang_rows    = [
            _lang_row(
                lang,
                count,
                lang_total,
                th.LANGUAGE_PALETTE[i % len(th.LANGUAGE_PALETTE)],
            )
            for i, (lang, count) in enumerate(sorted_langs)
        ]

        lang_section = th.glass_card(
            content=ft.Column(
                spacing=4,
                controls=[
                    ft.Row(
                        spacing=10,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[
                            th.neon_icon_container(
                                ft.Icons.LANGUAGE_ROUNDED, th.SPEECH_COLOR,
                                size=16, container_size=32, border_radius=10
                            ),
                            th.section_label("Language Distribution", th.ON_SURFACE),
                        ],
                    ),
                    ft.Container(height=4),
                    *lang_rows,
                ],
            ),
            padding=ft.padding.all(18),
            glow_color=th.SPEECH_COLOR,
        )
    else:
        lang_section = th.glass_card(
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=12,
                controls=[
                    th.neon_icon_container(
                        ft.Icons.LANGUAGE_ROUNDED, th.ON_SURFACE_2,
                        size=24, container_size=52, border_radius=18
                    ),
                    ft.Text(
                        "No language data yet",
                        color=th.ON_SURFACE,
                        size=14,
                        weight=ft.FontWeight.W_600,
                    ),
                    ft.Text(
                        "Language distribution appears once\nspeech files are analyzed.",
                        color=th.ON_SURFACE_2,
                        size=12,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ],
            ),
            padding=ft.padding.symmetric(vertical=32, horizontal=18),
        )

    # ── Avg confidence (if any) ───────────────────────────────────
    records_with_conf = [r for r in state.history if r.confidence is not None]
    if records_with_conf:
        avg_conf = sum(r.confidence for r in records_with_conf) / len(records_with_conf)
        avg_pct  = int(avg_conf * 100)
        conf_section = th.glass_card(
            content=ft.Column(
                spacing=10,
                controls=[
                    ft.Row(
                        spacing=10,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[
                            th.neon_icon_container(
                                ft.Icons.VERIFIED_ROUNDED, th.GREEN,
                                size=16, container_size=32, border_radius=10
                            ),
                            th.section_label("Avg Confidence", th.ON_SURFACE),
                            ft.Container(expand=True),
                            ft.Text(
                                f"{avg_pct}%",
                                size=20,
                                weight=ft.FontWeight.BOLD,
                                color=th.GREEN,
                            ),
                        ],
                    ),
                    ft.Container(
                        height=8,
                        border_radius=4,
                        bgcolor=th.SURFACE_3,
                        content=ft.Row(
                            spacing=0,
                            controls=[
                                ft.Container(
                                    height=8,
                                    border_radius=4,
                                    bgcolor=th.GREEN,
                                    expand=avg_pct if avg_pct > 0 else 0,
                                    shadow=ft.BoxShadow(
                                        spread_radius=0,
                                        blur_radius=8,
                                        color=f"{th.GREEN}66",
                                    ),
                                ),
                                ft.Container(expand=max(100 - avg_pct, 1)),
                            ],
                        ),
                    ),
                ],
            ),
            padding=ft.padding.all(18),
            glow_color=th.GREEN,
        )
    else:
        conf_section = ft.Container()

    return ft.View(
        route="/analytics",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Analytics", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
        ),
        navigation_bar=th.build_nav_bar(page, 2),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.all(16),
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[
                        stats_row,
                        type_section,
                        conf_section,
                        lang_section,
                    ],
                ),
            )
        ],
    )
