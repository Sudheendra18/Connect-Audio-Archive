"""Home screen — neon hero, live stats, quick actions, recent analyses."""
import flet as ft
from models import AppState
import theme as th


def _pulse_orb(color: str, size: int = 80) -> ft.Stack:
    """Layered glow orb for the hero section."""
    return ft.Stack(
        width=size,
        height=size,
        controls=[
            ft.Container(
                width=size,
                height=size,
                border_radius=size // 2,
                bgcolor=f"{color}0A",
            ),
            ft.Container(
                width=size - 16,
                height=size - 16,
                border_radius=(size - 16) // 2,
                bgcolor=f"{color}18",
                margin=ft.margin.all(8),
            ),
            ft.Container(
                width=size - 32,
                height=size - 32,
                border_radius=(size - 32) // 2,
                bgcolor=f"{color}30",
                margin=ft.margin.all(16),
                content=ft.Icon(
                    ft.Icons.GRAPHIC_EQ_ROUNDED,
                    color=color,
                    size=(size - 32) // 2,
                ),
                alignment=ft.alignment.center,
                shadow=ft.BoxShadow(
                    spread_radius=0,
                    blur_radius=20,
                    color=f"{color}55",
                ),
            ),
        ],
    )


def _hero_section(page: ft.Page) -> ft.Container:
    return ft.Container(
        content=ft.Column(
            spacing=0,
            controls=[
                # Top bar
                ft.Container(
                    content=ft.Row(
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[
                            ft.Column(
                                spacing=2,
                                controls=[
                                    ft.Text(
                                        "Audio Classifier",
                                        size=22,
                                        weight=ft.FontWeight.BOLD,
                                        color=th.ON_SURFACE,
                                    ),
                                    ft.Text(
                                        "SVM · Whisper · ML Pipeline",
                                        size=11,
                                        color=th.ON_SURFACE_2,
                                        letter_spacing=0.5,
                                    ),
                                ],
                            ),
                            ft.Container(
                                content=ft.Icon(
                                    ft.Icons.GRAPHIC_EQ_ROUNDED,
                                    color=th.CYAN,
                                    size=26,
                                ),
                                width=48,
                                height=48,
                                border_radius=15,
                                bgcolor=f"{th.CYAN}15",
                                border=ft.border.all(1, f"{th.CYAN}40"),
                                alignment=ft.alignment.center,
                                shadow=ft.BoxShadow(
                                    spread_radius=0,
                                    blur_radius=14,
                                    color=f"{th.CYAN}30",
                                ),
                            ),
                        ],
                    ),
                    padding=ft.padding.symmetric(horizontal=20, vertical=16),
                    bgcolor=th.SURFACE_1,
                    border=ft.border.only(bottom=ft.border.BorderSide(1, th.DIVIDER)),
                ),
            ],
        ),
    )


def _stat_row(counts: dict, total: int) -> ft.Row:
    return ft.Row(
        spacing=8,
        controls=[
            ft.Expanded(
                flex=1,
                content=th.stat_card("Total", str(total), ft.Icons.ANALYTICS_ROUNDED, th.VIOLET_LIGHT),
            ),
            ft.Expanded(
                flex=1,
                content=th.stat_card("Speech", str(counts.get("Speech", 0)), ft.Icons.RECORD_VOICE_OVER_ROUNDED, th.SPEECH_COLOR),
            ),
            ft.Expanded(
                flex=1,
                content=th.stat_card("Music", str(counts.get("Music", 0)), ft.Icons.MUSIC_NOTE_ROUNDED, th.MUSIC_COLOR),
            ),
            ft.Expanded(
                flex=1,
                content=th.stat_card("Noise", str(counts.get("Noise", 0)), ft.Icons.GRAPHIC_EQ_ROUNDED, th.NOISE_COLOR),
            ),
        ],
    )


def _action_card(icon, label: str, subtitle: str, color: str, gradient_end: str, on_click) -> ft.Container:
    return ft.Container(
        expand=True,
        content=ft.Container(
            content=ft.Column(
                spacing=0,
                controls=[
                    ft.Container(
                        content=ft.Icon(icon, color=color, size=30),
                        width=56,
                        height=56,
                        border_radius=18,
                        bgcolor=f"{color}18",
                        border=ft.border.all(1, f"{color}40"),
                        alignment=ft.alignment.center,
                        shadow=ft.BoxShadow(
                            spread_radius=0,
                            blur_radius=16,
                            color=f"{color}30",
                        ),
                    ),
                    ft.Container(height=14),
                    ft.Text(
                        label,
                        color=th.ON_SURFACE,
                        size=15,
                        weight=ft.FontWeight.W_700,
                    ),
                    ft.Container(height=4),
                    ft.Text(
                        subtitle,
                        color=th.ON_SURFACE_2,
                        size=11,
                    ),
                ],
            ),
            padding=ft.padding.all(18),
            border_radius=20,
            bgcolor=th.SURFACE_1,
            border=ft.border.all(1, f"{color}30"),
            on_click=on_click,
            ink=True,
            shadow=ft.BoxShadow(
                spread_radius=0,
                blur_radius=24,
                color=f"{color}15",
                offset=ft.Offset(0, 4),
            ),
        ),
    )


def _recent_tile(r) -> ft.Container:
    color = th.type_color(r.audio_type)
    icon  = th.type_icon(r.audio_type)
    lang_part = f"  ·  {r.language}" if r.language else ""
    conf_part = f"  ·  {r.confidence * 100:.0f}%" if r.confidence is not None else ""

    return ft.Container(
        content=ft.Row(
            spacing=14,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                th.neon_icon_container(icon, color, size=18, container_size=42, border_radius=13),
                ft.Column(
                    spacing=4,
                    expand=True,
                    controls=[
                        ft.Text(
                            r.filename,
                            size=13,
                            weight=ft.FontWeight.W_600,
                            color=th.ON_SURFACE,
                            max_lines=1,
                            overflow=ft.TextOverflow.ELLIPSIS,
                        ),
                        ft.Text(
                            f"{r.audio_type}{lang_part}{conf_part}",
                            size=11,
                            color=th.ON_SURFACE_2,
                        ),
                    ],
                ),
                ft.Text(r.display_time, size=10, color=th.ON_SURFACE_2),
            ],
        ),
        padding=ft.padding.symmetric(horizontal=16, vertical=13),
        border_radius=16,
        bgcolor=th.SURFACE_2,
        border=ft.border.all(1, f"{color}20"),
        margin=ft.margin.only(bottom=8),
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    counts = state.counts()
    total  = len(state.history)

    # Quick actions
    quick_actions = ft.Row(
        spacing=12,
        controls=[
            _action_card(
                ft.Icons.UPLOAD_FILE_ROUNDED,
                "Upload",
                "Pick from storage",
                th.VIOLET_LIGHT,
                th.MAGENTA,
                lambda e: page.go("/upload"),
            ),
            _action_card(
                ft.Icons.MIC_ROUNDED,
                "Record",
                "Use microphone",
                th.CYAN,
                th.GREEN,
                lambda e: page.go("/record"),
            ),
        ],
    )

    # Recent
    recent = state.history[:5]
    if recent:
        recent_tiles = [_recent_tile(r) for r in recent]
        recent_body  = ft.Column(spacing=0, controls=recent_tiles)
    else:
        recent_body = ft.Container(
            padding=ft.padding.symmetric(vertical=32),
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=12,
                controls=[
                    ft.Container(
                        content=ft.Icon(
                            ft.Icons.QUEUE_MUSIC_ROUNDED,
                            size=44,
                            color=th.ON_SURFACE_2,
                        ),
                        width=72,
                        height=72,
                        border_radius=24,
                        bgcolor=f"{th.VIOLET}15",
                        border=ft.border.all(1, f"{th.VIOLET}30"),
                        alignment=ft.alignment.center,
                    ),
                    ft.Text(
                        "No analyses yet",
                        color=th.ON_SURFACE,
                        size=14,
                        weight=ft.FontWeight.W_600,
                    ),
                    ft.Text(
                        "Upload or record your first audio clip\nto get started.",
                        color=th.ON_SURFACE_2,
                        size=12,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ],
            ),
        )

    recent_header = ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
        controls=[
            th.section_label("Recent Analyses"),
            ft.TextButton(
                "See all →",
                style=ft.ButtonStyle(color=th.VIOLET_LIGHT),
                on_click=lambda e: page.go("/history"),
            ) if recent else ft.Container(),
        ],
    )

    scroll_body = ft.Column(
        spacing=20,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            _stat_row(counts, total),
            ft.Container(
                content=ft.Column(
                    spacing=12,
                    controls=[
                        th.section_label("Classify Audio"),
                        quick_actions,
                    ],
                ),
            ),
            ft.Container(
                content=ft.Column(
                    spacing=12,
                    controls=[
                        recent_header,
                        recent_body,
                    ],
                ),
            ),
        ],
    )

    return ft.View(
        route="/",
        bgcolor=th.SURFACE_0,
        padding=0,
        navigation_bar=th.build_nav_bar(page, 0),
        controls=[
            ft.Column(
                expand=True,
                spacing=0,
                controls=[
                    _hero_section(page),
                    ft.Container(
                        expand=True,
                        padding=ft.padding.fromLTRB(16, 20, 16, 16),
                        content=scroll_body,
                    ),
                ],
            )
        ],
    )
