"""Local on-device persistence (Flet 0.85.3 — uses SharedPreferences class)."""
import flet as ft
from models import AppState

HISTORY_KEY    = "analysis_history"
THEME_KEY      = "dark_mode"
BACKEND_URL_KEY = "backend_url"


async def _prefs(page: ft.Page) -> ft.SharedPreferences:
    """Return the SharedPreferences instance (0.85 API)."""
    return ft.SharedPreferences(page)


async def load_state(page: ft.Page, state: AppState) -> None:
    prefs = ft.SharedPreferences(page)

    history_json = await prefs.get_async(HISTORY_KEY)
    if isinstance(history_json, str):
        state.history = state.history_from_json(history_json)

    dark = await prefs.get_async(THEME_KEY)
    state.dark_mode = bool(dark) if dark is not None else True   # default dark

    backend_url = await prefs.get_async(BACKEND_URL_KEY)
    if isinstance(backend_url, str) and backend_url:
        state.backend_url = backend_url


async def save_history(page: ft.Page, state: AppState) -> None:
    prefs = ft.SharedPreferences(page)
    await prefs.set_async(HISTORY_KEY, state.history_to_json())


async def save_theme(page: ft.Page, state: AppState) -> None:
    prefs = ft.SharedPreferences(page)
    await prefs.set_async(THEME_KEY, state.dark_mode)


async def save_backend_url(page: ft.Page, state: AppState) -> None:
    prefs = ft.SharedPreferences(page)
    await prefs.set_async(BACKEND_URL_KEY, state.backend_url)


async def clear_history(page: ft.Page, state: AppState) -> None:
    state.history = []
    prefs = ft.SharedPreferences(page)
    await prefs.remove_async(HISTORY_KEY)
