"""
Adapter between the API layer (main.py) and your existing
STAGE1/audio_pipeline.py.

Setup:
1. Copy these files from your STAGE1 project into backend/stage1/:
     - audio_pipeline.py
     - svm_model.pkl
     - scaler.pkl
   (and anything else audio_pipeline.py imports, e.g. speech_language_detection.py)

2. If the function in audio_pipeline.py isn't named `process_audio`,
   change the import below to match.

3. (Recommended) Add a "confidence" key to audio_pipeline.py's return dict:
     - For the SVM step: svm_model.predict_proba(X_scaled).max()
       (requires the SVM to have been trained/saved with probability=True)
     - For the Whisper step: whisper_model.detect_language(...) returns a
       probabilities dict per language - take the max value for the
       detected language.
   If "confidence" isn't present, the API still works; the app just shows
   "-" for confidence.
"""
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "stage1"))

try:
    from audio_pipeline import process_audio as _pipeline_fn  # noqa: E402
except ImportError:
    _pipeline_fn = None


def process_audio(audio_path: str) -> dict:
    """
    Runs the SVM + Whisper pipeline on a single audio file.

    Returns:
        {
            "audio_type": "Speech" | "Music" | "Noise",
            "language": str | None,
            "confidence": float | None,
        }
    """
    if _pipeline_fn is None:
        raise RuntimeError(
            "audio_pipeline.py not found in backend/stage1/. "
            "Copy it there along with svm_model.pkl and scaler.pkl. "
            "See the comment at the top of pipeline_adapter.py."
        )

    result = _pipeline_fn(audio_path)

    return {
        "audio_type": result.get("audio_type"),
        "language": result.get("language"),
        "confidence": result.get("confidence"),
    }
