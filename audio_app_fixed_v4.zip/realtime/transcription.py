"""
transcription.py
================
One interface, three backends.

The engine needs two very different things from Whisper:

  1. LANGUAGE DETECTION  — accurate, run rarely (startup + every ~2 min).
     Uses the bigger `lang_model` (default "small", your choice).

  2. CONTINUOUS TRANSCRIPTION — fast, run constantly, with WORD TIMESTAMPS
     so we can beep the exact word. Uses the lighter `transcribe_model`
     (default "base"), and — crucially — is given the already-detected
     language so it never wastes time re-detecting per window.

`TranscriptionEngine` hides which Whisper implementation is underneath:

  * "faster"  -> faster-whisper (CTranslate2). ~4x faster on CPU, lower RAM,
                 int8 quantization, native word timestamps. RECOMMENDED.
  * "openai"  -> the original openai-whisper package (what your code used).
  * "mock"    -> no model at all; deterministic canned output. Lets the whole
                 pipeline (buffering, VAD, beeping, wav I/O) be tested with no
                 heavy deps and no GPU — used by the test suite and --backend mock.

  * "auto"    -> faster if importable, else openai, else mock.

All backends return the same `Word(text, start, end)` list so the rest of the
engine is backend-agnostic.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass

import numpy as np


@dataclass
class Word:
    text: str
    start: float   # seconds, relative to the start of the audio passed in
    end: float


def _resolve_backend(name: str) -> str:
    if name != "auto":
        return name
    try:
        import faster_whisper  # noqa: F401
        return "faster"
    except Exception:
        pass
    try:
        import whisper  # noqa: F401
        return "openai"
    except Exception:
        return "mock"


# ═════════════════════════════════════════════════════════════════════════════
# faster-whisper backend
# ═════════════════════════════════════════════════════════════════════════════

class _FasterBackend:
    def __init__(self, cfg):
        from faster_whisper import WhisperModel
        self.cfg = cfg
        print(f"[faster-whisper] loading transcription model '{cfg.transcribe_model}' "
              f"({cfg.device}/{cfg.compute_type})…")
        self.tx = WhisperModel(cfg.transcribe_model, device=cfg.device,
                               compute_type=cfg.compute_type)
        if cfg.same_model or cfg.transcribe_model == cfg.lang_model:
            self.lang = self.tx
        else:
            print(f"[faster-whisper] loading language model '{cfg.lang_model}'…")
            self.lang = WhisperModel(cfg.lang_model, device=cfg.device,
                                     compute_type=cfg.compute_type)
        print("[faster-whisper] ready.\n")

    def detect_language(self, audio: np.ndarray) -> tuple[str, float]:
        # faster-whisper exposes language detection without full decoding
        try:
            lang, prob, _ = self.lang.detect_language(audio)
            return lang, float(prob)
        except Exception:
            # older versions: fall back to a 1-segment transcribe for info.language
            _, info = self.lang.transcribe(audio, beam_size=1)
            return info.language, float(getattr(info, "language_probability", 0.0))

    def transcribe(self, audio: np.ndarray, language: str | None) -> list[Word]:
        segments, _ = self.tx.transcribe(
            audio,
            language=language,          # pinned => no per-window detection
            task="transcribe",
            beam_size=1,                # greedy = fastest; fine for filtering
            word_timestamps=True,
            vad_filter=False,           # we run our own VAD upstream
            condition_on_previous_text=False,
            # Our energy VAD is deliberately lenient (it would rather pass a
            # bit of noise than ever hide real speech), so Whisper sometimes
            # sees a block that's just room tone, breathing, or a click. On
            # audio like that, greedy decoding can HALLUCINATE plausible-
            # looking words instead of returning nothing — which is exactly
            # what "beeped even though there were no words" looks like: the
            # wordlist/toxicity net then reacts to text that was never
            # actually said. These two thresholds make faster-whisper mark
            # such segments as no-speech instead of inventing words for them.
            no_speech_threshold=0.6,
            log_prob_threshold=-1.0,
        )
        words: list[Word] = []
        # Per-word confidence (when the backend provides it) catches the
        # same hallucination failure mode at word granularity: a single
        # low-confidence "word" inside an otherwise fine segment is dropped
        # rather than allowed to match the wordlist/tox net.
        min_word_prob = 0.35
        for seg in segments:
            if seg.words:
                for w in seg.words:
                    prob = getattr(w, "probability", None)
                    if prob is not None and prob < min_word_prob:
                        continue
                    words.append(Word(w.word, float(w.start), float(w.end)))
            else:
                words.append(Word(seg.text, float(seg.start), float(seg.end)))
        return words


# ═════════════════════════════════════════════════════════════════════════════
# openai-whisper backend
# ═════════════════════════════════════════════════════════════════════════════

class _OpenAIBackend:
    def __init__(self, cfg):
        import whisper
        self.whisper = whisper
        self.cfg = cfg
        print(f"[openai-whisper] loading transcription model '{cfg.transcribe_model}'…")
        self.tx = whisper.load_model(cfg.transcribe_model, device=cfg.device)
        if cfg.same_model or cfg.transcribe_model == cfg.lang_model:
            self.lang = self.tx
        else:
            print(f"[openai-whisper] loading language model '{cfg.lang_model}'…")
            self.lang = whisper.load_model(cfg.lang_model, device=cfg.device)
        print("[openai-whisper] ready.\n")

    def detect_language(self, audio: np.ndarray) -> tuple[str, float]:
        a = self.whisper.pad_or_trim(audio.astype(np.float32))
        mel = self.whisper.log_mel_spectrogram(a).to(self.lang.device)
        _, probs = self.lang.detect_language(mel)
        code = max(probs, key=probs.get)
        return code, float(probs[code])

    def transcribe(self, audio: np.ndarray, language: str | None) -> list[Word]:
        result = self.tx.transcribe(
            audio.astype(np.float32),
            language=language,          # pinned
            task="transcribe",
            word_timestamps=True,
            condition_on_previous_text=False,
            verbose=False,
            # See the matching comment in _FasterBackend.transcribe: suppress
            # hallucinated words on VAD-passed non-speech (room tone,
            # breathing, clicks) so they can't trigger a false beep.
            no_speech_threshold=0.6,
            logprob_threshold=-1.0,
        )
        words: list[Word] = []
        min_word_prob = 0.35
        for seg in result.get("segments", []):
            wl = seg.get("words")
            if wl:
                for w in wl:
                    prob = w.get("probability")
                    if prob is not None and prob < min_word_prob:
                        continue
                    words.append(Word(w["word"], float(w["start"]), float(w["end"])))
            else:
                words.append(Word(seg["text"], float(seg["start"]), float(seg["end"])))
        return words


# ═════════════════════════════════════════════════════════════════════════════
# mock backend — no model, deterministic; for tests / demos without deps
# ═════════════════════════════════════════════════════════════════════════════

class _MockBackend:
    """
    Produces fake words on a fixed grid so the pipeline can be exercised
    end-to-end with zero heavy dependencies. If cfg._extra["mock_script"]
    is set (a list of (text, start, end) relative to the WHOLE stream), the
    engine's caller maps it per-window; otherwise emits a repeating pattern
    where the token "badword" appears once per window at a known position so
    tests can assert precise beeping.
    """
    def __init__(self, cfg):
        self.cfg = cfg
        print("[mock] no Whisper backend loaded — using deterministic stub.\n")

    def detect_language(self, audio: np.ndarray) -> tuple[str, float]:
        return "en", 1.0

    def transcribe(self, audio: np.ndarray, language: str | None) -> list[Word]:
        sr = self.cfg.sample_rate
        dur = len(audio) / sr
        bad = self.cfg._extra.get("mock_bad_token", "badword")
        words: list[Word] = []
        # one "word" every 0.5s; middle word is the profane token
        step = 0.5
        n = max(1, int(dur / step))
        mid = n // 2
        for i in range(n):
            t0 = i * step
            t1 = min(dur, t0 + 0.35)
            words.append(Word(bad if i == mid else f"tok{i}", t0, t1))
        return words


# ═════════════════════════════════════════════════════════════════════════════
# Public engine
# ═════════════════════════════════════════════════════════════════════════════

class TranscriptionEngine:
    def __init__(self, cfg):
        self.cfg = cfg
        self.backend_name = _resolve_backend(cfg.backend)
        try:
            if self.backend_name == "faster":
                self.impl = _FasterBackend(cfg)
            elif self.backend_name == "openai":
                self.impl = _OpenAIBackend(cfg)
            else:
                self.backend_name = "mock"
                self.impl = _MockBackend(cfg)
        except Exception as e:
            hint = {"faster": "pip install faster-whisper",
                    "openai": "pip install openai-whisper"}.get(self.backend_name, "")
            print(f"[backend] could not load '{self.backend_name}' ({e}). "
                  f"{('Try: ' + hint + '. ') if hint else ''}"
                  f"Falling back to the mock backend (no real transcription).",
                  file=sys.stderr)
            self.backend_name = "mock"
            self.impl = _MockBackend(cfg)

    def detect_language(self, audio: np.ndarray) -> tuple[str, float]:
        return self.impl.detect_language(audio)

    def transcribe(self, audio: np.ndarray, language: str | None) -> list[Word]:
        return self.impl.transcribe(audio, language)
