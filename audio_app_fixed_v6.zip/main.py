import flet as ft
import flet_audio as fa
import json
import os
import math
import datetime
import asyncio
import threading
import concurrent.futures

# ─── Pipeline import ─────────────────────────────────────────────────────────
try:
    from audio_pipeline import analyze_audio as _analyze_audio
    _PIPELINE_READY = True
except Exception as _e:
    _PIPELINE_READY = False
    _PIPELINE_ERR   = str(_e)

try:
    from audio_pipeline import check_profanity as _check_profanity
    _PROFANITY_READY = True
except Exception:
    _PROFANITY_READY = False

# ─── Real-time (mic → speaker) profanity filter import ──────────────────────
# Lives in realtime/. Needs sounddevice (+ PortAudio) for mic/speaker I/O;
# the transcription backend auto-falls-back to a mock if faster-whisper/
# whisper aren't installed, so *building* an analyzer never hard-fails on
# its own — only *starting* a live session (which needs a real mic) can.
try:
    from realtime.config import RealtimeConfig
    from realtime.realtime_filter import build as _build_live_analyzer, RealtimeEngine
    from realtime import audio_io as _live_audio_io
    _REALTIME_READY = True
    _REALTIME_ERR   = None
except Exception as _rte:
    _REALTIME_READY = False
    _REALTIME_ERR   = str(_rte)

LIVE_LANG_CHOICES = [
    ("auto", "Auto-detect"),
    ("en", "English"), ("fr", "French"), ("de", "German"), ("hi", "Hindi"),
    ("kn", "Kannada"), ("ko", "Korean"), ("ml", "Malayalam"), ("es", "Spanish"),
    ("ta", "Tamil"), ("te", "Telugu"), ("ur", "Urdu"),
]

APP_VERSION   = "1.0.0"
APP_DIR       = os.path.dirname(os.path.abspath(__file__))
HISTORY_FILE  = os.path.join(APP_DIR, "analysis_history.json")
SETTINGS_FILE = os.path.join(APP_DIR, "app_settings.json")
LIVE_MONITOR_DIR = os.path.join(APP_DIR, "live_monitor")  # rolling wav of what was actually played

LANGUAGES = [
    "English", "French", "German", "Hindi",
    "Kannada", "Korean", "Malayalam", "Spanish",
    "Tamil", "Telugu",
]

# ═══════════════════════════════════════════════════════════════════════════════
# DESIGN SYSTEM  —  One UI inspired, flat, Samsung-blue primary, dual theme
# ═══════════════════════════════════════════════════════════════════════════════
class Palette:
    def __init__(self, **kw):
        self.__dict__.update(kw)

LIGHT_PAL = Palette(
    BG="#F2F4F8", SURFACE="#FFFFFF", SURFACE_2="#EDF0F6", SURFACE_3="#F6F8FC",
    BORDER="#E6E9F0", BORDER_STRONG="#D6DBE6",
    BRAND="#1B6EF3", BRAND_STRONG="#1457D6", BRAND_SOFT="#E4EDFE",
    ON_BRAND="#FFFFFF", ON_BRAND_MUTED="#C7DAFB",
    TEXT="#0C1322", TEXT_2="#39435A", MUTED="#6A7588", FAINT="#9AA3B4",
    SPEECH="#0EA5A5", SPEECH_SOFT="#D6F1F1",
    MUSIC="#7C5CFC",  MUSIC_SOFT="#E9E3FE",
    NOISE="#E08A00",  NOISE_SOFT="#FBEBCB",
    OK="#12A150", OK_SOFT="#D6F0E0", WARN="#E08A00", WARN_SOFT="#FBEBCB",
    ERR="#E5484D", ERR_SOFT="#FBDDDE",
    ERR_MUTED="#B0555A", ERR_MUTED_SOFT="#F3DEDF",
    NAV_BG="#FFFFFF", NAV_INDICATOR="#E4EDFE",
    NAV_SEL_ICON="#1B6EF3", NAV_ICON="#8A93A4",
    NAV_LABEL="#8A93A4", NAV_LABEL_SEL="#1B6EF3",
    RING_TRACK="#E9EDF5", WHITE="#FFFFFF",
)

DARK_PAL = Palette(
    BG="#0B0C11", SURFACE="#16181F", SURFACE_2="#212530", SURFACE_3="#1B1E27",
    BORDER="#272B36", BORDER_STRONG="#343A48",
    BRAND="#3B82F6", BRAND_STRONG="#2E6FE0", BRAND_SOFT="#16233B",
    ON_BRAND="#FFFFFF", ON_BRAND_MUTED="#CBDDFB",
    TEXT="#F4F6FA", TEXT_2="#C3CBD8", MUTED="#8A93A2", FAINT="#5B6473",
    SPEECH="#2DC6C6", SPEECH_SOFT="#0F2E2E",
    MUSIC="#9E86FF",  MUSIC_SOFT="#211C3A",
    NOISE="#F4A63A",  NOISE_SOFT="#33260F",
    OK="#2DB96E", OK_SOFT="#10301E", WARN="#F4A63A", WARN_SOFT="#33260F",
    ERR="#F26269", ERR_SOFT="#341A1C",
    ERR_MUTED="#C97478", ERR_MUTED_SOFT="#3A1F21",
    NAV_BG="#121319", NAV_INDICATOR="#1B2A45",
    NAV_SEL_ICON="#5B95F7", NAV_ICON="#7B8494",
    NAV_LABEL="#7B8494", NAV_LABEL_SEL="#6AA0F8",
    RING_TRACK="#272B36", WHITE="#FFFFFF",
)

HERO_TRACK = "#33FFFFFF"
HERO_SOFT  = "#1FFFFFFF"
HERO_HOVER = "#EAF0FD"

IS_DARK = False
P = LIGHT_PAL

DISPLAY_FONT = "Manrope"
BODY_FONT    = "Manrope"
MANROPE_URL  = "https://raw.githubusercontent.com/google/fonts/main/ofl/manrope/Manrope%5Bwght%5D.ttf"
def set_palette(dark):
    global P, IS_DARK
    IS_DARK = dark
    P = DARK_PAL if dark else LIGHT_PAL
def apply_page_theme(page):
    page.theme_mode = ft.ThemeMode.DARK if IS_DARK else ft.ThemeMode.LIGHT
    page.bgcolor = P.BG
def _load_settings():
    global IS_DARK
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE) as f:
                IS_DARK = bool(json.load(f).get("dark", False))
        except Exception:
            pass
def _save_settings():
    try:
        with open(SETTINGS_FILE, "w") as f:
            json.dump({"dark": IS_DARK}, f)
    except Exception:
        pass
# ─── History Manager ─────────────────────────────────────────────────────────
class HistoryManager:
    def __init__(self):
        self.records = []
        self._load()

    def _load(self):
        if os.path.exists(HISTORY_FILE):
            try:
                with open(HISTORY_FILE) as f:
                    self.records = json.load(f)
            except Exception:
                self.records = []

    def _save(self):
        with open(HISTORY_FILE, "w") as f:
            json.dump(self.records, f, indent=2)

    def add(self, record: dict):
        self.records.insert(0, record)
        if len(self.records) > 100:
            self.records = self.records[:100]
        self._save()

    def clear(self):
        self.records = []
        self._save()

    def export(self) -> str:
        lines = ["Audio Classifier - Analysis History", "=" * 40]
        for r in self.records:
            lines.append(f"\nDate      : {r.get('timestamp','N/A')}")
            lines.append(f"File      : {r.get('filename','N/A')}")
            lines.append(f"Type      : {r.get('audio_type','N/A')}")
            if r.get("language"):
                lines.append(f"Language  : {r['language']}")
            lines.append(f"Duration  : {r.get('duration','N/A')}")
            lines.append("-" * 30)
        return "\n".join(lines)

    def stats(self):
        total  = len(self.records)
        speech = sum(1 for r in self.records if r.get("audio_type") == "Speech")
        music  = sum(1 for r in self.records if r.get("audio_type") == "Music")
        noise  = sum(1 for r in self.records if r.get("audio_type") == "Noise")
        lang_dist = {}
        for r in self.records:
            if r.get("language"):
                lang_dist[r["language"]] = lang_dist.get(r["language"], 0) + 1
        return {"total": total, "speech": speech,
                "music": music, "noise": noise, "lang_dist": lang_dist}
# ─── Live filter session ──────────────────────────────────────────────────────
class LiveSession:
    """
    Owns the background real-time profanity-filter engine.

    RealtimeEngine.run() spawns its own capture/analysis/playback threads and
    then blocks the calling thread until stop_event is set, so we call it from
    one dedicated daemon thread and poll its plain-attribute stats (played,
    beeped, buffer depth, etc.) from the UI instead of invoking it directly.
    """
    def __init__(self):
        self.thread   = None
        self.engine   = None     # RealtimeEngine instance, once built
        self.analyzer = None     # ProfanityAnalyzer instance, once built
        self.cfg      = None
        self.starting = False
        self.error    = None
        # pending session settings, editable from the Live screen while idle
        self.pending_force_lang = "auto"
        self.pending_unverified = "mute"
        self.pending_granularity = "word"
        # The toxicity TRANSFORMER net is the real analysis bottleneck on
        # real devices (a ~280M-param model run on nearly every speech
        # block, sometimes twice) — off by default so live sessions rely on
        # the fast, exact-match wordlist and can actually keep up with real
        # time. See the comment in _toggle() below for the full story.
        self.pending_use_tox = False
        self.speaker_desc = None
        self.monitor_path = None

    def is_alive(self) -> bool:
        return bool(self.thread and self.thread.is_alive())

    def start(self, cfg):
        if self.is_alive() or self.starting:
            return
        self.error         = None
        self.starting      = True
        self.engine        = None
        self.analyzer      = None
        self.cfg           = cfg
        self.speaker_desc  = None   # which physical device is actually playing
        self.monitor_path  = None   # wav of exactly what was played, for verification

        def _run():
            sinks = []
            try:
                analyzer  = _build_live_analyzer(cfg)
                source    = _live_audio_io.make_source(cfg)

                speaker = _live_audio_io.SpeakerSink(cfg)
                sinks.append(speaker)
                self.speaker_desc = speaker.describe()

                # Always-on monitor tap: writes exactly what's played (beeps
                # included) to a rolling wav on disk, independent of whether
                # the live speaker is actually audible. This is the ground
                # truth to check against if you're not sure what you heard.
                try:
                    monitor = _live_audio_io.DebugTapSink(cfg, LIVE_MONITOR_DIR)
                    sinks.append(monitor)
                    self.monitor_path = monitor.current_path
                except Exception:
                    pass  # monitor is a diagnostic nicety, never block playback on it

                sink = (_live_audio_io.FanoutSink(sinks)
                        if len(sinks) != 1 else sinks[0])

                engine        = RealtimeEngine(cfg, analyzer)
                self.analyzer = analyzer
                self.engine   = engine
                self.starting = False
                engine.run(source, sink)     # blocks until stopped
            except Exception as ex:
                self.error    = str(ex)
                self.starting = False
            finally:
                for s in sinks:
                    try:
                        s.close()
                    except Exception:
                        pass

        self.thread = threading.Thread(target=_run, daemon=True)
        self.thread.start()

    def stop(self):
        if self.engine is not None:
            self.engine.stop_event.set()

    def stats(self) -> dict:
        eng = self.engine
        if eng is None:
            return {}
        try:
            with eng.lock:
                buffer_depth = len(eng.buffer)
            src = getattr(eng, "_source_ref", None)
            snk = getattr(eng, "_sink_ref", None)
            q_fn = getattr(snk, "queued_seconds", None) if snk is not None else None
            try:
                cushion = float(q_fn()) if q_fn else 0.0
            except Exception:
                cushion = 0.0
            return {
                "language":   (self.analyzer.language if self.analyzer else None),
                "played_s":   eng._played * eng.cfg.segment,
                "beeped_s":   eng._beeped_samples / eng.cfg.sample_rate,
                "buffer":     buffer_depth,
                "passes":     eng._passes,
                "unverified": eng._unverified,
                "delay":      eng.delay,
                "cushion_s":  cushion,
                "overflows":  getattr(src, "overflows", 0) if src is not None else 0,
                "underruns":  getattr(snk, "underruns", 0) if snk is not None else 0,
                "backend":    _analyzer_backend_name(self.analyzer),
                "speaker":    self.speaker_desc,
                "monitor":    self.monitor_path,
            }
        except Exception:
            return {}

def _analyzer_backend_name(analyzer) -> str:
    try:
        return analyzer.engine.backend_name
    except Exception:
        return "—"

# ─── App State ───────────────────────────────────────────────────────────────
class AppState:
    def __init__(self):
        self.history_mgr    = HistoryManager()
        self.last_result    = None
        self.current_file   = None
        self.file_picker    = None
        self.playing_path   = None   # filepath currently loaded in the player
        self.is_playing     = False
        self.current_screen = "home"
        self.live           = LiveSession()

state = AppState()
# ─── Pipeline helpers ────────────────────────────────────────────────────────
def _format_duration(seconds: float) -> str:
    if seconds is None:
        return "N/A"
    seconds = max(0.0, float(seconds))
    if seconds < 60:
        return f"{seconds:.1f}s"
    m, s = divmod(int(round(seconds)), 60)
    return f"{m}:{s:02d}"

def _get_audio_duration(audio_path: str) -> str:
    if not audio_path or not os.path.exists(audio_path):
        return "N/A"
    try:
        import librosa
        try:
            seconds = librosa.get_duration(path=audio_path)
        except TypeError:
            seconds = librosa.get_duration(filename=audio_path)
        return _format_duration(seconds)
    except Exception:
        pass
    try:
        import wave
        with wave.open(audio_path, "rb") as w:
            frames = w.getnframes()
            rate   = w.getframerate()
            if rate:
                return _format_duration(frames / float(rate))
    except Exception:
        pass
    try:
        import soundfile as sf
        info = sf.info(audio_path)
        return _format_duration(info.duration)
    except Exception:
        pass
    return "N/A"

def _run_pipeline_sync(audio_path: str) -> dict:
    if not _PIPELINE_READY:
        raise RuntimeError(
            f"Could not import audio_pipeline.\nError: {_PIPELINE_ERR}\n\n"
            "Make sure audio_pipeline.py, svm_model.pkl and scaler.pkl "
            "are in the same folder as main.py."
        )
    return _analyze_audio(audio_path)

def _analyze_with_duration(audio_path: str):
    result = _run_pipeline_sync(audio_path)
    duration = _get_audio_duration(audio_path)
    return result, duration
# ─── Type helpers ────────────────────────────────────────────────────────────
def _type_color(t):
    return {"Speech": P.SPEECH, "Music": P.MUSIC, "Noise": P.NOISE}.get(t, P.BRAND)

def _type_soft(t):
    return {"Speech": P.SPEECH_SOFT, "Music": P.MUSIC_SOFT, "Noise": P.NOISE_SOFT}.get(t, P.BRAND_SOFT)

def _type_icon(t):
    return {
        "Speech": ft.Icons.MIC_ROUNDED,
        "Music":  ft.Icons.MUSIC_NOTE_ROUNDED,
        "Noise":  ft.Icons.GRAPHIC_EQ_ROUNDED,
    }.get(t, ft.Icons.HELP_OUTLINE_ROUNDED)
# ═══════════════════════════════════════════════════════════════════════════════
# PRIMITIVES
# ═══════════════════════════════════════════════════════════════════════════════
def T(text, size=14, color=None, weight=ft.FontWeight.NORMAL, align=None, font=None):
    return ft.Text(
        text, size=size,
        color=color or P.TEXT_2,
        weight=weight,
        font_family=font or BODY_FONT,
        text_align=align or ft.TextAlign.LEFT,
    )

def D(text, size=24, color=None, weight=ft.FontWeight.W_800, align=None):
    return T(text, size=size, color=color or P.TEXT, weight=weight, align=align, font=DISPLAY_FONT)

def divider():
    return ft.Container(height=1, bgcolor=P.BORDER)

def card(content, pad=18, radius=22, bg=None, border=True, border_color=None):
    return ft.Container(
        content=content,
        bgcolor=bg or P.SURFACE,
        border_radius=radius,
        padding=pad,
        border=ft.Border.all(1, border_color or P.BORDER) if border else None,
    )

def section_title(txt):
    return ft.Container(
        T(txt.upper(), size=11, color=P.MUTED, weight=ft.FontWeight.W_700),
        padding=ft.Padding(left=4, right=0, top=4, bottom=2),
    )

def icon_square(icon, fg, bg, size=38, isz=18, radius=13):
    return ft.Container(
        ft.Icon(icon, color=fg, size=isz),
        width=size, height=size,
        bgcolor=bg, border_radius=radius,
        alignment=ft.alignment.Alignment(0, 0),
    )

def chip(label, fg, bg, size=11):
    return ft.Container(
        T(label, size=size, color=fg, weight=ft.FontWeight.W_700),
        bgcolor=bg, border_radius=100,
        padding=ft.Padding(left=11, right=11, top=6, bottom=6),
    )

def status_pill(text, dot_color):
    return ft.Container(
        ft.Row([
            ft.Container(width=8, height=8, border_radius=4, bgcolor=dot_color),
            T(text, size=12, color=P.MUTED, weight=ft.FontWeight.W_500),
        ], spacing=8, tight=True),
        bgcolor=P.SURFACE_2, border_radius=100,
        padding=ft.Padding(left=12, right=14, top=7, bottom=7),
    )

def pill_button(label, icon, on_click, kind="brand", expand=False, ref=None):
    if kind == "onbrand":
        fg, bg, hov, side = P.BRAND, P.WHITE, HERO_HOVER, ft.BorderSide(0, "transparent")
    elif kind == "ghost":
        fg, bg, hov, side = P.TEXT, "transparent", P.SURFACE_2, ft.BorderSide(1.5, P.BORDER_STRONG)
    else:
        fg, bg, hov, side = P.ON_BRAND, P.BRAND, P.BRAND_STRONG, ft.BorderSide(0, "transparent")
    return ft.Button(
        ref=ref,
        content=ft.Row([
            ft.Icon(icon, size=17, color=fg),
            T(label, size=14, color=fg, weight=ft.FontWeight.W_700),
        ], spacing=9, tight=True, alignment=ft.MainAxisAlignment.CENTER),
        on_click=on_click, expand=expand,
        style=ft.ButtonStyle(
            bgcolor={
                ft.ControlState.DEFAULT:  bg,
                ft.ControlState.HOVERED:  hov,
                ft.ControlState.DISABLED: P.SURFACE_2,
            },
            side={ft.ControlState.DEFAULT: side},
            shape=ft.RoundedRectangleBorder(radius=100),
            padding=ft.Padding(left=26, right=26, top=16, bottom=16),
        ),
    )

def back_btn(on_click):
    return ft.IconButton(
        ft.Icons.ARROW_BACK_ROUNDED, on_click=on_click,
        icon_color=P.TEXT, icon_size=20,
        style=ft.ButtonStyle(
            bgcolor={ft.ControlState.DEFAULT: P.SURFACE_2, ft.ControlState.HOVERED: P.SURFACE_3},
            shape=ft.RoundedRectangleBorder(radius=100),
            padding=ft.Padding(left=9, right=9, top=9, bottom=9),
        ),
    )

def chevron_btn(on_click, color):
    return ft.IconButton(
        ft.Icons.CHEVRON_RIGHT_ROUNDED, on_click=on_click,
        icon_color=color, icon_size=20,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10)),
    )

def list_row(icon, fg, soft, title, subtitle=None, trailing=None, value=None):
    mid = [T(title, size=15, color=P.TEXT, weight=ft.FontWeight.W_700)]
    if subtitle:
        mid.append(T(subtitle, size=12, color=P.MUTED))
    row = [icon_square(icon, fg, soft), ft.Column(mid, spacing=2, expand=True)]
    if trailing is not None:
        row.append(trailing)
    elif value is not None:
        row.append(T(value, size=14, color=P.TEXT, weight=ft.FontWeight.W_700))
    return ft.Container(
        ft.Row(row, spacing=14, vertical_alignment=ft.CrossAxisAlignment.CENTER),
        padding=ft.Padding(left=14, right=12, top=14, bottom=14),
    )

def group(rows, bg=None):
    ch = []
    for i, r in enumerate(rows):
        if i > 0:
            ch.append(ft.Container(
                ft.Container(height=1, bgcolor=P.BORDER),
                padding=ft.Padding(left=16, right=16, top=0, bottom=0),
            ))
        ch.append(r)
    return ft.Container(
        ft.Column(ch, spacing=0),
        bgcolor=bg or P.SURFACE, border_radius=22,
        border=ft.Border.all(1, P.BORDER),
    )

def empty_state(icon, title, subtitle):
    inner = ft.Column([
        ft.Container(
            ft.Icon(icon, size=30, color=P.FAINT),
            width=66, height=66, border_radius=66,
            bgcolor=P.SURFACE_2, alignment=ft.alignment.Alignment(0, 0),
        ),
        ft.Container(height=14),
        D(title, size=17, color=P.TEXT, align=ft.TextAlign.CENTER),
        ft.Container(height=4),
        T(subtitle, size=13, color=P.MUTED, align=ft.TextAlign.CENTER),
    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=0)
    return ft.Container(
        content=inner, bgcolor=P.SURFACE, border_radius=22,
        border=ft.Border.all(1, P.BORDER), padding=36,
        alignment=ft.alignment.Alignment(0, 0),
    )

def stat_tile(value, label, fg, soft, icon, brand=False):
    if brand:
        bg, num_c, lbl_c = P.BRAND, P.ON_BRAND, P.ON_BRAND_MUTED
        isq = icon_square(icon, P.WHITE, HERO_SOFT, size=34, isz=16, radius=11)
        border = None
    else:
        bg, num_c, lbl_c = P.SURFACE, fg, P.MUTED
        isq = icon_square(icon, fg, soft, size=34, isz=16, radius=11)
        border = ft.Border.all(1, P.BORDER)
    return ft.Container(
        ft.Column([
            ft.Row([isq, ft.Container(expand=True)]),
            ft.Container(height=12),
            D(str(value), size=28, color=num_c),
            T(label, size=12, color=lbl_c, weight=ft.FontWeight.W_500),
        ], spacing=2),
        bgcolor=bg, border_radius=20, padding=16, border=border, expand=True,
    )

def spec_card(title, items, fg, soft, icon):
    rows = [
        ft.Row([
            T(k, size=12, color=P.MUTED),
            ft.Container(expand=True),
            T(v, size=12, color=P.TEXT, weight=ft.FontWeight.W_600),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER)
        for k, v in items.items()
    ]
    return card(ft.Column([
        ft.Row([
            icon_square(icon, fg, soft),
            D(title, size=16, color=P.TEXT),
        ], spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER),
        divider(),
        *rows,
    ], spacing=12))
# ─── Signature element: concentric ring ──────────────────────────────────────
def ring(icon, ring_color, inner_bg, icon_color, size=116, stroke=9, icon_size=40):
    inner = size - 2 * stroke
    return ft.Container(
        content=ft.Container(
            content=ft.Icon(icon, color=icon_color, size=icon_size),
            width=inner, height=inner, border_radius=inner, bgcolor=inner_bg,
            alignment=ft.alignment.Alignment(0, 0),
        ),
        width=size, height=size, border_radius=size, bgcolor=ring_color,
        alignment=ft.alignment.Alignment(0, 0),
    )

def _center_layer(child, box):
    return ft.Container(content=child, width=box, height=box,
                        alignment=ft.alignment.Alignment(0, 0))
# ─── Theme switching ──────────────────────────────────────────────────────────
def _mk_theme_handler(page, navigate, target):
    async def _h(e):
        await set_theme(page, navigate, target)
    return _h

async def set_theme(page, navigate, dark):
    set_palette(dark)
    _save_settings()
    apply_page_theme(page)
    await navigate(state.current_screen)

def theme_icon_button(page, navigate):
    icon = ft.Icons.DARK_MODE_ROUNDED if IS_DARK else ft.Icons.LIGHT_MODE_ROUNDED
    return ft.IconButton(
        icon, icon_color=P.TEXT_2, icon_size=20,
        on_click=_mk_theme_handler(page, navigate, not IS_DARK),
        style=ft.ButtonStyle(
            bgcolor={ft.ControlState.DEFAULT: P.SURFACE_2, ft.ControlState.HOVERED: P.SURFACE_3},
            shape=ft.RoundedRectangleBorder(radius=100),
            padding=ft.Padding(left=10, right=10, top=10, bottom=10),
        ),
    )

def theme_segment(page, navigate):
    def seg(label, icon, target):
        active = (IS_DARK == target)
        fg = P.ON_BRAND if active else P.TEXT_2
        return ft.Button(
            content=ft.Row([
                ft.Icon(icon, size=16, color=fg),
                T(label, size=13, color=fg, weight=ft.FontWeight.W_700),
            ], spacing=8, tight=True, alignment=ft.MainAxisAlignment.CENTER),
            on_click=_mk_theme_handler(page, navigate, target),
            expand=True,
            style=ft.ButtonStyle(
                bgcolor={
                    ft.ControlState.DEFAULT: (P.BRAND if active else "transparent"),
                    ft.ControlState.HOVERED: (P.BRAND if active else P.SURFACE_3),
                },
                shape=ft.RoundedRectangleBorder(radius=100),
                padding=ft.Padding(left=14, right=14, top=11, bottom=11),
            ),
        )
    return ft.Container(
        ft.Row([
            seg("Light", ft.Icons.LIGHT_MODE_ROUNDED, False),
            seg("Dark",  ft.Icons.DARK_MODE_ROUNDED,  True),
        ], spacing=6),
        bgcolor=P.SURFACE_2, border_radius=100, padding=6,
    )

def big_header(caption, title, page, navigate, trailing=None):
    tr = trailing if trailing is not None else theme_icon_button(page, navigate)
    return ft.Row([
        ft.Column([
            T(caption.upper(), size=11, color=P.MUTED, weight=ft.FontWeight.W_700),
            ft.Container(height=3),
            D(title, size=28, color=P.TEXT),
        ], spacing=0, expand=True),
        ft.Container(width=10),
        tr,
    ], vertical_alignment=ft.CrossAxisAlignment.START)
# ═══════════════════════════════════════════════════════════════════════════════
# NAV BAR
# ═══════════════════════════════════════════════════════════════════════════════
def build_nav(selected_index, on_change):
    bar = ft.NavigationBar(
        selected_index=selected_index,
        on_change=on_change,
        bgcolor=P.NAV_BG,
        indicator_color=P.NAV_INDICATOR,
        indicator_shape=ft.RoundedRectangleBorder(radius=14),
        shadow_color="transparent",
        label_behavior=ft.NavigationBarLabelBehavior.ALWAYS_SHOW,
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME_OUTLINED,     selected_icon=ft.Icons.HOME_ROUNDED,     label="Home"),
            ft.NavigationBarDestination(icon=ft.Icons.MIC_NONE_ROUNDED,  selected_icon=ft.Icons.MIC_ROUNDED,      label="Live"),
            ft.NavigationBarDestination(icon=ft.Icons.HISTORY_OUTLINED,  selected_icon=ft.Icons.HISTORY_ROUNDED,  label="History"),
            ft.NavigationBarDestination(icon=ft.Icons.INSIGHTS_OUTLINED, selected_icon=ft.Icons.INSIGHTS_ROUNDED, label="Analytics"),
            ft.NavigationBarDestination(icon=ft.Icons.SETTINGS_OUTLINED, selected_icon=ft.Icons.SETTINGS_ROUNDED, label="Settings"),
            ft.NavigationBarDestination(icon=ft.Icons.INFO_OUTLINED,     selected_icon=ft.Icons.INFO_ROUNDED,     label="About"),
        ],
    )
    return ft.Container(
        ft.Column([ft.Container(height=1, bgcolor=P.BORDER), bar], spacing=0),
        bgcolor=P.NAV_BG,
    )
# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN: HOME
# ═══════════════════════════════════════════════════════════════════════════════
def build_home(page, navigate):
    fp = state.file_picker

    btn_ref    = ft.Ref[ft.Button]()
    status_ref = ft.Ref[ft.Text]()
    halo_ref   = ft.Ref[ft.Container]()
    anim       = {"on": False}

    HOME_BOX = 190

    async def _pulse():
        anim["on"] = True
        t = 0.0
        while anim["on"]:
            if halo_ref.current is None:
                break
            t += 1
            f = 0.5 + 0.5 * math.sin(t * 0.35)
            sz = 150 + 30 * f
            halo_ref.current.width = sz
            halo_ref.current.height = sz
            page.update()
            await asyncio.sleep(0.05)

    async def pick_file(_):
        btn_ref.current.disabled = True
        page.update()

        files = await fp.pick_files(
            dialog_title="Select Audio File",
            file_type=ft.FilePickerFileType.CUSTOM,
            allowed_extensions=["wav", "mp3", "ogg", "flac", "m4a", "aac"],
        )

        if not files:
            btn_ref.current.disabled = False
            status_ref.current.value = "No file selected."
            status_ref.current.color = P.ON_BRAND_MUTED
            page.update()
            return

        f = files[0]
        state.current_file = f.path
        status_ref.current.value = f"Analyzing  {f.name}"
        status_ref.current.color = P.ON_BRAND
        page.update()
        page.run_task(_pulse)

        loop = asyncio.get_event_loop()
        try:
            with concurrent.futures.ThreadPoolExecutor() as pool:
                result, duration = await loop.run_in_executor(
                    pool, _analyze_with_duration, f.path or f.name
                )
            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            record = {
                "filename":   f.name,
                "audio_type": result["audio_type"],
                "language":   result.get("language"),
                "duration":   duration,
                "timestamp":  ts,
                "filepath":   f.path,   # store path for player
            }
            state.history_mgr.add(record)
            state.last_result = record
            anim["on"] = False
            btn_ref.current.disabled = False
            page.update()
            await navigate("result")
        except Exception as ex:
            anim["on"] = False
            btn_ref.current.disabled = False
            status_ref.current.value = f"Error: {ex}"
            status_ref.current.color = "#FFDAD9"
            page.update()

    # pipeline status pill
    if _PIPELINE_READY:
        pill = status_pill("SVM + Whisper models loaded", P.OK)
    else:
        pill = status_pill("Models not found — demo mode", P.WARN)

    # signature visual: breathing halo behind a white ring, on the blue hero
    visual = ft.Stack([
        _center_layer(ft.Container(
            ref=halo_ref, width=150, height=150, border_radius=200,
            bgcolor=HERO_TRACK,
            animate=ft.Animation(160, ft.AnimationCurve.EASE_IN_OUT),
        ), HOME_BOX),
        _center_layer(ring(
            ft.Icons.GRAPHIC_EQ_ROUNDED, P.WHITE, P.BRAND, P.WHITE,
            size=112, stroke=8, icon_size=42,
        ), HOME_BOX),
    ], width=HOME_BOX, height=HOME_BOX)

    hero = ft.Container(
        ft.Column([
            visual,
            ft.Container(height=18),
            D("Analyze a sound", size=22, color=P.ON_BRAND, align=ft.TextAlign.CENTER),
            ft.Container(height=6),
            T("WAV · MP3 · OGG · FLAC · M4A · AAC",
              size=12, color=P.ON_BRAND_MUTED, align=ft.TextAlign.CENTER),
            ft.Container(height=22),
            pill_button("Choose audio file", ft.Icons.FOLDER_OPEN_ROUNDED,
                        pick_file, kind="onbrand", ref=btn_ref),
            ft.Container(height=12),
            ft.Text(
                ref=status_ref, value="No file selected yet",
                size=12, color=P.ON_BRAND_MUTED,
                text_align=ft.TextAlign.CENTER, font_family=BODY_FONT,
            ),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=0),
        bgcolor=P.BRAND, border_radius=28,
        padding=ft.Padding(left=22, right=22, top=28, bottom=28),
    )

    # recent
    recent = state.history_mgr.records[:4]
    if recent:
        rows = []
        for r in recent:
            sub = r["audio_type"] + (f" · {r['language']}" if r.get("language") else "")
            rows.append(list_row(
                _type_icon(r["audio_type"]), _type_color(r["audio_type"]),
                _type_soft(r["audio_type"]), r["filename"], subtitle=sub,
                trailing=chip(r["audio_type"], _type_color(r["audio_type"]),
                              _type_soft(r["audio_type"])),
            ))
        recent_section = ft.Column([section_title("Recent"), group(rows)], spacing=10)
    else:
        recent_section = ft.Column([
            section_title("Recent"),
            empty_state(ft.Icons.GRAPHIC_EQ_ROUNDED, "Nothing analyzed yet",
                        "Your analyses will appear here."),
        ], spacing=10)

    async def _go_live(_):
        await navigate("live")

    live_running = state.live.is_alive() or state.live.starting
    live_shortcut = ft.Container(
        content=list_row(
            ft.Icons.MIC_ROUNDED,
            P.OK if live_running else P.BRAND,
            P.OK_SOFT if live_running else P.BRAND_SOFT,
            "Live Filter",
            subtitle=("Listening now" if live_running else "Listen to your mic in real time"),
            trailing=ft.Icon(ft.Icons.CHEVRON_RIGHT_ROUNDED, color=P.MUTED, size=20),
        ),
        bgcolor=P.SURFACE, border_radius=22,
        border=ft.Border.all(1, P.BORDER),
        on_click=_go_live,
    )

    return ft.Column([
        big_header("On-device audio AI", "Audio Classifier", page, navigate),
        pill,
        hero,
        live_shortcut,
        recent_section,
    ], spacing=18, scroll=ft.ScrollMode.AUTO, expand=True)

# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN: RESULT
# ═══════════════════════════════════════════════════════════════════════════════
def build_result(page, navigate):
    async def _go_home(_):
        await navigate("home")

    r = state.last_result
    if not r:
        return ft.Column([
            D("No result yet", size=22, color=P.TEXT),
            pill_button("Go home", ft.Icons.HOME_ROUNDED, _go_home),
        ], spacing=20)

    atype    = r["audio_type"]
    col      = _type_color(atype)
    soft     = _type_soft(atype)
    lang     = r.get("language") or "N/A"
    has_lang = lang != "N/A"
    fpath    = r.get("filepath") or state.current_file or ""

    top = ft.Row([
        back_btn(_go_home),
        D("Result", size=22, color=P.TEXT),
        ft.Container(expand=True),
        theme_icon_button(page, navigate),
    ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER)

    file_row = ft.Row([
        ft.Icon(ft.Icons.AUDIO_FILE_ROUNDED, color=P.FAINT, size=15),
        T(r.get("filename", "Unknown file"), size=13, color=P.TEXT_2, weight=ft.FontWeight.W_500),
    ], spacing=8)

    hero = ft.Container(
        ft.Column([
            ring(_type_icon(atype), col, soft, col, size=124, stroke=11, icon_size=46),
            ft.Container(height=16),
            T("DETECTED", size=11, color=P.MUTED, weight=ft.FontWeight.W_700, align=ft.TextAlign.CENTER),
            ft.Container(height=4),
            D(atype, size=34, color=P.TEXT, align=ft.TextAlign.CENTER),
            ft.Container(height=12),
            chip(atype, col, soft),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=0),
        bgcolor=P.SURFACE, border_radius=28,
        padding=ft.Padding(left=20, right=20, top=28, bottom=28),
        border=ft.Border.all(1, P.BORDER),
        alignment=ft.alignment.Alignment(0, 0),
    )

    info = group([
        list_row(ft.Icons.LANGUAGE_ROUNDED,
                 P.SPEECH if has_lang else P.MUTED,
                 P.SPEECH_SOFT if has_lang else P.SURFACE_2,
                 "Language", value=(lang if has_lang else "Not speech")),
        list_row(ft.Icons.TIMER_OUTLINED, P.BRAND, P.BRAND_SOFT,
                 "Duration", value=r.get("duration", "N/A")),
        list_row(ft.Icons.SCHEDULE_ROUNDED, P.TEXT_2, P.SURFACE_2,
                 "Analyzed", value=r.get("timestamp", "N/A")),
    ])
    # ── in-app audio player ───────────────────────────────────────────────────
    # ROOT CAUSE of all previous failures:
    #   play()/pause()/resume()/seek() all use _invoke_method which sends a
    #   message to Flutter and waits 30s for an ACK. The ACK never comes
    #   because the native audioplayers plugin's method channel is not active
    #   until the control is mounted with a real src at creation time.
    #
    # THE FIX: never call play()/pause()/resume() at all.
    #   - Use autoplay=True so the file plays the moment the control mounts.
    #   - To "pause": set volume=0 (instant, no round-trip needed).
    #   - To "resume": set volume=1 (instant, no round-trip needed).
    #   - To seek: we use a fresh Audio control (simplest, most reliable).
    #   - Track position via on_position_change; duration via on_duration_change.
    #   - e.duration  → ft.Duration object → .in_milliseconds
    #   - e.position  → plain int (ms) already

    play_icon_ref = ft.Ref[ft.Icon]()
    seek_ref      = ft.Ref[ft.Slider]()
    elapsed_ref   = ft.Ref[ft.Text]()
    total_ref     = ft.Ref[ft.Text]()
    status_ref    = ft.Ref[ft.Text]()

    seek_dragging = {"v": False}
    total_ms      = {"v": 0}
    # paused = muted via volume=0; playing = volume=1
    paused        = {"v": False}
    # target seek position (ms) to jump to once the fresh player reaches PLAYING
    pending_seek_ms = {"v": None}

    def _fmt_ms(ms):
        if not ms or ms < 0:
            return "0:00"
        total_s = int(ms) // 1000
        m, s = divmod(total_s, 60)
        return f"{m}:{s:02d}"

    def _set_status(text, color=None):
        if status_ref.current:
            status_ref.current.value = text
            status_ref.current.color = color or P.MUTED
            page.update()

    def _set_icon(is_playing: bool):
        state.is_playing = is_playing
        if play_icon_ref.current:
            play_icon_ref.current.icon = (
                ft.Icons.PAUSE_CIRCLE_ROUNDED if is_playing
                else ft.Icons.PLAY_CIRCLE_ROUNDED
            )
        page.update()

    def _current_player() -> fa.Audio | None:
        """Return the Audio service currently in page.services, if any."""
        for svc in list(page.services):
            if isinstance(svc, fa.Audio):
                return svc
        return None

    def _remove_player():
        """Remove any existing Audio services cleanly."""
        to_remove = [s for s in list(page.services) if isinstance(s, fa.Audio)]
        for s in to_remove:
            page.services.remove(s)
        if to_remove:
            page.update()

    def _make_player(path: str) -> fa.Audio:
        """Create a fresh Audio service with autoplay=True for the given path."""
        p = fa.Audio(
            src=os.path.abspath(path),
            autoplay=True,
            volume=1.0,
            release_mode=fa.ReleaseMode.STOP,
        )
        p.on_state_change    = _on_state_change
        p.on_duration_change = _on_duration_change
        p.on_position_change = _on_position_change
        return p

    async def _on_state_change(e):
        st = e.state
        if st == fa.AudioState.PLAYING:
            # If this PLAYING event follows a seek request, jump to the
            # requested position now that the native player is actually
            # active and able to accept a seek call.
            if pending_seek_ms["v"] is not None:
                target = pending_seek_ms["v"]
                pending_seek_ms["v"] = None
                player = _current_player()
                if player:
                    try:
                        await player.seek(ft.Duration(milliseconds=target))
                    except Exception:
                        pass
            if not paused["v"]:
                _set_icon(True)
                _set_status("Playing")
        elif st == fa.AudioState.PAUSED:
            _set_icon(False)
            _set_status("Paused")
        elif st in (fa.AudioState.COMPLETED, fa.AudioState.STOPPED):
            _set_icon(False)
            state.is_playing = False
            state.playing_path = None
            paused["v"] = False
            if st == fa.AudioState.COMPLETED:
                if seek_ref.current:
                    seek_ref.current.value = 0
                if elapsed_ref.current:
                    elapsed_ref.current.value = "0:00"
                page.update()

    async def _on_duration_change(e):
        try:
            ms = e.duration.in_milliseconds
        except AttributeError:
            ms = int(e.duration) if e.duration else 0
        total_ms["v"] = ms
        if seek_ref.current:
            seek_ref.current.max = max(ms, 1)
        if total_ref.current:
            total_ref.current.value = _fmt_ms(ms)
        page.update()

    async def _on_position_change(e):
        if seek_dragging["v"] or paused["v"]:
            return
        pos = int(e.position)
        if seek_ref.current:
            seek_ref.current.value = min(pos, max(seek_ref.current.max, 1))
        if elapsed_ref.current:
            elapsed_ref.current.value = _fmt_ms(pos)
        page.update()

    async def _toggle_play(_):
        if not fpath or not os.path.exists(fpath):
            _set_status("File not found", color=P.ERR)
            return

        player = _current_player()

        if player and state.playing_path == fpath:
            if paused["v"]:
                # Un-mute to resume
                player.volume = 1.0
                page.update()
                paused["v"] = False
                _set_icon(True)
                _set_status("Playing")
            else:
                # Mute to "pause" — no invoke_method needed
                player.volume = 0.0
                page.update()
                paused["v"] = True
                _set_icon(False)
                _set_status("Paused")
            return

        # New file — remove old player, mount fresh one with autoplay
        _remove_player()
        paused["v"] = False
        state.playing_path = fpath
        state.is_playing = True
        new_player = _make_player(fpath)
        page.services.append(new_player)
        page.update()
        _set_icon(True)
        _set_status("Playing")

    async def _on_seek_start(_):
        seek_dragging["v"] = True

    async def _on_seek_end(e):
        seek_dragging["v"] = False
        target_ms = int(e.control.value)
        if elapsed_ref.current:
            elapsed_ref.current.value = _fmt_ms(target_ms)
            page.update()
        # Mount a fresh autoplay player, then seek to target_ms once it
        # reports PLAYING (see _on_state_change). This avoids the broken
        # play()/seek() invoke_method round-trip on a not-yet-mounted control.
        _remove_player()
        paused["v"] = False
        pending_seek_ms["v"] = target_ms
        state.playing_path = fpath
        state.is_playing = True
        new_player = _make_player(fpath)
        page.services.append(new_player)
        page.update()
        _set_icon(True)
        _set_status("Seeking…")

    is_active   = state.is_playing and state.playing_path == fpath
    has_audio   = bool(fpath and os.path.exists(fpath))
    init_total  = total_ms["v"]

    play_icon_btn = ft.IconButton(
        icon=ft.Icons.PAUSE_CIRCLE_ROUNDED if is_active else ft.Icons.PLAY_CIRCLE_ROUNDED,
        icon_color=col, icon_size=44,
        ref=play_icon_ref,
        on_click=_toggle_play,
        style=ft.ButtonStyle(padding=0),
    )

    seek_bar = ft.Slider(
        ref=seek_ref,
        value=0, min=0, max=max(init_total, 1),
        active_color=col, inactive_color=P.SURFACE_2, thumb_color=col,
        on_change_start=_on_seek_start,
        on_change_end=_on_seek_end,
    )

    player_card = card(
        ft.Column([
            ft.Row([
                play_icon_btn,
                ft.Column([
                    T("Now playing", size=12, color=P.MUTED, weight=ft.FontWeight.W_600),
                    T(r.get("filename", "Audio"), size=14, color=P.TEXT,
                      weight=ft.FontWeight.W_700, font="Manrope"),
                ], spacing=2, expand=True),
            ], spacing=14, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ft.Container(height=4),
            seek_bar,
            ft.Row([
                ft.Text("0:00", ref=elapsed_ref, size=11, color=P.MUTED, font_family=BODY_FONT),
                ft.Container(expand=True),
                ft.Text(_fmt_ms(init_total), ref=total_ref, size=11, color=P.MUTED, font_family=BODY_FONT),
            ]),
            ft.Text("", ref=status_ref, size=11, color=P.MUTED, font_family=BODY_FONT),
        ], spacing=2),
        pad=ft.Padding(left=16, right=16, top=14, bottom=10),
    ) if has_audio else ft.Column([])

    # ── Profanity result card ─────────────────────────────────────────────────
    profanity_card_ref = ft.Ref[ft.Column]()
    profanity_btn_ref  = ft.Ref[ft.Container]()

    # Label → display name map
    _LABEL_NAMES = {
        "toxic":           "Toxic",
        "obscene":         "Obscene",
        "insult":          "Insult",
        "threat":          "Threat",
        "identity_attack": "Identity Attack",
        "sexual_explicit": "Sexual / Explicit",
        "not_hate":        "Not Hate",
        "neutral":         "Neutral",
    }

    def _score_bar(label: str, score: float) -> ft.Control:
        pct   = max(0.0, min(1.0, score))
        # colour: red ≥70 %, amber 40–70 %, green below 40
        if pct >= 0.70:
            bar_color = P.ERR
        elif pct >= 0.40:
            bar_color = P.WARN
        else:
            bar_color = P.OK             # low score on this label -> clear
        filled_w  = max(2, int(pct * 240))
        disp_name = _LABEL_NAMES.get(label, label.replace("_", " ").title())
        return ft.Column([
            ft.Row([
                T(disp_name, size=12, color=P.TEXT_2),
                ft.Container(expand=True),
                T(f"{pct*100:.1f}%", size=12,
                  color=bar_color, weight=ft.FontWeight.W_600),
            ]),
            ft.Stack([
                ft.Container(
                    height=5, bgcolor=P.SURFACE_2,
                    border_radius=4, expand=True,
                ),
                ft.Container(
                    width=filled_w, height=5,
                    bgcolor=bar_color, border_radius=4,
                ),
            ], height=5),
        ], spacing=5)

    def _build_profanity_result(pr: dict) -> ft.Control:
        is_profane = pr.get("is_profane", False)
        category   = pr.get("category", "Safe")
        score_pct  = pr.get("score", 0.0)
        all_scores = pr.get("all_scores", {})
        err        = pr.get("error")

        # ── Colours: red (confident detection) / amber (mild) / green (confident clean) ──
        if err:
            accent  = P.MUTED
            icon_fg = P.MUTED
            icon_bg = P.SURFACE_2
        elif is_profane:
            if score_pct >= 70:
                accent, icon_fg, icon_bg = P.ERR, P.ERR, P.ERR_SOFT        # confidently flagged
            else:
                accent, icon_fg, icon_bg = P.WARN, P.WARN, P.WARN_SOFT     # flagged, lower confidence -> mild
        else:
            if score_pct < 40:
                accent, icon_fg, icon_bg = P.OK, P.OK, P.OK_SOFT           # confidently clean
            else:
                accent, icon_fg, icon_bg = P.WARN, P.WARN, P.WARN_SOFT     # clean call, but borderline -> mild

        verdict_text = "Profanity Detected" if is_profane else "No Profanity Found"
        disp_cat     = _LABEL_NAMES.get(category, category.replace("_", " ").title())

        # ── Hero banner ───────────────────────────────────────────────────────
        # Large icon + verdict text, coloured background strip
        hero_icon = (
            ft.Icons.REMOVE_MODERATOR_ROUNDED if is_profane
            else ft.Icons.VERIFIED_USER_ROUNDED
        )
        hero_banner = ft.Container(
            ft.Row([
                ft.Container(
                    ft.Icon(hero_icon, color=icon_fg, size=32),
                    width=56, height=56,
                    bgcolor=icon_bg,          # light red circle behind icon
                    border_radius=18,
                    alignment=ft.alignment.Alignment(0, 0),
                ),
                ft.Container(width=14),
                ft.Column([
                    T("Content Safety", size=12, color=P.WHITE,
                      weight=ft.FontWeight.W_600),
                    ft.Container(height=2),
                    D(verdict_text, size=17, color=P.WHITE),
                ], spacing=0),
            ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
            bgcolor=accent,                 # solid red fill, not a tint
            border_radius=16,
            padding=ft.Padding(left=16, right=16, top=14, bottom=14),
        )

        if err:
            return card(ft.Column([
                hero_banner,
                ft.Container(height=4),
                T(f"Could not analyse: {err}", size=12, color=P.MUTED),
            ], spacing=10))

        # ── Stat row ──────────────────────────────────────────────────────────
        def _stat(label, value, val_color=None):
            return ft.Column([
                T(value, size=18, color=val_color or P.TEXT,
                  weight=ft.FontWeight.W_700),
                T(label, size=11, color=P.MUTED),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2)

        stat_row = ft.Container(
            ft.Row([
                _stat("Category",   disp_cat,          accent),
                ft.Container(width=1, height=36, bgcolor=P.BORDER),
                _stat("Confidence", f"{score_pct:.1f}%", accent),
            ], alignment=ft.MainAxisAlignment.SPACE_EVENLY,
               vertical_alignment=ft.CrossAxisAlignment.CENTER),
            bgcolor=P.SURFACE_2,
            border_radius=14,
            padding=ft.Padding(left=12, right=12, top=14, bottom=14),
        )

        # ── Score bars — only offensive labels, sorted descending ─────────────
        offensive = ["toxic","obscene","insult","threat",
                     "identity_attack","sexual_explicit"]
        sorted_scores = sorted(
            [(lbl, sc) for lbl, sc in all_scores.items() if lbl in offensive],
            key=lambda x: x[1], reverse=True,
        )

        bars_section = ft.Column([
            T("LABEL BREAKDOWN", size=10, color=P.MUTED,
              weight=ft.FontWeight.W_700),
            ft.Container(height=2),
            *[_score_bar(lbl, sc) for lbl, sc in sorted_scores],
        ], spacing=10)

        return card(ft.Column([
            hero_banner,
            ft.Container(height=8),
            stat_row,
            ft.Container(height=12),
            divider(),
            ft.Container(height=10),
            bars_section,
        ], spacing=0))

    async def _run_profanity(_):
        # Only works on Speech clips that have a filepath
        if not fpath or not os.path.exists(fpath):
            return
        if not _PROFANITY_READY:
            return

        # Disable button while running
        if profanity_btn_ref.current:
            profanity_btn_ref.current.opacity = 0.5
            profanity_btn_ref.current.disabled = True
            page.update()

        loop = asyncio.get_event_loop()
        try:
            with concurrent.futures.ThreadPoolExecutor() as pool:
                # translate_to_english then check_profanity
                from audio_pipeline import translate_to_english as _translate
                translated = await loop.run_in_executor(pool, _translate, fpath)
                pr = await loop.run_in_executor(pool, _check_profanity, translated)
        except Exception as ex:
            pr = {
                "is_profane": False, "category": "unavailable",
                "score": 0.0, "all_scores": {}, "error": str(ex),
            }

        if profanity_card_ref.current is not None:
            profanity_card_ref.current.controls = [_build_profanity_result(pr)]
            profanity_card_ref.current.visible  = True

        if profanity_btn_ref.current:
            profanity_btn_ref.current.opacity  = 1.0
            profanity_btn_ref.current.disabled = False

        page.update()

    # Only show profanity button for Speech clips
    show_profanity_btn = (atype == "Speech") and bool(fpath) and _PROFANITY_READY

    profanity_btn = ft.Container(
        ref=profanity_btn_ref,
        content=ft.Row([
            ft.Icon(ft.Icons.SHIELD_ROUNDED, color=P.ON_BRAND, size=18),
            T("Check Content Safety", size=14, color=P.ON_BRAND, weight=ft.FontWeight.W_700),
        ], spacing=10, alignment=ft.MainAxisAlignment.CENTER),
        on_click=_run_profanity,
        bgcolor=P.BRAND,
        border_radius=100,
        padding=ft.Padding(left=20, right=20, top=14, bottom=14),
        expand=True,
        animate_opacity=200,
    ) if show_profanity_btn else ft.Column([])

    profanity_result_area = ft.Column(
        ref=profanity_card_ref,
        controls=[],
        visible=False,
    )

    return ft.Column([
        top,
        file_row,
        hero,
        player_card,
        info,
        profanity_btn,
        profanity_result_area,
        ft.Container(height=2),
        pill_button("Analyze another", ft.Icons.ADD_ROUNDED, _go_home, expand=True),
    ], spacing=14, scroll=ft.ScrollMode.AUTO, expand=True)
# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN: HISTORY
# ═══════════════════════════════════════════════════════════════════════════════
def build_history(page, navigate):
    records = state.history_mgr.records
    header = big_header(f"{len(records)} analyses", "History", page, navigate)

    if records:
        rows = []
        for r in records:
            sub = r["audio_type"]
            if r.get("language"):
                sub += f" · {r['language']}"
            if r.get("timestamp"):
                sub += f" · {r['timestamp']}"
            rows.append(list_row(
                _type_icon(r["audio_type"]), _type_color(r["audio_type"]),
                _type_soft(r["audio_type"]), r.get("filename", "unknown"),
                subtitle=sub,
                trailing=chip(r["audio_type"], _type_color(r["audio_type"]),
                              _type_soft(r["audio_type"])),
            ))
        body = group(rows)
    else:
        body = empty_state(ft.Icons.HISTORY_ROUNDED, "No history yet",
                           "Analyze an audio file to see it here.")

    return ft.Column([header, body], spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)
# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN: LIVE FILTER  (mic → speaker, beeps profanity with a broadcast delay)
# ═══════════════════════════════════════════════════════════════════════════════
def build_live(page, navigate):
    live = state.live

    status_ref  = ft.Ref[ft.Container]()
    status_txt  = ft.Ref[ft.Text]()
    status_dot  = ft.Ref[ft.Container]()
    toggle_ref  = ft.Ref[ft.Container]()
    toggle_txt  = ft.Ref[ft.Text]()
    toggle_icon = ft.Ref[ft.Icon]()

    lang_val_ref  = ft.Ref[ft.Text]()
    played_ref    = ft.Ref[ft.Text]()
    beeped_ref    = ft.Ref[ft.Text]()
    buffer_ref    = ft.Ref[ft.Text]()
    passes_ref    = ft.Ref[ft.Text]()
    unverified_ref = ft.Ref[ft.Text]()
    overflows_ref  = ft.Ref[ft.Text]()
    underruns_ref  = ft.Ref[ft.Text]()
    backend_ref   = ft.Ref[ft.Text]()
    speaker_ref   = ft.Ref[ft.Text]()
    monitor_ref   = ft.Ref[ft.Text]()

    poll_flag = {"on": False}

    def _make_choice_btn(label, active, on_click):
        fg = P.ON_BRAND if active else P.TEXT_2
        return ft.Button(
            content=T(label, size=12, color=fg, weight=ft.FontWeight.W_700),
            on_click=on_click,
            style=ft.ButtonStyle(
                bgcolor={
                    ft.ControlState.DEFAULT: (P.BRAND if active else P.SURFACE_2),
                    ft.ControlState.HOVERED: (P.BRAND_STRONG if active else P.SURFACE_3),
                },
                shape=ft.RoundedRectangleBorder(radius=100),
                padding=ft.Padding(left=14, right=14, top=10, bottom=10),
            ),
        )

    def _apply_status(text, color):
        if status_txt.current:
            status_txt.current.value = text
            status_txt.current.color = color
        if status_dot.current:
            status_dot.current.bgcolor = color

    def _apply_toggle(running_or_starting):
        if toggle_txt.current and toggle_icon.current and toggle_ref.current:
            if running_or_starting:
                toggle_txt.current.value  = "Stop listening"
                toggle_icon.current.name  = ft.Icons.STOP_ROUNDED
                toggle_ref.current.bgcolor = P.ERR
            else:
                toggle_txt.current.value  = "Start listening"
                toggle_icon.current.name  = ft.Icons.MIC_ROUNDED
                toggle_ref.current.bgcolor = P.BRAND

    async def _poll_live():
        if poll_flag["on"]:
            return  # already polling
        poll_flag["on"] = True
        try:
            while poll_flag["on"]:
                if status_txt.current is None:
                    break  # screen no longer mounted

                if live.error:
                    _apply_status(f"Error: {live.error}", P.ERR)
                    _apply_toggle(False)
                    page.update()
                    break

                if live.starting:
                    _apply_status("Starting engine…", P.WARN)
                    _apply_toggle(True)

                elif live.is_alive():
                    s = live.stats()
                    _apply_status("Listening — filtering live audio", P.OK)
                    _apply_toggle(True)
                    if lang_val_ref.current:
                        lang_val_ref.current.value = s.get("language") or "detecting…"
                    if played_ref.current:
                        played_ref.current.value = f"{s.get('played_s', 0):.1f}s"
                    if beeped_ref.current:
                        beeped_ref.current.value = f"{s.get('beeped_s', 0):.2f}s"
                    if buffer_ref.current:
                        buffer_ref.current.value = str(s.get("buffer", 0))
                    if passes_ref.current:
                        passes_ref.current.value = str(s.get("passes", 0))
                    if unverified_ref.current:
                        unverified_ref.current.value = str(s.get("unverified", 0))
                    if overflows_ref.current:
                        overflows_ref.current.value = str(s.get("overflows", 0))
                    if underruns_ref.current:
                        underruns_ref.current.value = str(s.get("underruns", 0))
                    if backend_ref.current:
                        backend_ref.current.value = (
                            f"{s.get('backend', '—')} · delay {s.get('delay', 0):.1f}s"
                            f" · cushion {s.get('cushion_s', 0):.1f}s")
                    if speaker_ref.current and s.get("speaker"):
                        speaker_ref.current.value = f"Playing on: {s['speaker']}"
                    if monitor_ref.current and s.get("monitor"):
                        monitor_ref.current.value = f"Monitor file: {os.path.basename(s['monitor'])}"

                else:
                    _apply_status("Idle — not listening", P.MUTED)
                    _apply_toggle(False)
                    page.update()
                    break

                page.update()
                await asyncio.sleep(0.5)
        finally:
            poll_flag["on"] = False

    async def _toggle(_):
        if not _REALTIME_READY:
            _apply_status(f"Unavailable: {_REALTIME_ERR}", P.ERR)
            page.update()
            return

        if live.is_alive() or live.starting:
            live.stop()
            _apply_status("Stopping…", P.WARN)
            page.update()
            return

        force_lang = live.pending_force_lang
        cfg = RealtimeConfig(
            input="mic",
            play_output=True,
            force_language=None if force_lang in (None, "auto") else force_lang,
            # Beep censorship is ON: wordlist hits beep just the word, and
            # toxicity-net hits are localized to the offending word(s) too
            # (net_localize defaults True) — the whole block is only beeped
            # when no single word carries the toxicity.
            beep_enabled=True,
            unverified_action=live.pending_unverified,
            beep_granularity=live.pending_granularity,
            # A phone/laptop CPU is weaker than this module's baseline, and
            # it was running the toxicity transformer on every pass too —
            # "base" falls behind on that combination. "tiny" alone was
            # only half the fix: the transformer (a ~280M-param multilingual
            # model, sometimes called TWICE per block — once to classify
            # the window, again to localize the word) was still the
            # dominant per-pass cost either way. That's what was actually
            # causing analysis to fall behind, the broadcast delay to
            # ratchet upward, and audio to get muted for missing its
            # verdict in time — i.e. the delay and "packet loss" symptoms.
            # Off by default here; the wordlist alone is fast and still
            # catches literal profanity. Toggle it on in Session Settings
            # for extra contextual coverage if your device can keep up.
            transcribe_model="tiny",
            use_model_net=live.pending_use_tox,
        )
        live.start(cfg)
        _apply_status("Starting engine…", P.WARN)
        _apply_toggle(True)
        page.update()
        page.run_task(_poll_live)

    # kick off polling immediately if a session is already running (e.g. user
    # navigated away and back)
    if live.is_alive() or live.starting:
        page.run_task(_poll_live)

    if not _REALTIME_READY:
        avail_card = card(ft.Column([
            ft.Row([
                icon_square(ft.Icons.ERROR_OUTLINE_ROUNDED, P.ERR, P.ERR_SOFT),
                D("Live filter unavailable", size=16, color=P.TEXT),
            ], spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ft.Container(height=8),
            T(f"Could not load the realtime module: {_REALTIME_ERR}",
              size=12, color=P.MUTED),
        ]))
        return ft.Column([
            big_header("Mic → speaker", "Live Filter", page, navigate),
            avail_card,
        ], spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)

    is_running = live.is_alive() or live.starting

    status_card = ft.Container(
        ref=status_ref,
        content=ft.Row([
            ft.Container(ref=status_dot, width=10, height=10, border_radius=5,
                         bgcolor=(P.OK if is_running else P.MUTED)),
            ft.Text(ref=status_txt,
                    value=("Listening — filtering live audio" if is_running else "Idle — not listening"),
                    size=13, color=(P.OK if is_running else P.MUTED),
                    weight=ft.FontWeight.W_600, font_family=BODY_FONT),
        ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER),
        bgcolor=P.SURFACE_2, border_radius=100,
        padding=ft.Padding(left=14, right=16, top=10, bottom=10),
    )

    note = card(ft.Row([
        ft.Icon(ft.Icons.INFO_OUTLINE_ROUNDED, color=P.MUTED, size=16),
        T("Streams your microphone through a short broadcast delay so "
          "profanity detection has time to run before audio reaches your "
          "speaker. Needs a working mic/speaker on this device (desktop, "
          "via PortAudio).",
          size=12, color=P.MUTED),
    ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START), bg=P.SURFACE_2, border=False)

    toggle_btn = ft.Container(
        ref=toggle_ref,
        content=ft.Row([
            ft.Icon(ft.Icons.STOP_ROUNDED if is_running else ft.Icons.MIC_ROUNDED,
                    ref=toggle_icon, color=P.WHITE, size=20),
            ft.Text("Stop listening" if is_running else "Start listening",
                    ref=toggle_txt, size=15, color=P.WHITE,
                    weight=ft.FontWeight.W_700, font_family=BODY_FONT),
        ], spacing=10, alignment=ft.MainAxisAlignment.CENTER),
        on_click=_toggle,
        bgcolor=P.ERR if is_running else P.BRAND,
        border_radius=100,
        padding=ft.Padding(left=24, right=24, top=16, bottom=16),
        expand=True,
    )

    s0 = live.stats() if is_running else {}

    def _stat_line(icon, label, value, ref):
        return list_row(icon, P.BRAND, P.BRAND_SOFT, label,
                         trailing=ft.Text(value, ref=ref, size=14, color=P.TEXT,
                                          weight=ft.FontWeight.W_700, font_family=BODY_FONT))

    stats_group = group([
        _stat_line(ft.Icons.LANGUAGE_ROUNDED, "Detected language",
                   s0.get("language") or ("detecting…" if is_running else "—"), lang_val_ref),
        _stat_line(ft.Icons.GRAPHIC_EQ_ROUNDED, "Audio played",
                   f"{s0.get('played_s', 0):.1f}s", played_ref),
        _stat_line(ft.Icons.VOLUME_OFF_ROUNDED, "Time flagged (not censored yet)",
                   f"{s0.get('beeped_s', 0):.2f}s", beeped_ref),
        _stat_line(ft.Icons.LAYERS_ROUNDED, "Buffer depth",
                   str(s0.get("buffer", 0)), buffer_ref),
        _stat_line(ft.Icons.SPEED_ROUNDED, "Analysis passes",
                   str(s0.get("passes", 0)), passes_ref),
        _stat_line(ft.Icons.WARNING_AMBER_ROUNDED, "Unverified (muted)",
                   str(s0.get("unverified", 0)), unverified_ref),
        _stat_line(ft.Icons.MIC_OFF_ROUNDED, "Mic overflows (driver-level loss)",
                   str(s0.get("overflows", 0)), overflows_ref),
        _stat_line(ft.Icons.SIGNAL_CELLULAR_CONNECTED_NO_INTERNET_0_BAR_ROUNDED,
                   "Speaker underruns", str(s0.get("underruns", 0)), underruns_ref),
    ])

    backend_row = ft.Row([
        ft.Icon(ft.Icons.MEMORY_ROUNDED, color=P.MUTED, size=14),
        ft.Text(f"{s0.get('backend', '—')} · delay {s0.get('delay', 0):.1f}s" if is_running else "Not started",
                ref=backend_ref, size=12, color=P.MUTED, font_family=BODY_FONT),
    ], spacing=8)

    # Where the audio is actually going, and where to verify it afterwards —
    # this directly answers "where can I hear it": the live device it opened,
    # plus a wav file on disk that's an exact copy of what was played
    # (beeps included), independent of whether your speakers are audible.
    speaker_row = ft.Row([
        ft.Icon(ft.Icons.SPEAKER_ROUNDED, color=P.MUTED, size=14),
        ft.Text(f"Playing on: {s0['speaker']}" if s0.get("speaker") else "Speaker: not started",
                ref=speaker_ref, size=12, color=P.MUTED, font_family=BODY_FONT),
    ], spacing=8)

    monitor_row = ft.Row([
        ft.Icon(ft.Icons.SAVE_ROUNDED, color=P.MUTED, size=14),
        ft.Text(f"Monitor file: {os.path.basename(s0['monitor'])}" if s0.get("monitor")
                else "Monitor file: not started",
                ref=monitor_ref, size=12, color=P.MUTED, font_family=BODY_FONT),
    ], spacing=8)

    monitor_note = card(ft.Row([
        ft.Icon(ft.Icons.FOLDER_OPEN_ROUNDED, color=P.MUTED, size=16),
        T(f"Everything played is also saved to {LIVE_MONITOR_DIR} as it "
          f"happens — open the newest file there any time to check exactly "
          f"what was heard.",
          size=12, color=P.MUTED),
    ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START), bg=P.SURFACE_2, border=False)

    mock_warning = None
    if s0.get("backend") == "mock":
        mock_warning = card(ft.Row([
            ft.Icon(ft.Icons.ERROR_OUTLINE_ROUNDED, color=P.ERR, size=16),
            T("Running on the mock backend — no real speech model is loaded, "
              "so beeps are placed on a fixed timer, not on real words. "
              "Install faster-whisper (pip install faster-whisper) and restart "
              "to get real transcription.",
              size=12, color=P.ERR),
        ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START), bg=P.ERR_SOFT, border=False)

    def _mk_pick_handler(attr_name, value):
        async def _h(e):
            if live.is_alive() or live.starting:
                return  # settings lock while a session is running
            setattr(live, attr_name, value)
            await navigate("live")
        return _h

    lang_chips = ft.Row(
        [_make_choice_btn(name, live.pending_force_lang == code,
                          _mk_pick_handler("pending_force_lang", code))
         for code, name in LIVE_LANG_CHOICES],
        wrap=True, spacing=8, run_spacing=8,
    )

    def _mk_segment_for(attr_name, options, current_value):
        def _seg(value, label):
            active = current_value == value
            fg = P.ON_BRAND if active else P.TEXT_2
            return ft.Button(
                content=ft.Row([T(label, size=12, color=fg, weight=ft.FontWeight.W_700)],
                                tight=True, alignment=ft.MainAxisAlignment.CENTER),
                on_click=_mk_pick_handler(attr_name, value),
                expand=True,
                style=ft.ButtonStyle(
                    bgcolor={
                        ft.ControlState.DEFAULT: (P.BRAND if active else "transparent"),
                        ft.ControlState.HOVERED: (P.BRAND if active else P.SURFACE_3),
                    },
                    shape=ft.RoundedRectangleBorder(radius=100),
                    padding=ft.Padding(left=10, right=10, top=10, bottom=10),
                ),
            )
        return ft.Container(
            ft.Row([_seg(v, l) for v, l in options], spacing=4),
            bgcolor=P.SURFACE_2, border_radius=100, padding=6,
        )

    config_card = card(ft.Column([
        T("SESSION SETTINGS", size=11, color=P.MUTED, weight=ft.FontWeight.W_700),
        ft.Container(height=4),
        T("Locked while listening — stop the session to change these.",
          size=11, color=P.FAINT),
        ft.Container(height=10),
        T("Language", size=12, color=P.TEXT_2),
        ft.Container(height=6),
        lang_chips,
        ft.Container(height=14),
        T("Unverified audio (missed its verdict in time)", size=12, color=P.TEXT_2),
        ft.Container(height=6),
        _mk_segment_for("pending_unverified",
                        [("mute", "Mute"), ("beep", "Beep"), ("pass", "Pass")],
                        live.pending_unverified),
        ft.Container(height=14),
        T("Beep granularity", size=12, color=P.TEXT_2),
        ft.Container(height=6),
        _mk_segment_for("pending_granularity",
                        [("word", "Word (precise)"), ("window", "Whole chunk")],
                        live.pending_granularity),
        ft.Container(height=14),
        T("AI toxicity net", size=12, color=P.TEXT_2),
        ft.Container(height=6),
        _mk_segment_for("pending_use_tox",
                        [(False, "Off — fast"), (True, "On — slower")],
                        live.pending_use_tox),
        ft.Container(height=6),
        T("Off relies on the word list only (fast, keeps up in real time). "
          "On adds AI detection of unlisted/contextual profanity but is "
          "the most common cause of rising delay and muted audio on "
          "slower devices.", size=11, color=P.FAINT),
    ], spacing=0))

    if is_running:
        config_card.opacity = 0.5

    layout = [
        big_header("Mic → speaker", "Live Filter", page, navigate),
        status_card,
    ]
    if mock_warning is not None:
        layout.append(mock_warning)
    layout += [
        note,
        toggle_btn,
        stats_group,
        backend_row,
        speaker_row,
        monitor_row,
        monitor_note,
        config_card,
    ]
    return ft.Column(layout, spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)
# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN: ANALYTICS
# ═══════════════════════════════════════════════════════════════════════════════
def build_analytics(page, navigate):
    s = state.history_mgr.stats()
    total, speech, music, noise = s["total"], s["speech"], s["music"], s["noise"]

    tiles = ft.Column([
        ft.Row([
            stat_tile(total, "Total scans", P.BRAND, P.BRAND_SOFT,
                      ft.Icons.GRAPHIC_EQ_ROUNDED, brand=True),
            stat_tile(speech, "Speech", P.SPEECH, P.SPEECH_SOFT, ft.Icons.MIC_ROUNDED),
        ], spacing=12),
        ft.Row([
            stat_tile(music, "Music", P.MUSIC, P.MUSIC_SOFT, ft.Icons.MUSIC_NOTE_ROUNDED),
            stat_tile(noise, "Noise", P.NOISE, P.NOISE_SOFT, ft.Icons.WAVES_ROUNDED),
        ], spacing=12),
    ], spacing=12)

    seg = []
    for cnt, clr in [(speech, P.SPEECH), (music, P.MUSIC), (noise, P.NOISE)]:
        if cnt > 0:
            seg.append(ft.Container(expand=cnt, height=16, bgcolor=clr, border_radius=8))
    bar = ft.Row(seg, spacing=4) if seg else ft.Container(height=16, bgcolor=P.SURFACE_2, border_radius=8)

    def leg(label, cnt, clr):
        return ft.Row([
            ft.Container(width=8, height=8, border_radius=4, bgcolor=clr),
            T(label, size=12, color=P.MUTED),
            T(str(cnt), size=12, color=clr, weight=ft.FontWeight.W_700),
        ], spacing=6, tight=True)

    dist_card = card(ft.Column([
        T("TYPE DISTRIBUTION", size=11, color=P.MUTED, weight=ft.FontWeight.W_700),
        ft.Container(height=12),
        bar,
        ft.Container(height=14),
        ft.Row([leg("Speech", speech, P.SPEECH), leg("Music", music, P.MUSIC),
                leg("Noise", noise, P.NOISE)], spacing=18, wrap=True, run_spacing=8),
    ], spacing=0))

    lang_items = sorted(s["lang_dist"].items(), key=lambda x: -x[1])[:6]
    lang_rows = (
        [ft.Row([
            T(lang, size=14, color=P.TEXT_2),
            ft.Container(expand=True),
            chip(str(cnt), P.SPEECH, P.SPEECH_SOFT),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER) for lang, cnt in lang_items]
        if lang_items else [T("No speech detected yet", size=14, color=P.MUTED)]
    )
    lang_card = card(ft.Column([
        T("LANGUAGE BREAKDOWN", size=11, color=P.MUTED, weight=ft.FontWeight.W_700),
        *lang_rows,
    ], spacing=12))

    return ft.Column([
        big_header("Insights", "Analytics", page, navigate),
        tiles, dist_card, lang_card,
    ], spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)
# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN: SETTINGS
# ═══════════════════════════════════════════════════════════════════════════════
def build_settings(page, navigate):

    async def _export(_):
        content = state.history_mgr.export()
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        fpath = os.path.join(APP_DIR, f"audio_history_{ts}.txt")
        try:
            with open(fpath, "w") as f:
                f.write(content)
            page.show_dialog(ft.SnackBar(
                ft.Text(f"Saved to {fpath}", color=P.ON_BRAND), bgcolor=P.BRAND))
        except Exception as ex:
            page.show_dialog(ft.SnackBar(
                ft.Text(f"Export failed: {ex}", color=P.WHITE), bgcolor=P.ERR))
        page.update()

    async def _clear(_):
        async def _confirm(e):
            state.history_mgr.clear()
            page.pop_dialog()
            page.update()
            await navigate("settings")

        async def _cancel(e):
            page.pop_dialog()
            page.update()

        dlg = ft.AlertDialog(
            title=D("Clear all history?", size=18, color=P.TEXT),
            content=T("This cannot be undone.", size=13, color=P.TEXT_2),
            actions=[
                ft.TextButton("Cancel", on_click=_cancel, style=ft.ButtonStyle(color=P.MUTED)),
                ft.TextButton("Delete all", on_click=_confirm, style=ft.ButtonStyle(color=P.ERR)),
            ],
            bgcolor=P.SURFACE,
            shape=ft.RoundedRectangleBorder(radius=20),
        )
        page.show_dialog(dlg)
        page.update()

    appearance = ft.Column([
        section_title("Appearance"),
        card(ft.Column([
            ft.Row([
                icon_square(ft.Icons.PALETTE_OUTLINED, P.BRAND, P.BRAND_SOFT),
                ft.Column([
                    T("Theme", size=15, color=P.TEXT, weight=ft.FontWeight.W_700),
                    T("Choose light or dark", size=12, color=P.MUTED),
                ], spacing=2, expand=True),
            ], spacing=14, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ft.Container(height=14),
            theme_segment(page, navigate),
        ], spacing=0), pad=16),
    ], spacing=10)

    data = ft.Column([
        section_title("Data"),
        group([
            list_row(ft.Icons.DOWNLOAD_ROUNDED, P.BRAND, P.BRAND_SOFT,
                     "Export history", "Save analyses to a text file",
                     trailing=chevron_btn(_export, P.MUTED)),
            list_row(ft.Icons.DELETE_OUTLINE_ROUNDED, P.ERR, P.ERR_SOFT,
                     "Clear history", "Remove all stored analyses",
                     trailing=chevron_btn(_clear, P.ERR)),
        ]),
    ], spacing=10)

    return ft.Column([
        big_header("Preferences", "Settings", page, navigate),
        appearance, data,
    ], spacing=18, scroll=ft.ScrollMode.AUTO, expand=True)
# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN: ABOUT
# ═══════════════════════════════════════════════════════════════════════════════
def build_about(page, navigate):
    hero = ft.Container(
        ft.Column([
            ring(ft.Icons.GRAPHIC_EQ_ROUNDED, P.WHITE, P.BRAND, P.WHITE,
                 size=92, stroke=7, icon_size=34),
            ft.Container(height=16),
            D("Audio Classifier", size=24, color=P.ON_BRAND, align=ft.TextAlign.CENTER),
            ft.Container(height=4),
            T(f"v{APP_VERSION} · Speech / Music / Noise",
              size=12, color=P.ON_BRAND_MUTED, align=ft.TextAlign.CENTER),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=0),
        bgcolor=P.BRAND, border_radius=28,
        padding=ft.Padding(left=20, right=20, top=28, bottom=30),
        alignment=ft.alignment.Alignment(0, 0),
    )

    svm = spec_card("SVM Classifier", {
        "Purpose":  "Audio type classification",
        "Classes":  "Speech · Music · Noise",
        "Features": "57 (MFCC, Chroma, Spectral)",
        "Dataset":  "MUSAN", "Kernel": "RBF",
    }, P.BRAND, P.BRAND_SOFT, ft.Icons.MODEL_TRAINING_ROUNDED)

    whisper = spec_card("Whisper", {
        "Purpose":    "Language detection",
        "Model size": "Small",
        "Languages":  "10 supported",
        "Method":     "Log-mel spectrogram",
    }, P.MUSIC, P.MUSIC_SOFT, ft.Icons.TRANSLATE_ROUNDED)

    langs = card(ft.Column([
        T("SUPPORTED LANGUAGES", size=11, color=P.MUTED, weight=ft.FontWeight.W_700),
        ft.Container(height=10),
        ft.Row(wrap=True, spacing=8, run_spacing=8,
               controls=[chip(l, P.TEXT_2, P.SURFACE_2) for l in LANGUAGES]),
    ], spacing=0))

    about = ft.Column([
        section_title("About"),
        group([
            list_row(ft.Icons.INFO_OUTLINE_ROUNDED, P.TEXT_2, P.SURFACE_2,
                     "Version", "Audio Classifier",
                     trailing=chip(f"v{APP_VERSION}", P.TEXT_2, P.SURFACE_2)),
        ]),
    ], spacing=10)

    return ft.Column([
        big_header("Audio intelligence", "About", page, navigate),
        hero, svm, whisper, langs, about,
    ], spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)
# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════
def _make_theme(pal):
    return ft.Theme(
        color_scheme_seed=pal.BRAND,
        font_family=BODY_FONT,
        navigation_bar_theme=ft.NavigationBarTheme(
            label_text_style={
                ft.ControlState.DEFAULT: ft.TextStyle(
                    size=11, color=pal.NAV_LABEL,
                    weight=ft.FontWeight.W_600, font_family=BODY_FONT),
                ft.ControlState.SELECTED: ft.TextStyle(
                    size=11, color=pal.NAV_LABEL_SEL,
                    weight=ft.FontWeight.W_700, font_family=BODY_FONT),
            },
        ),
    )
async def main(page: ft.Page):
    page.title   = "Audio Classifier"
    page.padding = 0
    page.fonts   = {"Manrope": MANROPE_URL}

    page.theme      = _make_theme(LIGHT_PAL)
    page.dark_theme = _make_theme(DARK_PAL)

    _load_settings()
    set_palette(IS_DARK)
    apply_page_theme(page)

    state.file_picker = ft.FilePicker()
    page.services.append(state.file_picker)
    page.update()

    current_nav = {"v": 0}

    SCREEN_MAP = {
        "home": 0, "live": 1, "history": 2, "analytics": 3,
        "settings": 4, "about": 5, "result": None,
    }

    builders = {
        "home":      build_home,
        "result":    build_result,
        "live":      build_live,
        "history":   build_history,
        "analytics": build_analytics,
        "settings":  build_settings,
        "about":     build_about,
    }

    async def navigate(screen: str):
        state.current_screen = screen
        idx = SCREEN_MAP.get(screen, 0)
        if idx is not None:
            current_nav["v"] = idx
        content = builders.get(screen, build_home)(page, navigate)
        page.controls.clear()
        page.controls.append(
            ft.Column([
                ft.Container(
                    content=content, expand=True,
                    padding=ft.Padding(left=20, right=20, top=16, bottom=10),
                ),
                build_nav(current_nav["v"], on_nav_change),
            ], expand=True, spacing=0)
        )
        page.update()

    async def on_nav_change(e):
        idx_map = {0: "home", 1: "live", 2: "history", 3: "analytics",
                   4: "settings", 5: "about"}
        await navigate(idx_map.get(e.control.selected_index, "home"))

    await navigate("home")
ft.run(main)
