"""
Theme, design tokens, and shared UI components.

Visual identity: deep space / sound-wave aesthetic.
Primary:  Indigo-to-violet gradient feel (#5C6BC0 → #7E57C2)
Accent:   Electric cyan for interactive highlights (#00E5FF)
Surface:  Near-black with subtle blue tint (#0D1117, #161B27, #1E2436)
Danger:   Vivid coral (#FF5252)
"""
import flet as ft

# ── Semantic tokens ──────────────────────────────────────────────

PRIMARY       = "#5C6BC0"       # indigo
PRIMARY_LIGHT = "#7986CB"
ACCENT        = "#00E5FF"       # electric cyan
ACCENT_DIM    = "#00B8D4"

SPEECH_COLOR = "#42A5F5"        # sky blue
MUSIC_COLOR  = "#66BB6A"        # emerald
NOISE_COLOR  = "#FFA726"        # amber

SURFACE_0    = "#0D1117"        # deepest bg
SURFACE_1    = "#161B27"        # card bg
SURFACE_2    = "#1E2436"        # elevated card / chip

ON_PRIMARY   = "#FFFFFF"
ON_SURFACE   = "#E8EAF6"
ON_SURFACE_2 = "#9FA8DA"        # muted label
DIVIDER      = "#2A3050"

# ── Type + Icon maps ──────────────────────────────────────────────

TYPE_COLORS = {
    "Speech": SPEECH_COLOR,
    "Music":  MUSIC_COLOR,
    "Noise":  NOISE_COLOR,
}

TYPE_ICONS = {
    "Speech": ft.Icons.RECORD_VOICE_OVER_ROUNDED,
    "Music":  ft.Icons.MUSIC_NOTE_ROUNDED,
    "Noise":  ft.Icons.GRAPHIC_EQ_ROUNDED,
}

TYPE_GRADIENTS = {
    "Speech": [SPEECH_COLOR, "#1565C0"],
    "Music":  [MUSIC_COLOR,  "#1B5E20"],
    "Noise":  [NOISE_COLOR,  "#E65100"],
}

NAV_ROUTES = ["/", "/history", "/analytics", "/settings"]

LANGUAGE_PALETTE = [
    "#7C4DFF", "#00BCD4", "#43A047", "#F57C00",
    "#E91E63", "#00ACC1", "#8D6E63", "#5C6BC0",
    "#26A69A", "#EF5350", "#AB47BC", "#FFB300",
]


# ── Theme ─────────────────────────────────────────────────────────

def make_theme() -> ft.Theme:
    return ft.Theme(
        color_scheme_seed=PRIMARY,
        use_material3=True,
    )


# ── Helpers ───────────────────────────────────────────────────────

def type_color(audio_type: str | None) -> str:
    return TYPE_COLORS.get(audio_type or "", ON_SURFACE_2)


def type_icon(audio_type: str | None):
    return TYPE_ICONS.get(audio_type or "", ft.Icons.HELP_OUTLINE_ROUNDED)


# ── Navigation bar ────────────────────────────────────────────────

def build_nav_bar(page: ft.Page, selected_index: int) -> ft.NavigationBar:
    def on_change(e: ft.ControlEvent):
        page.go(NAV_ROUTES[e.control.selected_index])

    return ft.NavigationBar(
        selected_index=selected_index,
        bgcolor=SURFACE_1,
        indicator_color=PRIMARY,
        on_change=on_change,
        destinations=[
            ft.NavigationBarDestination(
                icon=ft.Icons.HOME_OUTLINED,
                selected_icon=ft.Icons.HOME_ROUNDED,
                label="Home",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.HISTORY_ROUNDED,
                label="History",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.INSIGHTS_OUTLINED,
                selected_icon=ft.Icons.INSIGHTS_ROUNDED,
                label="Stats",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.SETTINGS_OUTLINED,
                selected_icon=ft.Icons.SETTINGS_ROUNDED,
                label="Settings",
            ),
        ],
    )


# ── Reusable widgets ──────────────────────────────────────────────

def glass_card(content: ft.Control, padding: int = 16, border_radius: int = 16) -> ft.Container:
    """Card with surface-2 background and a subtle border."""
    return ft.Container(
        content=content,
        padding=padding,
        border_radius=border_radius,
        bgcolor=SURFACE_1,
        border=ft.border.all(1, DIVIDER),
    )


def stat_card(title: str, value: str, icon, color: str) -> ft.Container:
    return glass_card(
        content=ft.Column(
            spacing=8,
            controls=[
                ft.Container(
                    content=ft.Icon(icon, color=color, size=20),
                    padding=ft.padding.only(bottom=2),
                ),
                ft.Text(value, size=26, weight=ft.FontWeight.BOLD, color=ON_SURFACE),
                ft.Text(title, size=11, color=ON_SURFACE_2, weight=ft.FontWeight.W_500),
            ],
        ),
        padding=ft.padding.all(16),
    )


def section_label(text: str) -> ft.Text:
    return ft.Text(
        text.upper(),
        size=11,
        weight=ft.FontWeight.W_600,
        color=ON_SURFACE_2,
        letter_spacing=1.2,
    )


def accent_button(label: str, icon, on_click, expand: bool = False) -> ft.Container:
    """Full-width gradient-ish primary action button."""
    return ft.Container(
        expand=expand,
        content=ft.ElevatedButton(
            content=ft.Row(
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=8,
                controls=[
                    ft.Icon(icon, color=ON_PRIMARY, size=20),
                    ft.Text(label, color=ON_PRIMARY, weight=ft.FontWeight.W_600, size=15),
                ],
            ),
            style=ft.ButtonStyle(
                bgcolor=PRIMARY,
                shape=ft.RoundedRectangleBorder(radius=12),
                padding=ft.padding.symmetric(horizontal=20, vertical=14),
                elevation=0,
            ),
            on_click=on_click,
            expand=expand,
        ),
    )


def ghost_button(label: str, icon, on_click, expand: bool = False) -> ft.Container:
    return ft.Container(
        expand=expand,
        content=ft.OutlinedButton(
            content=ft.Row(
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=8,
                controls=[
                    ft.Icon(icon, color=PRIMARY_LIGHT, size=20),
                    ft.Text(label, color=PRIMARY_LIGHT, weight=ft.FontWeight.W_600, size=15),
                ],
            ),
            style=ft.ButtonStyle(
                side=ft.BorderSide(1.5, PRIMARY_LIGHT),
                shape=ft.RoundedRectangleBorder(radius=12),
                padding=ft.padding.symmetric(horizontal=20, vertical=14),
            ),
            on_click=on_click,
            expand=expand,
        ),
    )


def type_badge(audio_type: str) -> ft.Container:
    color = type_color(audio_type)
    return ft.Container(
        content=ft.Row(
            spacing=6,
            tight=True,
            controls=[
                ft.Icon(type_icon(audio_type), color=color, size=14),
                ft.Text(audio_type, color=color, size=12, weight=ft.FontWeight.W_600),
            ],
        ),
        padding=ft.padding.symmetric(horizontal=10, vertical=4),
        border_radius=20,
        bgcolor=f"{color}22",
        border=ft.border.all(1, f"{color}55"),
    )
