"""Upload screen — pick an audio file and analyze it."""
import flet as ft
from models import AppState, AnalysisRecord
import api_client
import storage as storage_mod
import theme as th


def build_view(page: ft.Page, state: AppState, file_picker: ft.FilePicker) -> ft.View:
    selected_name = ft.Ref[ft.Text]()
    status_text   = ft.Ref[ft.Text]()
    progress      = ft.Ref[ft.ProgressRing]()
    analyze_btn   = ft.Ref[ft.ElevatedButton]()
    drop_zone     = ft.Ref[ft.Container]()
    file_icon     = ft.Ref[ft.Icon]()

    picked = {"path": None, "bytes": None, "name": None}

    async def choose_file(e):
        files = await file_picker.pick_files(
            dialog_title="Select an audio file",
            allowed_extensions=["wav", "mp3", "m4a", "flac", "ogg"],
            allow_multiple=False,
            with_data=True,
        )
        if not files:
            return
        f = files[0]
        picked["path"]  = f.path
        picked["bytes"] = f.bytes
        picked["name"]  = f.name

        selected_name.current.value  = f.name
        selected_name.current.color  = th.ON_SURFACE
        selected_name.current.weight = ft.FontWeight.W_500
        status_text.current.value    = "Ready to analyze"
        status_text.current.color    = th.ACCENT_DIM
        analyze_btn.current.disabled = False

        drop_zone.current.border = ft.border.all(2, th.ACCENT)
        drop_zone.current.bgcolor = f"{th.ACCENT}11"
        file_icon.current.color  = th.ACCENT
        page.update()

    async def run_analysis(e):
        if not picked["name"]:
            return
        progress.current.visible     = True
        status_text.current.value    = "Analyzing…"
        status_text.current.color    = th.ON_SURFACE_2
        analyze_btn.current.disabled = True
        page.update()

        try:
            result = await api_client.analyze_audio(
                state.backend_url,
                file_path=picked["path"] if not picked["bytes"] else None,
                file_bytes=picked["bytes"],
                filename=picked["name"],
            )
            record = AnalysisRecord(
                audio_type=result.get("audio_type", "Unknown"),
                language=result.get("language"),
                confidence=result.get("confidence"),
                duration=result.get("duration", 0.0),
                filename=picked["name"],
            )
            state.add_record(record)
            state.current_result = record
            await storage_mod.save_history(page, state)
            page.go("/result")
        except api_client.ApiError as exc:
            progress.current.visible     = False
            status_text.current.value    = str(exc)
            status_text.current.color    = "#FF5252"
            analyze_btn.current.disabled = False
            page.update()

    drop_zone_content = ft.Container(
        ref=drop_zone,
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=14,
            controls=[
                ft.Icon(
                    ref=file_icon,
                    icon=ft.Icons.AUDIO_FILE_ROUNDED,
                    size=52,
                    color=th.ON_SURFACE_2,
                ),
                ft.Text("Tap to choose an audio file", color=th.ON_SURFACE, size=15, weight=ft.FontWeight.W_500),
                ft.Text(
                    "WAV · MP3 · M4A · FLAC · OGG",
                    color=th.ON_SURFACE_2,
                    size=11,
                    letter_spacing=1,
                ),
            ],
        ),
        padding=ft.padding.symmetric(vertical=36),
        border_radius=20,
        bgcolor=th.SURFACE_1,
        border=ft.border.all(2, th.DIVIDER),
        alignment=ft.alignment.center,
        on_click=choose_file,
        ink=True,
    )

    file_name_row = ft.Row(
        visible=True,
        spacing=8,
        controls=[
            ft.Icon(ft.Icons.ATTACH_FILE_ROUNDED, color=th.ON_SURFACE_2, size=16),
            ft.Text(
                ref=selected_name,
                value="No file selected",
                color=th.ON_SURFACE_2,
                size=13,
                italic=True,
                expand=True,
                max_lines=1,
                overflow=ft.TextOverflow.ELLIPSIS,
            ),
        ],
    )

    status_row = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=10,
        controls=[
            ft.ProgressRing(ref=progress, visible=False, width=16, height=16, stroke_width=2, color=th.ACCENT),
            ft.Text(ref=status_text, value="", size=13, color=th.ON_SURFACE_2),
        ],
    )

    return ft.View(
        route="/upload",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Upload Audio", color=th.ON_SURFACE, weight=ft.FontWeight.W_600),
            bgcolor=th.SURFACE_1,
            leading=ft.IconButton(
                icon=ft.Icons.ARROW_BACK_IOS_NEW_ROUNDED,
                icon_color=th.ON_SURFACE,
                on_click=lambda e: page.go("/"),
            ),
            elevation=0,
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.all(20),
                content=ft.Column(
                    spacing=20,
                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                    controls=[
                        ft.Container(height=8),
                        drop_zone_content,
                        file_name_row,
                        status_row,
                        ft.Container(expand=True),
                        th.accent_button(
                            "Analyze Audio",
                            ft.Icons.PLAY_ARROW_ROUNDED,
                            run_analysis,
                        ),
                    ],
                ),
            )
        ],
    )
