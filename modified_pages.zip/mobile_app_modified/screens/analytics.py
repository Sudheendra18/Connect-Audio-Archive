"""Analytics screen — charts and summary statistics."""
import flet as ft
from flet_charts import PieChart, PieChartSection

from models import AppState
import theme as th


def _bar(label: str, count: int, total: int, color: str) -> ft.Column:
    pct = (count / total * 100) if total > 0 else 0
    bar_width_pct = pct / 100  # 0–1

    return ft.Column(
        spacing=6,
        horizontal_alignment=ft.CrossAxisAlignment.START,
        controls=[
            ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    ft.Text(label, size=12, color=th.ON_SURFACE_2),
                    ft.Text(f"{count}  ({pct:.0f}%)", size=12, color=th.ON_SURFACE, weight=ft.FontWeight.W_500),
                ],
            ),
            ft.Stack(
                height=8,
                controls=[
                    ft.Container(height=8, border_radius=4, bgcolor=th.SURFACE_2),
                    ft.Container(
                        height=8,
                        border_radius=4,
                        bgcolor=color,
                        # width is fractional via expand trick — use a row trick instead
                    ) if pct == 0 else ft.FractionallySizedBox(
                        width_factor=bar_width_pct,
                        child=ft.Container(height=8, border_radius=4, bgcolor=color),
                    ),
                ],
            ),
        ],
    )


def _simple_bar(label: str, count: int, total: int, color: str) -> ft.Column:
    """Simple bar chart row without FractionallySizedBox (better compat)."""
    pct = int((count / total * 100)) if total > 0 else 0

    return ft.Column(
        spacing=6,
        controls=[
            ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    ft.Text(label, size=13, color=th.ON_SURFACE_2),
                    ft.Text(
                        f"{count}  ({pct}%)",
                        size=13,
                        color=th.ON_SURFACE,
                        weight=ft.FontWeight.W_600,
                    ),
                ],
            ),
            ft.Container(
                height=8,
                border_radius=4,
                bgcolor=th.SURFACE_2,
                content=ft.Row(
                    expand=True,
                    controls=[
                        ft.Container(
                            height=8,
                            border_radius=4,
                            bgcolor=color,
                            # Use expand fractionally — not natively possible, simulate with width
                            width=None,
                            expand=pct if pct > 0 else None,
                        ),
                        ft.Container(expand=max(100 - pct, 0)) if pct < 100 else ft.Container(),
                    ],
                ),
            ),
        ],
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    counts    = state.counts()
    total     = len(state.history)
    lang_dist = state.language_distribution()

    # ── Summary stat cards ────────────────────────────────────────
    stats_row = ft.Row(
        spacing=8,
        controls=[
            ft.Expanded(flex=1, content=th.stat_card("Total", str(total), ft.Icons.ANALYTICS_ROUNDED, th.PRIMARY_LIGHT)),
            ft.Expanded(flex=1, content=th.stat_card("Speech", str(counts.get("Speech", 0)), ft.Icons.RECORD_VOICE_OVER_ROUNDED, th.SPEECH_COLOR)),
            ft.Expanded(flex=1, content=th.stat_card("Music", str(counts.get("Music", 0)), ft.Icons.MUSIC_NOTE_ROUNDED, th.MUSIC_COLOR)),
            ft.Expanded(flex=1, content=th.stat_card("Noise", str(counts.get("Noise", 0)), ft.Icons.GRAPHIC_EQ_ROUNDED, th.NOISE_COLOR)),
        ],
    )

    # ── Type distribution bars ────────────────────────────────────
    type_bars = th.glass_card(
        content=ft.Column(
            spacing=14,
            controls=[
                th.section_label("Type Distribution"),
                ft.Container(height=2),
                _simple_bar("Speech", counts.get("Speech", 0), total, th.SPEECH_COLOR),
                _simple_bar("Music",  counts.get("Music",  0), total, th.MUSIC_COLOR),
                _simple_bar("Noise",  counts.get("Noise",  0), total, th.NOISE_COLOR),
            ],
        ),
        padding=ft.padding.all(16),
    )

    # ── Language pie chart ────────────────────────────────────────
    if lang_dist:
        sorted_langs = sorted(lang_dist.items(), key=lambda kv: -kv[1])
        sections     = []
        legend_items = []

        for i, (lang, count) in enumerate(sorted_langs):
            color = th.LANGUAGE_PALETTE[i % len(th.LANGUAGE_PALETTE)]
            pct   = count / sum(lang_dist.values()) * 100
            sections.append(
                PieChartSection(
                    value=float(count),
                    title=f"{pct:.0f}%",
                    title_style=ft.TextStyle(size=11, color=th.ON_PRIMARY, weight=ft.FontWeight.BOLD),
                    color=color,
                    radius=65,
                )
            )
            legend_items.append(
                ft.Row(
                    spacing=8,
                    controls=[
                        ft.Container(width=10, height=10, bgcolor=color, border_radius=3),
                        ft.Text(f"{lang}", size=12, color=th.ON_SURFACE, expand=True),
                        ft.Text(f"{count}", size=12, color=th.ON_SURFACE_2, weight=ft.FontWeight.W_600),
                    ],
                )
            )

        lang_chart = PieChart(
            sections=sections,
            sections_space=2,
            center_space_radius=34,
        )

        lang_section = th.glass_card(
            content=ft.Column(
                spacing=14,
                controls=[
                    th.section_label("Language Distribution"),
                    ft.Container(
                        height=200,
                        content=lang_chart,
                    ),
                    ft.Container(
                        content=ft.Column(spacing=8, controls=legend_items),
                        padding=ft.padding.only(top=4),
                    ),
                ],
            ),
            padding=ft.padding.all(16),
        )
    else:
        lang_section = th.glass_card(
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10,
                controls=[
                    ft.Icon(ft.Icons.LANGUAGE_ROUNDED, size=36, color=th.ON_SURFACE_2),
                    ft.Text(
                        "Language data will appear once speech files are analyzed",
                        color=th.ON_SURFACE_2,
                        size=12,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ],
            ),
            padding=ft.padding.symmetric(vertical=28, horizontal=16),
        )

    return ft.View(
        route="/analytics",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Analytics", color=th.ON_SURFACE, weight=ft.FontWeight.W_600),
            bgcolor=th.SURFACE_1,
            elevation=0,
        ),
        navigation_bar=th.build_nav_bar(page, 2),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.all(16),
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[stats_row, type_bars, lang_section],
                ),
            )
        ],
    )
