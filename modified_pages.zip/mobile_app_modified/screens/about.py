"""About screen — model details, pipeline, and app version."""
import flet as ft
import theme as th

APP_VERSION = "1.0.0"


def _tech_card(icon, color: str, title: str, lines: list[str]) -> ft.Container:
    return th.glass_card(
        content=ft.Column(
            spacing=10,
            controls=[
                ft.Row(
                    spacing=10,
                    controls=[
                        ft.Container(
                            content=ft.Icon(icon, color=color, size=20),
                            width=36,
                            height=36,
                            border_radius=10,
                            bgcolor=f"{color}22",
                            alignment=ft.alignment.center,
                        ),
                        ft.Text(title, size=14, weight=ft.FontWeight.W_600, color=th.ON_SURFACE),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                ft.Container(height=1, bgcolor=th.DIVIDER),
                *[
                    ft.Row(
                        spacing=8,
                        vertical_alignment=ft.CrossAxisAlignment.START,
                        controls=[
                            ft.Container(
                                width=5,
                                height=5,
                                border_radius=3,
                                bgcolor=color,
                                margin=ft.margin.only(top=5),
                            ),
                            ft.Text(line, size=12, color=th.ON_SURFACE_2, expand=True),
                        ],
                    )
                    for line in lines
                ],
            ],
        ),
        padding=ft.padding.all(16),
    )


def build_view(page: ft.Page, state) -> ft.View:
    # ── App identity ──────────────────────────────────────────────
    app_header = ft.Container(
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
            controls=[
                ft.Container(
                    content=ft.Icon(ft.Icons.GRAPHIC_EQ_ROUNDED, color=th.ACCENT, size=36),
                    width=72,
                    height=72,
                    border_radius=24,
                    bgcolor=f"{th.ACCENT}22",
                    border=ft.border.all(1, f"{th.ACCENT}55"),
                    alignment=ft.alignment.center,
                    shadow=ft.BoxShadow(blur_radius=24, color=f"{th.ACCENT}33"),
                ),
                ft.Text("Audio Classifier", size=22, weight=ft.FontWeight.BOLD, color=th.ON_SURFACE),
                ft.Container(
                    content=ft.Text(
                        f"Version {APP_VERSION}",
                        size=11,
                        color=th.ON_SURFACE_2,
                        weight=ft.FontWeight.W_500,
                        letter_spacing=0.5,
                    ),
                    padding=ft.padding.symmetric(horizontal=10, vertical=4),
                    border_radius=20,
                    bgcolor=th.SURFACE_2,
                ),
            ],
        ),
        padding=ft.padding.symmetric(vertical=24),
    )

    svm_card = _tech_card(
        ft.Icons.PSYCHOLOGY_ROUNDED,
        th.PRIMARY_LIGHT,
        "Audio Type Classifier — SVM",
        [
            "Trained on the MUSAN dataset (music, noise, speech).",
            "57 features per clip via Librosa: 40 MFCC (20 mean + 20 std), 12 chroma means, spectral centroid, bandwidth, rolloff, zero-crossing rate, and RMS energy.",
            "Compared against Logistic Regression, KNN, Random Forest, Extra Trees, and XGBoost. SVM achieved the best accuracy.",
        ],
    )

    whisper_card = _tech_card(
        ft.Icons.TRANSLATE_ROUNDED,
        th.SPEECH_COLOR,
        "Language Detection — Whisper Small",
        [
            "OpenAI Whisper (small model), runs only when audio is classified as Speech.",
            "Covers: English, French, German, Hindi, Kannada, Korean, Malayalam, Spanish, Tamil, Telugu, Urdu.",
            "Replaces a custom classifier — Whisper generalized significantly better across accents and noise levels.",
        ],
    )

    pipeline_card = _tech_card(
        ft.Icons.ACCOUNT_TREE_ROUNDED,
        th.MUSIC_COLOR,
        "Pipeline",
        [
            "Audio File → SVM Classifier → audio_type",
            "If audio_type == Speech → Whisper Small → language",
            "Music and Noise clips skip language detection entirely.",
            "Backend: FastAPI + Librosa. Mobile: Flet 0.85.",
        ],
    )

    return ft.View(
        route="/about",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("About", color=th.ON_SURFACE, weight=ft.FontWeight.W_600),
            bgcolor=th.SURFACE_1,
            elevation=0,
            leading=ft.IconButton(
                icon=ft.Icons.ARROW_BACK_IOS_NEW_ROUNDED,
                icon_color=th.ON_SURFACE,
                on_click=lambda e: page.go("/settings"),
            ),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.all(16),
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                    controls=[app_header, svm_card, whisper_card, pipeline_card],
                ),
            )
        ],
    )
