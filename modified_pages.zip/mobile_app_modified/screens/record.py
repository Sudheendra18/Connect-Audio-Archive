"""Record screen — microphone capture with live timer."""
import asyncio
import os
import time
import flet as ft
from flet_audio_recorder import AudioRecorder, AudioRecorderConfiguration, AudioEncoder

from models import AppState, AnalysisRecord
import api_client
import storage as storage_mod
import theme as th


def _waveform_bars(n: int = 9) -> list[ft.Container]:
    heights = [10, 18, 28, 36, 42, 36, 28, 18, 10]
    bars = []
    for h in heights[:n]:
        bars.append(
            ft.Container(
                width=4,
                height=h,
                border_radius=2,
                bgcolor=th.ACCENT,
            )
        )
    return bars


def build_view(page: ft.Page, state: AppState, audio_recorder: AudioRecorder) -> ft.View:
    mic_icon_ref   = ft.Ref[ft.Icon]()
    mic_container  = ft.Ref[ft.Container]()
    record_btn     = ft.Ref[ft.ElevatedButton]()
    status_text    = ft.Ref[ft.Text]()
    timer_text     = ft.Ref[ft.Text]()
    progress       = ft.Ref[ft.ProgressRing]()
    analyze_btn    = ft.Ref[ft.ElevatedButton]()
    wave_row       = ft.Ref[ft.Row]()

    rec_state = {"recording": False, "path": None, "start": 0.0}

    async def tick():
        while rec_state["recording"]:
            elapsed = time.time() - rec_state["start"]
            mins, secs = divmod(int(elapsed), 60)
            timer_text.current.value = f"{mins:02d}:{secs:02d}"
            page.update()
            await asyncio.sleep(1)

    async def toggle_recording(e):
        if not rec_state["recording"]:
            has_perm = await audio_recorder.has_permission()
            if not has_perm:
                status_text.current.value = "Microphone permission denied"
                status_text.current.color = "#FF5252"
                page.update()
                return

            tmp_dir = await page.storage_paths.get_temporary_directory()
            output_path = os.path.join(tmp_dir, f"recording_{int(time.time())}.wav")

            await audio_recorder.start_recording(
                output_path=output_path,
                configuration=AudioRecorderConfiguration(encoder=AudioEncoder.WAV),
            )
            rec_state["recording"] = True
            rec_state["start"]     = time.time()
            rec_state["path"]      = output_path

            mic_icon_ref.current.color     = "#FF5252"
            mic_container.current.bgcolor  = "#FF525222"
            mic_container.current.border   = ft.border.all(2, "#FF5252")
            record_btn.current.text        = "Stop Recording"
            record_btn.current.icon        = ft.Icons.STOP_ROUNDED
            status_text.current.value      = "Recording…"
            status_text.current.color      = "#FF5252"
            analyze_btn.current.disabled   = True
            wave_row.current.visible       = True
            page.update()
            page.run_task(tick)
        else:
            path = await audio_recorder.stop_recording()
            rec_state["recording"] = False
            rec_state["path"]      = path or rec_state["path"]

            mic_icon_ref.current.color     = th.ACCENT
            mic_container.current.bgcolor  = f"{th.ACCENT}22"
            mic_container.current.border   = ft.border.all(2, th.ACCENT)
            record_btn.current.text        = "Start Recording"
            record_btn.current.icon        = ft.Icons.MIC_ROUNDED
            status_text.current.value      = "Recording captured — ready to analyze"
            status_text.current.color      = th.ACCENT_DIM
            analyze_btn.current.disabled   = False
            wave_row.current.visible       = False
            page.update()

    async def run_analysis(e):
        if not rec_state["path"]:
            return
        progress.current.visible     = True
        status_text.current.value    = "Analyzing…"
        status_text.current.color    = th.ON_SURFACE_2
        analyze_btn.current.disabled = True
        page.update()

        try:
            filename = os.path.basename(rec_state["path"])
            result = await api_client.analyze_audio(
                state.backend_url,
                file_path=rec_state["path"],
                filename=filename,
            )
            record = AnalysisRecord(
                audio_type=result.get("audio_type", "Unknown"),
                language=result.get("language"),
                confidence=result.get("confidence"),
                duration=result.get("duration", 0.0),
                filename=filename,
            )
            state.add_record(record)
            state.current_result = record
            await storage_mod.save_history(page, state)
            page.go("/result")
        except api_client.ApiError as exc:
            progress.current.visible     = False
            status_text.current.value    = str(exc)
            status_text.current.color    = "#FF5252"
            analyze_btn.current.disabled = False
            page.update()

    return ft.View(
        route="/record",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Record Audio", color=th.ON_SURFACE, weight=ft.FontWeight.W_600),
            bgcolor=th.SURFACE_1,
            leading=ft.IconButton(
                icon=ft.Icons.ARROW_BACK_IOS_NEW_ROUNDED,
                icon_color=th.ON_SURFACE,
                on_click=lambda e: page.go("/"),
            ),
            elevation=0,
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.all(20),
                content=ft.Column(
                    spacing=24,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Container(height=16),

                        # Mic orb
                        ft.Container(
                            ref=mic_container,
                            content=ft.Icon(
                                ref=mic_icon_ref,
                                icon=ft.Icons.MIC_ROUNDED,
                                size=52,
                                color=th.ACCENT,
                            ),
                            width=96,
                            height=96,
                            border_radius=48,
                            bgcolor=f"{th.ACCENT}22",
                            border=ft.border.all(2, th.ACCENT),
                            alignment=ft.alignment.center,
                        ),

                        # Timer
                        ft.Text(
                            ref=timer_text,
                            value="00:00",
                            size=42,
                            weight=ft.FontWeight.BOLD,
                            color=th.ON_SURFACE,
                            font_family="monospace",
                        ),

                        # Waveform indicator (visible during recording)
                        ft.Row(
                            ref=wave_row,
                            visible=False,
                            spacing=4,
                            alignment=ft.MainAxisAlignment.CENTER,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=_waveform_bars(),
                        ),

                        # Status
                        ft.Text(
                            ref=status_text,
                            value="Tap to start recording",
                            color=th.ON_SURFACE_2,
                            size=13,
                        ),

                        # Record button
                        ft.ElevatedButton(
                            ref=record_btn,
                            text="Start Recording",
                            icon=ft.Icons.MIC_ROUNDED,
                            style=ft.ButtonStyle(
                                bgcolor=th.PRIMARY,
                                color=th.ON_PRIMARY,
                                shape=ft.RoundedRectangleBorder(radius=12),
                                padding=ft.padding.symmetric(horizontal=28, vertical=14),
                                elevation=0,
                            ),
                            on_click=toggle_recording,
                        ),

                        ft.Container(expand=True),

                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=10,
                            controls=[
                                ft.ProgressRing(
                                    ref=progress,
                                    visible=False,
                                    width=16,
                                    height=16,
                                    stroke_width=2,
                                    color=th.ACCENT,
                                ),
                            ],
                        ),

                        th.accent_button(
                            "Analyze Recording",
                            ft.Icons.PLAY_ARROW_ROUNDED,
                            run_analysis,
                        ),
                    ],
                ),
            )
        ],
    )
