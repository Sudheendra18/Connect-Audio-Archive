"""Settings screen — theme, backend URL, data management."""
import flet as ft
from models import AppState
import storage as storage_mod
import theme as th


def _settings_row(icon, color: str, title: str, subtitle: str, trailing: ft.Control, on_click=None) -> ft.Container:
    return ft.Container(
        content=ft.Row(
            spacing=14,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Container(
                    content=ft.Icon(icon, color=color, size=20),
                    width=40,
                    height=40,
                    border_radius=12,
                    bgcolor=f"{color}22",
                    alignment=ft.alignment.center,
                ),
                ft.Column(
                    expand=True,
                    spacing=2,
                    controls=[
                        ft.Text(title, size=14, color=th.ON_SURFACE, weight=ft.FontWeight.W_500),
                        ft.Text(subtitle, size=11, color=th.ON_SURFACE_2),
                    ],
                ),
                trailing,
            ],
        ),
        padding=ft.padding.symmetric(horizontal=14, vertical=12),
        on_click=on_click,
        ink=True if on_click else False,
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    backend_field = ft.Ref[ft.TextField]()
    theme_switch  = ft.Ref[ft.Switch]()

    async def on_theme_change(e: ft.ControlEvent):
        state.dark_mode = e.control.value
        page.theme_mode = ft.ThemeMode.DARK if state.dark_mode else ft.ThemeMode.LIGHT
        await storage_mod.save_theme(page, state)
        page.update()

    async def save_backend_url(e):
        state.backend_url = backend_field.current.value or state.backend_url
        await storage_mod.save_backend_url(page, state)
        page.open(ft.SnackBar(content=ft.Text("Backend URL saved"), bgcolor=th.SURFACE_2))
        page.update()

    async def export_history(e):
        if not state.history:
            page.open(ft.SnackBar(content=ft.Text("No history to export"), bgcolor=th.SURFACE_2))
            page.update()
            return
        await page.clipboard.set(state.history_to_json())
        page.open(ft.SnackBar(content=ft.Text("History copied to clipboard as JSON"), bgcolor=th.SURFACE_2))
        page.update()

    async def do_clear_history(e):
        page.close_dialog()
        await storage_mod.clear_history(page, state)
        page.open(ft.SnackBar(content=ft.Text("History cleared"), bgcolor=th.SURFACE_2))
        page.go("/settings")

    def cancel_clear(e):
        page.close_dialog()

    def confirm_clear_history(e):
        page.open(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Clear all history?", color=th.ON_SURFACE),
                content=ft.Text(
                    "All saved analyses on this device will be deleted. This cannot be undone.",
                    color=th.ON_SURFACE_2,
                    size=13,
                ),
                bgcolor=th.SURFACE_1,
                actions=[
                    ft.TextButton("Cancel", style=ft.ButtonStyle(color=th.ON_SURFACE_2), on_click=cancel_clear),
                    ft.TextButton("Clear", style=ft.ButtonStyle(color="#FF5252"), on_click=do_clear_history),
                ],
                actions_alignment=ft.MainAxisAlignment.END,
            )
        )

    def go_about(e):
        page.go("/about")

    # ── Appearance section ────────────────────────────────────────
    appearance_card = th.glass_card(
        content=ft.Column(
            spacing=0,
            controls=[
                th.section_label("Appearance"),
                ft.Container(height=10),
                _settings_row(
                    ft.Icons.DARK_MODE_ROUNDED,
                    th.PRIMARY_LIGHT,
                    "Dark Mode",
                    "Switch between dark and light theme",
                    ft.Switch(
                        ref=theme_switch,
                        value=state.dark_mode,
                        active_color=th.PRIMARY,
                        on_change=on_theme_change,
                    ),
                ),
            ],
        ),
        padding=ft.padding.all(16),
    )

    # ── Network section ───────────────────────────────────────────
    network_card = th.glass_card(
        content=ft.Column(
            spacing=10,
            controls=[
                th.section_label("Network"),
                ft.Container(height=4),
                ft.Text("Backend URL", size=13, color=th.ON_SURFACE_2),
                ft.TextField(
                    ref=backend_field,
                    value=state.backend_url,
                    hint_text="http://192.168.1.50:8000",
                    hint_style=ft.TextStyle(color=th.ON_SURFACE_2),
                    text_style=ft.TextStyle(color=th.ON_SURFACE, size=13),
                    bgcolor=th.SURFACE_2,
                    border_color=th.DIVIDER,
                    focused_border_color=th.PRIMARY_LIGHT,
                    border_radius=10,
                    content_padding=ft.padding.symmetric(horizontal=12, vertical=10),
                    border_width=1,
                ),
                ft.Container(
                    content=ft.ElevatedButton(
                        "Save URL",
                        icon=ft.Icons.SAVE_ROUNDED,
                        style=ft.ButtonStyle(
                            bgcolor=th.PRIMARY,
                            color=th.ON_PRIMARY,
                            shape=ft.RoundedRectangleBorder(radius=10),
                            elevation=0,
                            padding=ft.padding.symmetric(horizontal=20, vertical=12),
                        ),
                        on_click=save_backend_url,
                    ),
                    alignment=ft.alignment.center_right,
                ),
            ],
        ),
        padding=ft.padding.all(16),
    )

    # ── Data section ──────────────────────────────────────────────
    data_card = th.glass_card(
        content=ft.Column(
            spacing=0,
            controls=[
                ft.Container(
                    padding=ft.padding.only(bottom=10),
                    content=th.section_label("Data"),
                ),
                _settings_row(
                    ft.Icons.IOS_SHARE_ROUNDED,
                    th.ACCENT_DIM,
                    "Export History",
                    "Copy all analyses as JSON to clipboard",
                    ft.Icon(ft.Icons.CHEVRON_RIGHT_ROUNDED, color=th.ON_SURFACE_2, size=18),
                    on_click=export_history,
                ),
                ft.Container(height=1, bgcolor=th.DIVIDER, margin=ft.margin.only(left=54)),
                _settings_row(
                    ft.Icons.DELETE_OUTLINE_ROUNDED,
                    "#FF5252",
                    "Clear History",
                    "Remove all saved analyses from device",
                    ft.Icon(ft.Icons.CHEVRON_RIGHT_ROUNDED, color=th.ON_SURFACE_2, size=18),
                    on_click=confirm_clear_history,
                ),
            ],
        ),
        padding=ft.padding.all(16),
    )

    # ── About row ─────────────────────────────────────────────────
    about_card = th.glass_card(
        content=_settings_row(
            ft.Icons.INFO_OUTLINE_ROUNDED,
            th.PRIMARY_LIGHT,
            "About",
            "Models, pipeline, and version info",
            ft.Icon(ft.Icons.CHEVRON_RIGHT_ROUNDED, color=th.ON_SURFACE_2, size=18),
            on_click=go_about,
        ),
        padding=ft.padding.symmetric(vertical=4),
    )

    return ft.View(
        route="/settings",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Settings", color=th.ON_SURFACE, weight=ft.FontWeight.W_600),
            bgcolor=th.SURFACE_1,
            elevation=0,
        ),
        navigation_bar=th.build_nav_bar(page, 3),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.all(16),
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[
                        appearance_card,
                        network_card,
                        data_card,
                        about_card,
                    ],
                ),
            )
        ],
    )
