"""History screen — full list of past analyses."""
import flet as ft
from models import AppState
import theme as th


def _history_tile(r) -> ft.Container:
    color = th.type_color(r.audio_type)
    icon  = th.type_icon(r.audio_type)
    conf  = f"{r.confidence * 100:.0f}%" if r.confidence is not None else "—"
    lang  = r.language or "—"

    return ft.Container(
        content=ft.Row(
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                # Icon orb
                ft.Container(
                    content=ft.Icon(icon, color=color, size=20),
                    width=44,
                    height=44,
                    border_radius=14,
                    bgcolor=f"{color}22",
                    alignment=ft.alignment.center,
                ),
                # Main info
                ft.Column(
                    expand=True,
                    spacing=4,
                    controls=[
                        ft.Text(
                            r.filename,
                            size=13,
                            weight=ft.FontWeight.W_500,
                            color=th.ON_SURFACE,
                            max_lines=1,
                            overflow=ft.TextOverflow.ELLIPSIS,
                        ),
                        ft.Row(
                            spacing=6,
                            controls=[
                                th.type_badge(r.audio_type),
                                ft.Text(
                                    f"· {lang}  · {conf}  · {r.duration:.1f}s",
                                    size=11,
                                    color=th.ON_SURFACE_2,
                                ),
                            ],
                        ),
                    ],
                ),
                # Time
                ft.Text(r.display_time, size=10, color=th.ON_SURFACE_2),
            ],
        ),
        padding=ft.padding.symmetric(horizontal=16, vertical=14),
        border_radius=14,
        bgcolor=th.SURFACE_1,
        border=ft.border.all(1, th.DIVIDER),
        margin=ft.margin.only(bottom=8),
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    if not state.history:
        body = ft.Container(
            padding=ft.padding.symmetric(vertical=60),
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=12,
                controls=[
                    ft.Icon(ft.Icons.HISTORY_ROUNDED, size=52, color=th.ON_SURFACE_2),
                    ft.Text("No history yet", color=th.ON_SURFACE_2, size=15, weight=ft.FontWeight.W_500),
                    ft.Text(
                        "Analyses you run will appear here.",
                        color=th.ON_SURFACE_2,
                        size=12,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ],
            ),
        )
    else:
        tiles = [_history_tile(r) for r in state.history]
        body = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO, controls=tiles)

    return ft.View(
        route="/history",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text(f"History  ({len(state.history)})", color=th.ON_SURFACE, weight=ft.FontWeight.W_600),
            bgcolor=th.SURFACE_1,
            elevation=0,
        ),
        navigation_bar=th.build_nav_bar(page, 1),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.all(16),
                content=body,
            )
        ],
    )
