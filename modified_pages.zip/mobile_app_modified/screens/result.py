"""Result screen — vivid display of the analysis outcome."""
import flet as ft
from models import AppState
import theme as th


def _detail_row(label: str, value: str, icon) -> ft.Row:
    return ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        controls=[
            ft.Row(
                spacing=10,
                controls=[
                    ft.Container(
                        content=ft.Icon(icon, size=16, color=th.ON_SURFACE_2),
                        width=30,
                    ),
                    ft.Text(label, size=13, color=th.ON_SURFACE_2),
                ],
            ),
            ft.Text(value, size=13, weight=ft.FontWeight.W_600, color=th.ON_SURFACE),
        ],
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    record = state.current_result

    if record is None:
        body = ft.Container(
            padding=40,
            content=ft.Text("No result available.", color=th.ON_SURFACE_2),
        )
    else:
        color   = th.type_color(record.audio_type)
        icon    = th.type_icon(record.audio_type)
        conf    = f"{record.confidence * 100:.1f}%" if record.confidence is not None else "—"
        lang    = record.language or "—"

        # ── Hero badge ────────────────────────────────────────────
        hero_badge = ft.Container(
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=14,
                controls=[
                    ft.Container(
                        content=ft.Icon(icon, color=th.ON_PRIMARY, size=44),
                        width=88,
                        height=88,
                        border_radius=44,
                        bgcolor=color,
                        alignment=ft.alignment.center,
                        shadow=ft.BoxShadow(
                            spread_radius=0,
                            blur_radius=32,
                            color=f"{color}66",
                        ),
                    ),
                    ft.Text(
                        record.audio_type,
                        size=28,
                        weight=ft.FontWeight.BOLD,
                        color=th.ON_SURFACE,
                    ),
                    th.type_badge(record.audio_type),
                    ft.Text(
                        record.filename,
                        size=12,
                        color=th.ON_SURFACE_2,
                        max_lines=1,
                        overflow=ft.TextOverflow.ELLIPSIS,
                    ),
                ],
            ),
            padding=ft.padding.symmetric(vertical=28),
        )

        # ── Detail card ───────────────────────────────────────────
        detail_card = th.glass_card(
            content=ft.Column(
                spacing=0,
                controls=[
                    _detail_row("Language", lang, ft.Icons.LANGUAGE_ROUNDED),
                    ft.Container(height=1, bgcolor=th.DIVIDER, margin=ft.margin.symmetric(vertical=10)),
                    _detail_row("Confidence", conf, ft.Icons.VERIFIED_ROUNDED),
                    ft.Container(height=1, bgcolor=th.DIVIDER, margin=ft.margin.symmetric(vertical=10)),
                    _detail_row("Duration", f"{record.duration:.1f}s", ft.Icons.TIMER_ROUNDED),
                    ft.Container(height=1, bgcolor=th.DIVIDER, margin=ft.margin.symmetric(vertical=10)),
                    _detail_row("Analyzed", record.display_time, ft.Icons.SCHEDULE_ROUNDED),
                ],
            ),
            padding=ft.padding.symmetric(horizontal=16, vertical=14),
        )

        body = ft.Column(
            spacing=16,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[hero_badge, detail_card],
        )

    action_row = ft.Row(
        spacing=10,
        controls=[
            th.ghost_button("History", ft.Icons.HISTORY_ROUNDED, lambda e: page.go("/history"), expand=True),
            th.accent_button("Done", ft.Icons.CHECK_ROUNDED, lambda e: page.go("/"), expand=True),
        ],
    )

    return ft.View(
        route="/result",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Analysis Result", color=th.ON_SURFACE, weight=ft.FontWeight.W_600),
            bgcolor=th.SURFACE_1,
            elevation=0,
            leading=ft.IconButton(
                icon=ft.Icons.ARROW_BACK_IOS_NEW_ROUNDED,
                icon_color=th.ON_SURFACE,
                on_click=lambda e: page.go("/"),
            ),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.all(20),
                content=ft.Column(
                    spacing=20,
                    scroll=ft.ScrollMode.AUTO,
                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                    controls=[body, action_row],
                ),
            )
        ],
    )
