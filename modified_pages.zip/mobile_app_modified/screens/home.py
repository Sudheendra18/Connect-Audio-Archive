"""Home screen — hero quick-actions, live stats, recent analyses."""
import flet as ft
from models import AppState
import theme as th


def _quick_action_card(icon, label: str, subtitle: str, color: str, on_click) -> ft.Container:
    return ft.Container(
        expand=True,
        content=ft.Container(
            content=ft.Column(
                spacing=10,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Container(
                        content=ft.Icon(icon, color=color, size=28),
                        width=52,
                        height=52,
                        border_radius=16,
                        bgcolor=f"{color}22",
                        alignment=ft.alignment.center,
                    ),
                    ft.Text(label, color=th.ON_SURFACE, size=14, weight=ft.FontWeight.W_600),
                    ft.Text(subtitle, color=th.ON_SURFACE_2, size=11, text_align=ft.TextAlign.CENTER),
                ],
            ),
            padding=ft.padding.symmetric(vertical=18, horizontal=12),
            border_radius=16,
            bgcolor=th.SURFACE_1,
            border=ft.border.all(1, th.DIVIDER),
            on_click=on_click,
            ink=True,
        ),
    )


def _recent_tile(r, page: ft.Page) -> ft.Container:
    color = th.type_color(r.audio_type)
    icon = th.type_icon(r.audio_type)
    lang_part = f"  ·  {r.language}" if r.language else ""
    conf_part = f"  ·  {r.confidence * 100:.0f}%" if r.confidence is not None else ""

    return ft.Container(
        content=ft.Row(
            spacing=12,
            controls=[
                ft.Container(
                    content=ft.Icon(icon, color=color, size=18),
                    width=40,
                    height=40,
                    border_radius=12,
                    bgcolor=f"{color}22",
                    alignment=ft.alignment.center,
                ),
                ft.Column(
                    spacing=3,
                    expand=True,
                    controls=[
                        ft.Text(
                            r.filename,
                            size=13,
                            weight=ft.FontWeight.W_500,
                            color=th.ON_SURFACE,
                            max_lines=1,
                            overflow=ft.TextOverflow.ELLIPSIS,
                        ),
                        ft.Text(
                            f"{r.audio_type}{lang_part}{conf_part}",
                            size=11,
                            color=th.ON_SURFACE_2,
                        ),
                    ],
                ),
                ft.Text(r.display_time, size=10, color=th.ON_SURFACE_2),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=ft.padding.symmetric(horizontal=14, vertical=12),
        border_radius=12,
        bgcolor=th.SURFACE_2,
        margin=ft.margin.only(bottom=8),
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    counts = state.counts()
    total  = len(state.history)

    # ── Hero banner ───────────────────────────────────────────────
    hero = ft.Container(
        content=ft.Column(
            spacing=4,
            controls=[
                ft.Row(
                    spacing=10,
                    controls=[
                        ft.Container(
                            content=ft.Icon(ft.Icons.GRAPHIC_EQ_ROUNDED, color=th.ACCENT, size=28),
                            width=44,
                            height=44,
                            border_radius=14,
                            bgcolor=f"{th.ACCENT}22",
                            alignment=ft.alignment.center,
                        ),
                        ft.Column(
                            spacing=1,
                            controls=[
                                ft.Text("Audio Classifier", size=18, weight=ft.FontWeight.BOLD, color=th.ON_SURFACE),
                                ft.Text("SVM · Whisper · ML Pipeline", size=11, color=th.ON_SURFACE_2),
                            ],
                        ),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
            ],
        ),
        padding=ft.padding.symmetric(horizontal=16, vertical=14),
        bgcolor=th.SURFACE_1,
        border=ft.border.only(bottom=ft.border.BorderSide(1, th.DIVIDER)),
    )

    # ── Stats row ─────────────────────────────────────────────────
    stats_row = ft.Row(
        spacing=8,
        controls=[
            ft.Expanded(
                flex=1,
                content=th.stat_card("Total", str(total), ft.Icons.ANALYTICS_ROUNDED, th.PRIMARY_LIGHT),
            ),
            ft.Expanded(
                flex=1,
                content=th.stat_card("Speech", str(counts.get("Speech", 0)), ft.Icons.RECORD_VOICE_OVER_ROUNDED, th.SPEECH_COLOR),
            ),
            ft.Expanded(
                flex=1,
                content=th.stat_card("Music", str(counts.get("Music", 0)), ft.Icons.MUSIC_NOTE_ROUNDED, th.MUSIC_COLOR),
            ),
            ft.Expanded(
                flex=1,
                content=th.stat_card("Noise", str(counts.get("Noise", 0)), ft.Icons.GRAPHIC_EQ_ROUNDED, th.NOISE_COLOR),
            ),
        ],
    )

    # ── Quick actions ─────────────────────────────────────────────
    quick_actions = ft.Row(
        spacing=10,
        controls=[
            _quick_action_card(
                ft.Icons.UPLOAD_FILE_ROUNDED, "Upload", "Pick from storage",
                th.PRIMARY_LIGHT, lambda e: page.go("/upload"),
            ),
            _quick_action_card(
                ft.Icons.MIC_ROUNDED, "Record", "Use microphone",
                th.ACCENT_DIM, lambda e: page.go("/record"),
            ),
        ],
    )

    # ── Recent section ────────────────────────────────────────────
    recent = state.history[:5]
    if recent:
        recent_tiles = [_recent_tile(r, page) for r in recent]
        recent_body = ft.Column(spacing=0, controls=recent_tiles)
    else:
        recent_body = ft.Container(
            padding=ft.padding.symmetric(vertical=28),
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10,
                controls=[
                    ft.Icon(ft.Icons.QUEUE_MUSIC_ROUNDED, size=40, color=th.ON_SURFACE_2),
                    ft.Text("No analyses yet", color=th.ON_SURFACE_2, size=13),
                    ft.Text(
                        "Upload or record your first audio clip to get started.",
                        color=th.ON_SURFACE_2,
                        size=11,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ],
            ),
        )

    recent_header = ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        controls=[
            th.section_label("Recent Analyses"),
            ft.TextButton(
                "See all",
                style=ft.ButtonStyle(color=th.ACCENT),
                on_click=lambda e: page.go("/history"),
            ) if recent else ft.Container(),
        ],
    )

    scroll_body = ft.Column(
        spacing=16,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            stats_row,
            quick_actions,
            recent_header,
            recent_body,
        ],
    )

    return ft.View(
        route="/",
        bgcolor=th.SURFACE_0,
        padding=0,
        navigation_bar=th.build_nav_bar(page, 0),
        controls=[
            ft.Column(
                expand=True,
                spacing=0,
                controls=[
                    hero,
                    ft.Container(
                        expand=True,
                        padding=ft.padding.all(16),
                        content=scroll_body,
                    ),
                ],
            )
        ],
    )
