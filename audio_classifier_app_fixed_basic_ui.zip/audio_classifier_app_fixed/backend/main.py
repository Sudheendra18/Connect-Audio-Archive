"""
FastAPI backend for the Audio Classifier app.

The app works in two modes:
1) If your original stage1 pipeline exists in backend/stage1, it will use it.
2) Otherwise it falls back to a light heuristic classifier so the UI still works.
"""
from __future__ import annotations

import os
import shutil
import tempfile
import uuid
from datetime import datetime, timezone
from typing import Optional

import librosa
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from pipeline_adapter import process_audio

app = FastAPI(title="Audio Classification & Language Detection API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalysisResult(BaseModel):
    audio_type: str
    language: Optional[str] = None
    confidence: Optional[float] = None
    duration: float = 0.0
    filename: str = "unknown"
    timestamp: str


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/analyze", response_model=AnalysisResult)
async def analyze(file: UploadFile = File(...)):
    suffix = os.path.splitext(file.filename or "")[1] or ".wav"
    tmp_path = os.path.join(tempfile.gettempdir(), f"{uuid.uuid4().hex}{suffix}")

    try:
        with open(tmp_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        try:
            duration = float(librosa.get_duration(path=tmp_path))
        except Exception:
            duration = 0.0

        try:
            result = process_audio(tmp_path)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Pipeline error: {exc}") from exc

        return AnalysisResult(
            audio_type=str(result.get("audio_type") or "Unknown"),
            language=result.get("language"),
            confidence=result.get("confidence"),
            duration=float(result.get("duration", duration) or duration),
            filename=file.filename or "unknown",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
