"""
Fallback-friendly adapter for the API layer.

If your original stage1 pipeline files are present in backend/stage1/,
the adapter will try to use them. Otherwise it falls back to a small
heuristic classifier so the app still works end to end.
"""
from __future__ import annotations

import os
import sys
from typing import Any

import librosa
import numpy as np

STAGE1_DIR = os.path.join(os.path.dirname(__file__), "stage1")
if STAGE1_DIR not in sys.path:
    sys.path.append(STAGE1_DIR)

try:
    from audio_pipeline import process_audio as _pipeline_fn  # type: ignore
except Exception:
    _pipeline_fn = None


def _clip01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def _fallback_process_audio(audio_path: str) -> dict[str, Any]:
    y, sr = librosa.load(audio_path, sr=16000, mono=True, duration=20)

    if y.size == 0:
        return {"audio_type": "Unknown", "language": None, "confidence": 0.0}

    duration = float(len(y) / sr)
    rms = float(np.mean(librosa.feature.rms(y=y)[0]))
    zcr = float(np.mean(librosa.feature.zero_crossing_rate(y)[0]))
    centroid = float(np.mean(librosa.feature.spectral_centroid(y=y, sr=sr)[0]))
    flatness = float(np.mean(librosa.feature.spectral_flatness(y=y)[0]))
    tempo, _ = librosa.beat.beat_track(y=y, sr=sr)
    tempo = float(tempo or 0.0)

    # Very small heuristic, only used when your trained pipeline is absent.
    noise_score = _clip01((flatness - 0.15) / 0.55 + max(0.0, 0.08 - rms) * 3.0)
    music_score = _clip01((tempo / 180.0) * 0.45 + (centroid / 5000.0) * 0.35 + (1.0 - flatness) * 0.2)
    speech_score = _clip01(1.0 - max(noise_score, music_score))

    scores = {
        "Noise": noise_score,
        "Music": music_score,
        "Speech": speech_score,
    }
    audio_type = max(scores, key=scores.get)
    confidence = scores[audio_type]

    # No language model is bundled in this lightweight fallback.
    language = None

    return {
        "audio_type": audio_type,
        "language": language,
        "confidence": round(confidence, 4),
        "duration": round(duration, 2),
        "rms": round(rms, 6),
        "zcr": round(zcr, 6),
        "centroid": round(centroid, 2),
        "flatness": round(flatness, 6),
        "tempo": round(tempo, 2),
        "backend_mode": "fallback",
    }


def process_audio(audio_path: str) -> dict[str, Any]:
    if _pipeline_fn is not None:
        result = _pipeline_fn(audio_path)
        if not isinstance(result, dict):
            raise RuntimeError("audio_pipeline.process_audio() must return a dict")
        result.setdefault("confidence", None)
        result.setdefault("language", None)
        return result
    return _fallback_process_audio(audio_path)
