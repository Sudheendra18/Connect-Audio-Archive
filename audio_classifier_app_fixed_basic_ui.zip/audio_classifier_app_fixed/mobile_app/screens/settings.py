"""Settings screen."""
from __future__ import annotations

import flet as ft

from models import AppState
import storage as storage_mod
import theme as th


def build_view(page: ft.Page, state: AppState) -> ft.View:
    url_field = ft.TextField(label="Backend URL", value=state.backend_url, expand=True)
    theme_switch = ft.Switch(value=state.dark_mode)
    info_text = ft.Text("", color=th.ON_SURFACE_2, size=12)

    def save_settings(e):
        state.backend_url = url_field.value.strip() or state.backend_url
        state.dark_mode = bool(theme_switch.value)
        storage_mod.save_state(state)
        page.theme_mode = ft.ThemeMode.DARK if state.dark_mode else ft.ThemeMode.LIGHT
        page.bgcolor = th.SURFACE_0 if state.dark_mode else th.BG
        info_text.value = "Saved."
        page.update()

    def clear_history(e):
        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Clear all history?", color=th.ON_SURFACE),
            content=ft.Text("This removes all saved analyses from this device.", color=th.ON_SURFACE_2, size=12),
        )

        def close_dialog(ev):
            dlg.open = False
            page.update()

        def confirm_clear(ev):
            storage_mod.clear_history(state)
            dlg.open = False
            page.update()
            page.go("/history")

        dlg.actions = [
            ft.TextButton("Cancel", on_click=close_dialog),
            ft.TextButton("Clear", on_click=confirm_clear),
        ]
        page.dialog = dlg
        dlg.open = True
        page.update()

    return ft.View(
        route="/settings",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Settings", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(icon=ft.Icons.ARROW_BACK_ROUNDED, on_click=lambda e: page.go("/")),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[
                        th.glass_card(
                            content=ft.Column(
                                spacing=12,
                                controls=[
                                    ft.Text("Appearance", size=14, weight=ft.FontWeight.W_700, color=th.ON_SURFACE),
                                    ft.Row(
                                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                                        controls=[
                                            ft.Text("Dark mode", color=th.ON_SURFACE),
                                            theme_switch,
                                        ],
                                    ),
                                ],
                            ),
                            padding=ft.Padding.all(16),
                        ),
                        th.glass_card(
                            content=ft.Column(
                                spacing=12,
                                controls=[
                                    ft.Text("Backend", size=14, weight=ft.FontWeight.W_700, color=th.ON_SURFACE),
                                    url_field,
                                    ft.Row(
                                        spacing=10,
                                        controls=[
                                            ft.ElevatedButton(text="Save", icon=ft.Icons.SAVE_ROUNDED, on_click=save_settings),
                                            ft.OutlinedButton(text="Clear history", icon=ft.Icons.DELETE_OUTLINE_ROUNDED, on_click=clear_history),
                                        ],
                                    ),
                                    info_text,
                                ],
                            ),
                            padding=ft.Padding.all(16),
                        ),
                        th.glass_card(
                            content=ft.Column(
                                spacing=8,
                                controls=[
                                    ft.Text("About the app", size=14, weight=ft.FontWeight.W_700, color=th.ON_SURFACE),
                                    ft.Text("The backend can use your trained stage1 pipeline if you add it under backend/stage1. Without that, the app still works with a lightweight fallback classifier.", color=th.ON_SURFACE_2, size=12),
                                ],
                            ),
                            padding=ft.Padding.all(16),
                        ),
                    ],
                ),
            )
        ],
    )
