from . import home, upload, record, result, history, analytics, settings, about
