"""About screen."""
from __future__ import annotations

import flet as ft
import theme as th


def build_view(page: ft.Page, state) -> ft.View:
    return ft.View(
        route="/about",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("About", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(icon=ft.Icons.ARROW_BACK_ROUNDED, on_click=lambda e: page.go("/")),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    scroll=ft.ScrollMode.AUTO,
                    spacing=16,
                    controls=[
                        th.glass_card(
                            content=ft.Column(
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                spacing=10,
                                controls=[
                                    th.neon_icon_container(ft.Icons.AUDIOTRACK_ROUNDED, th.PRIMARY, size=24, container_size=56, border_radius=18),
                                    ft.Text("Audio Classifier", size=22, weight=ft.FontWeight.BOLD, color=th.ON_SURFACE),
                                    ft.Text("A simple, stable front end for upload, recording, history, analytics, and settings.", size=12, color=th.ON_SURFACE_2, text_align=ft.TextAlign.CENTER),
                                ],
                            ),
                            padding=ft.Padding.all(18),
                        ),
                        th.glass_card(
                            content=ft.Text(
                                "If you add your trained stage1 pipeline files to backend/stage1, the backend will use them. Otherwise it falls back to a small heuristic classifier so the app still runs.",
                                color=th.ON_SURFACE_2,
                                size=12,
                            ),
                            padding=ft.Padding.all(16),
                        ),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[ft.ElevatedButton(text="Home", on_click=lambda e: page.go("/"))],
                        ),
                    ],
                ),
            )
        ],
    )
