"""Result screen."""
from __future__ import annotations

import flet as ft
from models import AppState
import theme as th


def _detail_row(label: str, value: str) -> ft.Row:
    return ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        controls=[
            ft.Text(label, color=th.ON_SURFACE_2, size=12),
            ft.Text(value, color=th.ON_SURFACE, size=12, weight=ft.FontWeight.W_700),
        ],
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    record = state.current_result

    if record is None:
        body = ft.Text("No result available yet.", color=th.ON_SURFACE_2)
    else:
        color = th.type_color(record.audio_type)
        conf = f"{record.confidence * 100:.1f}%" if record.confidence is not None else "—"
        lang = record.language or "Unknown"

        body = ft.Column(
            spacing=14,
            controls=[
                th.glass_card(
                    content=ft.Column(
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=10,
                        controls=[
                            th.neon_icon_container(th.type_icon(record.audio_type), color, size=24, container_size=60, border_radius=20),
                            ft.Text(record.audio_type, size=24, weight=ft.FontWeight.BOLD, color=th.ON_SURFACE),
                            ft.Text(f"Confidence: {conf}", color=th.ON_SURFACE_2, size=12),
                        ],
                    ),
                    padding=ft.Padding.all(18),
                ),
                th.glass_card(
                    content=ft.Column(
                        spacing=8,
                        controls=[
                            ft.Text("Details", size=14, weight=ft.FontWeight.W_700, color=th.ON_SURFACE),
                            _detail_row("Language", lang),
                            _detail_row("Duration", f"{record.duration:.2f}s"),
                            _detail_row("File", record.filename),
                            _detail_row("Time", record.display_time),
                        ],
                    ),
                    padding=ft.Padding.all(16),
                ),
                ft.Row(
                    spacing=10,
                    controls=[
                        ft.ElevatedButton(text="Upload another", icon=ft.Icons.UPLOAD_FILE_ROUNDED, on_click=lambda e: page.go("/upload")),
                        ft.OutlinedButton(text="Home", on_click=lambda e: page.go("/")),
                    ],
                ),
            ],
        )

    return ft.View(
        route="/result",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Result", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(icon=ft.Icons.ARROW_BACK_ROUNDED, on_click=lambda e: page.go("/")),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    scroll=ft.ScrollMode.AUTO,
                    spacing=16,
                    controls=[body],
                ),
            )
        ],
    )
