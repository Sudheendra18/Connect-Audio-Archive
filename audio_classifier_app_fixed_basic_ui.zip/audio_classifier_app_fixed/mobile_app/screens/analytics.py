"""Analytics screen."""
from __future__ import annotations

import flet as ft
from models import AppState
import theme as th


def _bar_row(label: str, value: int, max_value: int) -> ft.Column:
    fraction = 0 if max_value == 0 else value / max_value
    return ft.Column(
        spacing=4,
        controls=[
            ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    ft.Text(label, size=12, color=th.ON_SURFACE),
                    ft.Text(str(value), size=12, weight=ft.FontWeight.W_700, color=th.ON_SURFACE_2),
                ],
            ),
            ft.ProgressBar(value=fraction, height=8),
        ],
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    counts = state.counts()
    lang = state.language_distribution()
    max_count = max(counts.values()) if counts else 0

    lang_controls = []
    if lang:
        lang_max = max(lang.values())
        for key, val in sorted(lang.items(), key=lambda x: (-x[1], x[0])):
            lang_controls.append(_bar_row(key, val, lang_max))
    else:
        lang_controls.append(ft.Text("No language data yet.", color=th.ON_SURFACE_2, size=12))

    return ft.View(
        route="/analytics",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Analytics", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(icon=ft.Icons.ARROW_BACK_ROUNDED, on_click=lambda e: page.go("/")),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    scroll=ft.ScrollMode.AUTO,
                    spacing=16,
                    controls=[
                        th.glass_card(
                            content=ft.Column(
                                spacing=10,
                                controls=[
                                    ft.Text("Audio type breakdown", size=14, weight=ft.FontWeight.W_700, color=th.ON_SURFACE),
                                    _bar_row("Speech", counts.get("Speech", 0), max_count),
                                    _bar_row("Music", counts.get("Music", 0), max_count),
                                    _bar_row("Noise", counts.get("Noise", 0), max_count),
                                    _bar_row("Unknown", counts.get("Unknown", 0), max_count),
                                ],
                            ),
                            padding=ft.Padding.all(16),
                        ),
                        th.glass_card(
                            content=ft.Column(
                                spacing=10,
                                controls=[
                                    ft.Text("Languages seen", size=14, weight=ft.FontWeight.W_700, color=th.ON_SURFACE),
                                    *lang_controls,
                                ],
                            ),
                            padding=ft.Padding.all(16),
                        ),
                    ],
                ),
            )
        ],
    )
