"""History screen."""
from __future__ import annotations

import flet as ft
from models import AppState
import storage as storage_mod
import theme as th


def build_view(page: ft.Page, state: AppState) -> ft.View:
    def clear_all(e):
        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Clear history?", color=th.ON_SURFACE),
            content=ft.Text("This removes all saved results from this device.", color=th.ON_SURFACE_2, size=12),
        )

        def close_dialog(ev):
            dlg.open = False
            page.update()

        def confirm_clear(ev):
            storage_mod.clear_history(state)
            dlg.open = False
            page.update()
            page.go("/history")

        dlg.actions = [
            ft.TextButton("Cancel", on_click=close_dialog),
            ft.TextButton("Clear", on_click=confirm_clear),
        ]
        page.dialog = dlg
        dlg.open = True
        page.update()

    items = []
    if not state.history:
        items.append(
            th.glass_card(
                content=ft.Text("No history yet.", color=th.ON_SURFACE_2, text_align=ft.TextAlign.CENTER),
                padding=ft.Padding.all(18),
            )
        )
    else:
        for rec in state.history:
            color = th.type_color(rec.audio_type)
            items.append(
                th.glass_card(
                    content=ft.Column(
                        spacing=6,
                        controls=[
                            ft.Row(
                                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                                controls=[
                                    ft.Text(rec.audio_type, color=th.ON_SURFACE, weight=ft.FontWeight.W_700),
                                    ft.Text(rec.display_time, size=11, color=th.ON_SURFACE_2),
                                ],
                            ),
                            ft.Text(f"File: {rec.filename}", size=12, color=th.ON_SURFACE_2),
                            ft.Text(f"Language: {rec.language or 'Unknown'}", size=12, color=th.ON_SURFACE_2),
                            ft.Text(f"Confidence: {((rec.confidence or 0) * 100):.1f}%", size=12, color=th.ON_SURFACE_2),
                        ],
                    ),
                    padding=ft.Padding.all(16),
                )
            )

    return ft.View(
        route="/history",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("History", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(icon=ft.Icons.ARROW_BACK_ROUNDED, on_click=lambda e: page.go("/")),
            actions=[ft.IconButton(icon=ft.Icons.DELETE_OUTLINE_ROUNDED, on_click=clear_all)],
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    scroll=ft.ScrollMode.AUTO,
                    spacing=12,
                    controls=items,
                ),
            )
        ],
    )
