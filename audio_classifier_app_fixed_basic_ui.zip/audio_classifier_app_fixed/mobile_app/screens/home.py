"""Home screen."""
from __future__ import annotations

import flet as ft
import theme as th


def _feature_tile(icon, title: str, subtitle: str, color: str) -> ft.Container:
    return th.glass_card(
        content=ft.Row(
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.START,
            controls=[
                th.neon_icon_container(icon, color, size=18, container_size=40, border_radius=12),
                ft.Column(
                    expand=True,
                    spacing=2,
                    controls=[
                        ft.Text(title, size=14, weight=ft.FontWeight.W_700, color=th.ON_SURFACE),
                        ft.Text(subtitle, size=11, color=th.ON_SURFACE_2),
                    ],
                ),
            ],
        ),
        padding=ft.Padding.all(14),
    )


def build_view(page: ft.Page, state) -> ft.View:
    counts = state.counts()

    return ft.View(
        route="/",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Audio Classifier", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    scroll=ft.ScrollMode.AUTO,
                    spacing=16,
                    controls=[
                        th.glass_card(
                            content=ft.Column(
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                spacing=10,
                                controls=[
                                    th.neon_icon_container(ft.Icons.AUDIOTRACK_ROUNDED, th.PRIMARY, size=26, container_size=56, border_radius=18),
                                    ft.Text("Simple audio analysis UI", size=22, weight=ft.FontWeight.BOLD, color=th.ON_SURFACE, text_align=ft.TextAlign.CENTER),
                                    ft.Text("Upload a clip or record from the mic, then see the result, history, and basic analytics.", size=12, color=th.ON_SURFACE_2, text_align=ft.TextAlign.CENTER),
                                ],
                            ),
                            padding=ft.Padding.all(18),
                        ),
                        ft.Row(
                            spacing=10,
                            wrap=True,
                            controls=[
                                th.stat_card("Speech", str(counts.get("Speech", 0)), ft.Icons.RECORD_VOICE_OVER_ROUNDED, th.SPEECH_COLOR),
                                th.stat_card("Music", str(counts.get("Music", 0)), ft.Icons.MUSIC_NOTE_ROUNDED, th.MUSIC_COLOR),
                                th.stat_card("Noise", str(counts.get("Noise", 0)), ft.Icons.GRAPHIC_EQ_ROUNDED, th.NOISE_COLOR),
                            ],
                        ),
                        _feature_tile(ft.Icons.UPLOAD_FILE_ROUNDED, "Upload audio", "Pick a WAV, MP3, M4A, FLAC, or OGG file.", th.VIOLET),
                        _feature_tile(ft.Icons.MIC_ROUNDED, "Record audio", "Capture a new sample from the microphone.", th.TEAL),
                        ft.Row(
                            spacing=10,
                            wrap=True,
                            controls=[
                                ft.ElevatedButton(text="Upload", icon=ft.Icons.UPLOAD_FILE_ROUNDED, on_click=lambda e: page.go("/upload")),
                                ft.ElevatedButton(text="Record", icon=ft.Icons.MIC_ROUNDED, on_click=lambda e: page.go("/record")),
                                ft.OutlinedButton(text="History", on_click=lambda e: page.go("/history")),
                                ft.OutlinedButton(text="Analytics", on_click=lambda e: page.go("/analytics")),
                            ],
                        ),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.TextButton("Settings", on_click=lambda e: page.go("/settings")),
                                ft.TextButton("About", on_click=lambda e: page.go("/about")),
                            ],
                        ),
                    ],
                ),
            )
        ],
    )
