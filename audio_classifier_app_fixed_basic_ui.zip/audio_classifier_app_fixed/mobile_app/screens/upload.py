"""Upload screen."""
from __future__ import annotations

import asyncio
from pathlib import Path

import flet as ft

from models import AppState, AnalysisRecord
import api_client
import storage as storage_mod
import theme as th


def build_view(page: ft.Page, state: AppState, file_picker: ft.FilePicker) -> ft.View:
    selected_name = ft.Text("No file selected", color=th.ON_SURFACE_2)
    status_text = ft.Text("Choose a file to begin.", color=th.ON_SURFACE_2)
    analyze_btn = ft.ElevatedButton(text="Analyze", icon=ft.Icons.PLAY_ARROW_ROUNDED, disabled=True)
    progress = ft.ProgressRing(visible=False, width=18, height=18, stroke_width=2, color=th.PRIMARY)

    picked = {"path": None, "name": None}

    def on_pick_result(e: ft.FilePickerResultEvent):
        files = e.files or []
        if not files:
            return
        f = files[0]
        picked["path"] = f.path
        picked["name"] = f.name or (Path(f.path).name if f.path else "audio.wav")
        selected_name.value = picked["name"]
        selected_name.color = th.ON_SURFACE
        status_text.value = "File ready. Tap Analyze."
        status_text.color = th.GREEN
        analyze_btn.disabled = False
        page.update()

    async def run_analysis(e):
        if not picked["path"]:
            return
        progress.visible = True
        analyze_btn.disabled = True
        status_text.value = "Analyzing..."
        status_text.color = th.ON_SURFACE_2
        page.update()

        try:
            result = await api_client.analyze_audio(
                state.backend_url,
                file_path=picked["path"],
                filename=picked["name"] or "audio.wav",
            )
            record = AnalysisRecord(
                audio_type=result.get("audio_type", "Unknown"),
                language=result.get("language"),
                confidence=result.get("confidence"),
                duration=result.get("duration", 0.0),
                filename=result.get("filename", picked["name"] or "audio.wav"),
                timestamp=result.get("timestamp", ""),
            )
            state.add_record(record)
            storage_mod.save_state(state)
            page.go("/result")
        except api_client.ApiError as exc:
            progress.visible = False
            analyze_btn.disabled = False
            status_text.value = str(exc)
            status_text.color = th.DANGER
            page.update()

    analyze_btn.on_click = run_analysis
    file_picker.on_result = on_pick_result

    def open_picker(e):
        file_picker.pick_files(
            allow_multiple=False,
            allowed_extensions=["wav", "mp3", "m4a", "flac", "ogg"],
        )

    return ft.View(
        route="/upload",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Upload Audio", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(icon=ft.Icons.ARROW_BACK_ROUNDED, on_click=lambda e: page.go("/")),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    spacing=16,
                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                    controls=[
                        th.glass_card(
                            content=ft.Column(
                                spacing=12,
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                controls=[
                                    th.neon_icon_container(ft.Icons.UPLOAD_FILE_ROUNDED, th.VIOLET, size=24, container_size=54, border_radius=18),
                                    ft.Text("Pick an audio file", size=18, weight=ft.FontWeight.BOLD, color=th.ON_SURFACE),
                                    ft.Text("Supports WAV, MP3, M4A, FLAC, and OGG.", size=12, color=th.ON_SURFACE_2),
                                    ft.OutlinedButton(text="Choose file", icon=ft.Icons.FOLDER_OPEN_ROUNDED, on_click=open_picker),
                                    ft.Text("Selected file:", color=th.ON_SURFACE_2, size=12),
                                    selected_name,
                                ],
                            ),
                            padding=ft.Padding.all(18),
                        ),
                        th.glass_card(
                            content=ft.Column(
                                spacing=10,
                                controls=[
                                    ft.Text("Status", size=14, weight=ft.FontWeight.W_700, color=th.ON_SURFACE),
                                    status_text,
                                    ft.Row(spacing=10, controls=[progress, analyze_btn]),
                                ],
                            ),
                            padding=ft.Padding.all(16),
                        ),
                    ],
                ),
            )
        ],
    )
