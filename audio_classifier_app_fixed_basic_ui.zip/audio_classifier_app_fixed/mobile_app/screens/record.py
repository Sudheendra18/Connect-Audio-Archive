"""Record screen."""
from __future__ import annotations

import asyncio
import os
import tempfile
import time
from pathlib import Path

import flet as ft
from flet_audio_recorder import AudioRecorder, AudioRecorderConfiguration, AudioEncoder

from models import AppState, AnalysisRecord
import api_client
import storage as storage_mod
import theme as th


def build_view(page: ft.Page, state: AppState, audio_recorder: AudioRecorder) -> ft.View:
    status_text = ft.Text("Tap Start Recording.", color=th.ON_SURFACE_2)
    timer_text = ft.Text("00:00", size=42, weight=ft.FontWeight.BOLD, color=th.ON_SURFACE)
    analyze_btn = ft.ElevatedButton(text="Analyze", icon=ft.Icons.PLAY_ARROW_ROUNDED, disabled=True)
    record_btn = ft.ElevatedButton(text="Start Recording", icon=ft.Icons.MIC_ROUNDED)
    progress = ft.ProgressRing(visible=False, width=18, height=18, stroke_width=2, color=th.PRIMARY)
    wave = ft.Row(spacing=4, visible=False, alignment=ft.MainAxisAlignment.CENTER)
    bar_refs = [ft.Ref[ft.Container]() for _ in range(10)]
    heights = [10, 18, 26, 34, 42, 42, 34, 26, 18, 10]

    state_box = {"recording": False, "path": None, "start": 0.0}

    for i, h in enumerate(heights):
        wave.controls.append(
            ft.Container(ref=bar_refs[i], width=4, height=h, border_radius=2, bgcolor=th.VIOLET)
        )

    async def animate():
        t = 0.0
        while state_box["recording"]:
            for i, ref in enumerate(bar_refs):
                if ref.current is not None:
                    h = int(heights[i] * (0.4 + 0.6 * abs(__import__("math").sin(t + i * 0.35))))
                    ref.current.height = max(4, h)
            page.update()
            await asyncio.sleep(0.08)
            t += 0.3

    async def tick():
        while state_box["recording"]:
            elapsed = int(time.time() - state_box["start"])
            mins, secs = divmod(elapsed, 60)
            timer_text.value = f"{mins:02d}:{secs:02d}"
            page.update()
            await asyncio.sleep(1)

    async def toggle_recording(e):
        if not state_box["recording"]:
            try:
                has_perm = await audio_recorder.has_permission()
            except Exception as exc:
                status_text.value = f"Recorder unavailable: {exc}"
                status_text.color = th.DANGER
                page.update()
                return

            if not has_perm:
                status_text.value = "Microphone permission denied."
                status_text.color = th.DANGER
                page.update()
                return

            out_path = os.path.join(tempfile.gettempdir(), f"recording_{int(time.time())}.wav")
            try:
                try:
                    await audio_recorder.start_recording(
                        output_path=out_path,
                        configuration=AudioRecorderConfiguration(encoder=AudioEncoder.WAV),
                    )
                except TypeError:
                    await audio_recorder.start_recording(output_path=out_path)
            except Exception as exc:
                status_text.value = f"Could not start recording: {exc}"
                status_text.color = th.DANGER
                page.update()
                return

            state_box["recording"] = True
            state_box["path"] = out_path
            state_box["start"] = time.time()
            record_btn.text = "Stop Recording"
            record_btn.icon = ft.Icons.STOP_ROUNDED
            analyze_btn.disabled = True
            wave.visible = True
            status_text.value = "Recording in progress..."
            status_text.color = th.DANGER
            page.update()
            asyncio.create_task(tick())
            asyncio.create_task(animate())
        else:
            try:
                stopped_path = await audio_recorder.stop_recording()
            except Exception as exc:
                stopped_path = None
                status_text.value = f"Could not stop recording: {exc}"
                status_text.color = th.DANGER
                page.update()

            state_box["recording"] = False
            state_box["path"] = stopped_path or state_box["path"]
            record_btn.text = "Start Recording"
            record_btn.icon = ft.Icons.MIC_ROUNDED
            analyze_btn.disabled = False
            wave.visible = False
            status_text.value = "Recording captured. Tap Analyze."
            status_text.color = th.GREEN
            page.update()

    async def run_analysis(e):
        if not state_box["path"]:
            return
        progress.visible = True
        analyze_btn.disabled = True
        status_text.value = "Analyzing..."
        status_text.color = th.ON_SURFACE_2
        page.update()

        try:
            filename = Path(state_box["path"]).name
            result = await api_client.analyze_audio(
                state.backend_url,
                file_path=state_box["path"],
                filename=filename,
            )
            record = AnalysisRecord(
                audio_type=result.get("audio_type", "Unknown"),
                language=result.get("language"),
                confidence=result.get("confidence"),
                duration=result.get("duration", 0.0),
                filename=result.get("filename", filename),
                timestamp=result.get("timestamp", ""),
            )
            state.add_record(record)
            storage_mod.save_state(state)
            page.go("/result")
        except api_client.ApiError as exc:
            progress.visible = False
            analyze_btn.disabled = False
            status_text.value = str(exc)
            status_text.color = th.DANGER
            page.update()

    record_btn.on_click = toggle_recording
    analyze_btn.on_click = run_analysis

    return ft.View(
        route="/record",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Record Audio", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(icon=ft.Icons.ARROW_BACK_ROUNDED, on_click=lambda e: page.go("/")),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    spacing=16,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        th.glass_card(
                            content=ft.Column(
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                spacing=12,
                                controls=[
                                    th.neon_icon_container(ft.Icons.MIC_ROUNDED, th.TEAL, size=24, container_size=56, border_radius=18),
                                    timer_text,
                                    wave,
                                    status_text,
                                    record_btn,
                                ],
                            ),
                            padding=ft.Padding.all(18),
                        ),
                        th.glass_card(
                            content=ft.Column(
                                spacing=10,
                                controls=[
                                    ft.Text("Next step", size=14, weight=ft.FontWeight.W_700, color=th.ON_SURFACE),
                                    ft.Text("Stop recording first, then tap Analyze to send it to the backend.", color=th.ON_SURFACE_2, size=12),
                                    ft.Row(spacing=10, controls=[progress, analyze_btn]),
                                ],
                            ),
                            padding=ft.Padding.all(16),
                        ),
                    ],
                ),
            )
        ],
    )
