"""Simple local persistence using a JSON file in the temp directory."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

from models import AppState

STATE_FILE = Path(tempfile.gettempdir()) / "audio_classifier_app_state.json"


def load_state(state: AppState) -> None:
    if not STATE_FILE.exists():
        return
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return

    if isinstance(data, dict):
        state.backend_url = str(data.get("backend_url", state.backend_url))
        state.dark_mode = bool(data.get("dark_mode", state.dark_mode))
        history = data.get("history", [])
        if isinstance(history, list):
            state.history = [item for item in AppState.history_from_json(json.dumps(history))]
        current = data.get("current_result")
        if isinstance(current, dict):
            from models import AnalysisRecord
            state.current_result = AnalysisRecord.from_dict(current)


def save_state(state: AppState) -> None:
    payload = {
        "backend_url": state.backend_url,
        "dark_mode": state.dark_mode,
        "history": [r.to_dict() for r in state.history],
        "current_result": state.current_result.to_dict() if state.current_result else None,
    }
    try:
        STATE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def clear_history(state: AppState) -> None:
    state.history = []
    state.current_result = None
    save_state(state)
