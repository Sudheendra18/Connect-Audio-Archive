"""Theme tokens and shared UI helpers."""
from __future__ import annotations

import flet as ft

PRIMARY = "#4F6EF7"
PRIMARY_LIGHT = "#7B93F9"
VIOLET = "#7C5CF6"
VIOLET_LIGHT = "#9C7FF9"
TEAL = "#0EA5B0"
GREEN = "#16A34A"
DANGER = "#EF4444"
AMBER = "#F59E0B"

SPEECH_COLOR = PRIMARY
MUSIC_COLOR = VIOLET
NOISE_COLOR = AMBER

BG = "#F7F8FA"
SURFACE_0 = "#F7F8FA"
SURFACE_1 = "#FFFFFF"
SURFACE_2 = "#EEF0F4"
SURFACE_3 = "#E2E5EC"

ON_PRIMARY = "#FFFFFF"
ON_SURFACE = "#111827"
ON_SURFACE_2 = "#6B7280"
DIVIDER = "#E5E7EB"

TYPE_COLORS = {
    "Speech": SPEECH_COLOR,
    "Music": MUSIC_COLOR,
    "Noise": NOISE_COLOR,
}

TYPE_ICONS = {
    "Speech": ft.Icons.RECORD_VOICE_OVER_ROUNDED,
    "Music": ft.Icons.MUSIC_NOTE_ROUNDED,
    "Noise": ft.Icons.GRAPHIC_EQ_ROUNDED,
}


def make_theme() -> ft.Theme:
    return ft.Theme(color_scheme_seed=PRIMARY, use_material3=True)


def type_color(audio_type: str) -> str:
    return TYPE_COLORS.get(audio_type, PRIMARY)


def type_icon(audio_type: str):
    return TYPE_ICONS.get(audio_type, ft.Icons.AUDIOTRACK_ROUNDED)


def neon_icon_container(icon, color: str, size: int = 20, container_size: int = 44, border_radius: int = 14) -> ft.Container:
    return ft.Container(
        content=ft.Icon(icon, color=color, size=size),
        width=container_size,
        height=container_size,
        border_radius=border_radius,
        bgcolor=f"{color}18",
        border=ft.Border.all(1, f"{color}35"),
        alignment=ft.Alignment.CENTER,
    )


def glass_card(content: ft.Control, padding=None) -> ft.Container:
    return ft.Container(
        content=content,
        padding=padding or ft.Padding.all(16),
        border_radius=20,
        bgcolor=SURFACE_1,
        border=ft.Border.all(1, DIVIDER),
        shadow=ft.BoxShadow(spread_radius=0, blur_radius=12, color="#00000012", offset=ft.Offset(0, 3)),
    )


def stat_card(label: str, value: str, icon, color: str) -> ft.Container:
    return ft.Container(
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=4,
            controls=[
                ft.Container(
                    content=ft.Icon(icon, color=color, size=18),
                    width=38,
                    height=38,
                    border_radius=12,
                    bgcolor=f"{color}15",
                    border=ft.Border.all(1, f"{color}30"),
                    alignment=ft.Alignment.CENTER,
                ),
                ft.Text(value, size=18, weight=ft.FontWeight.BOLD, color=ON_SURFACE),
                ft.Text(label, size=10, color=ON_SURFACE_2),
            ],
        ),
        padding=ft.Padding.symmetric(vertical=14, horizontal=8),
        border_radius=16,
        bgcolor=SURFACE_1,
        border=ft.Border.all(1, DIVIDER),
        shadow=ft.BoxShadow(spread_radius=0, blur_radius=8, color="#00000010", offset=ft.Offset(0, 2)),
        alignment=ft.Alignment.CENTER,
    )
