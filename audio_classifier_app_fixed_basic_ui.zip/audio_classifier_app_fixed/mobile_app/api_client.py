"""Talks to the FastAPI backend."""
from __future__ import annotations

import httpx


class ApiError(Exception):
    pass


async def check_health(backend_url: str) -> bool:
    url = f"{backend_url.rstrip('/')}/health"
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(url)
            return resp.status_code == 200
    except Exception:
        return False


async def analyze_audio(
    backend_url: str,
    file_path: str | None = None,
    file_bytes: bytes | None = None,
    filename: str = "audio.wav",
) -> dict:
    url = f"{backend_url.rstrip('/')}/analyze"

    if file_bytes is None and file_path is not None:
        with open(file_path, "rb") as f:
            file_bytes = f.read()

    if file_bytes is None:
        raise ApiError("No audio data provided")

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            files = {"file": (filename, file_bytes)}
            response = await client.post(url, files=files)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        raise ApiError(f"Server error ({exc.response.status_code}): {exc.response.text}") from exc
    except httpx.RequestError as exc:
        raise ApiError(f"Could not reach backend at {backend_url}: {exc}") from exc
