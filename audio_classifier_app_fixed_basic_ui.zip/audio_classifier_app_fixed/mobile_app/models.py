"""Data models shared across the app."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import List, Optional
import json
import uuid


@dataclass
class AnalysisRecord:
    audio_type: str
    language: Optional[str] = None
    confidence: Optional[float] = None
    duration: float = 0.0
    filename: str = "audio"
    timestamp: str = ""
    id: str = ""

    def __post_init__(self):
        if not self.id:
            self.id = uuid.uuid4().hex
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "AnalysisRecord":
        return AnalysisRecord(
            audio_type=d.get("audio_type", "Unknown"),
            language=d.get("language"),
            confidence=d.get("confidence"),
            duration=float(d.get("duration", 0.0) or 0.0),
            filename=d.get("filename", "audio"),
            timestamp=d.get("timestamp", ""),
            id=d.get("id", ""),
        )

    @property
    def display_time(self) -> str:
        try:
            dt = datetime.fromisoformat(self.timestamp)
            return dt.strftime("%b %d, %Y %I:%M %p")
        except Exception:
            return self.timestamp or "Unknown"


@dataclass
class AppState:
    backend_url: str = "http://10.0.2.2:8000"
    history: List[AnalysisRecord] = field(default_factory=list)
    current_result: Optional[AnalysisRecord] = None
    dark_mode: bool = False

    def add_record(self, record: AnalysisRecord) -> None:
        self.history.insert(0, record)
        self.current_result = record

    def history_to_json(self) -> str:
        return json.dumps([r.to_dict() for r in self.history], ensure_ascii=False)

    @staticmethod
    def history_from_json(s: str) -> List[AnalysisRecord]:
        if not s:
            return []
        try:
            data = json.loads(s)
            return [AnalysisRecord.from_dict(item) for item in data if isinstance(item, dict)]
        except Exception:
            return []

    def counts(self) -> dict:
        counts = {"Speech": 0, "Music": 0, "Noise": 0, "Unknown": 0}
        for r in self.history:
            counts[r.audio_type] = counts.get(r.audio_type, 0) + 1
        return counts

    def language_distribution(self) -> dict:
        dist: dict[str, int] = {}
        for r in self.history:
            if r.language:
                dist[r.language] = dist.get(r.language, 0) + 1
        return dist
