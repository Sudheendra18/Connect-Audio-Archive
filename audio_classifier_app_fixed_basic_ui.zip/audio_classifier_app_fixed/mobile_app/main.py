"""Audio Classifier app entry point."""
from __future__ import annotations

import flet as ft
from flet_audio_recorder import AudioRecorder

from models import AppState
import storage as storage_mod
import theme as th
from screens import home, upload, record, result, history, analytics, settings, about


def main(page: ft.Page):
    page.title = "Audio Classifier"
    page.theme = th.make_theme()
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = th.BG
    page.padding = 0

    state = AppState()
    storage_mod.load_state(state)
    page.theme_mode = ft.ThemeMode.DARK if state.dark_mode else ft.ThemeMode.LIGHT
    page.bgcolor = th.SURFACE_0 if state.dark_mode else th.BG

    file_picker = ft.FilePicker()
    audio_recorder = AudioRecorder()
    page.overlay.extend([file_picker, audio_recorder])

    def route_change(e: ft.RouteChangeEvent):
        page.views.clear()
        route = page.route or "/"

        if route == "/upload":
            page.views.append(upload.build_view(page, state, file_picker))
        elif route == "/record":
            page.views.append(record.build_view(page, state, audio_recorder))
        elif route == "/result":
            page.views.append(result.build_view(page, state))
        elif route == "/history":
            page.views.append(history.build_view(page, state))
        elif route == "/analytics":
            page.views.append(analytics.build_view(page, state))
        elif route == "/settings":
            page.views.append(settings.build_view(page, state))
        elif route == "/about":
            page.views.append(about.build_view(page, state))
        else:
            page.views.append(home.build_view(page, state))

        page.update()

    def view_pop(e: ft.ViewPopEvent):
        if len(page.views) > 1:
            page.views.pop()
            page.go(page.views[-1].route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go("/")


if __name__ == "__main__":
    ft.app(target=main)
