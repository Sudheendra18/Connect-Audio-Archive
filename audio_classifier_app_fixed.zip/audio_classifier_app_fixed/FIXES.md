# What was broken & what I fixed

I installed Flet 0.85.3 (the exact pinned version) in a sandbox and validated every
control/method call against the real package source instead of guessing — then ran
the actual screens through the real `flet` runtime. Found and fixed:

## Critical — navigation was completely broken
`page.push_route()` is `async` in this Flet version. Every nav action in the app
(bottom nav bar, all back buttons, Upload/Record card taps, "See all", Settings →
About, post-analysis redirect to Result, dialog "Clear" confirm, etc.) called it
from a plain `lambda e: page.push_route(route)` — that just creates a coroutine
object that's never awaited, so **nothing actually happened**. Fixed by:
- Sync `lambda` callbacks → `page.navigate(route)` (Flet's sync-safe wrapper).
- `async def` handlers that were already being awaited by Flet (e.g. `run_analysis`,
  `do_clear`) → added the missing `await` on `page.push_route(...)`.
- `main.py`'s `view_pop` → made `async`, awaits `push_route`, and guards against
  popping the only remaining view (would've thrown `IndexError`).

## Crashes on Result / History / Analytics screens
- `theme.py` was missing `type_badge()`, `ghost_button()`, `accent_button()` used by
  `result.py` / `history.py` → `AttributeError` on every visit. Implemented all three.
- `theme.section_label()` didn't accept a `color` override; `analytics.py` called it
  with one → `TypeError`. Added the optional param.
- `theme.glass_card()` didn't accept `glow_color`; `analytics.py` used it →
  `TypeError`. Added tinted border/shadow support.
- `ft.NavigationBar(..., surface_tint_color=...)` isn't a valid field in this Flet
  version → crashed every screen with a bottom nav bar. Removed it.

## Dark Mode was a non-functional switch
The toggle flipped `page.theme_mode` but every screen hardcoded light hex colors
(`th.SURFACE_1`, `th.ON_SURFACE`, …), so dark mode produced a broken half-dark UI.
Added a real light/dark token system in `theme.py` (`apply_mode()`), applied on every
route change and rebuilt in place the instant you flip the switch so it's
immediate — no screen files needed to change since they already read `th.*` fresh
on every render.

## Verification performed (not just code review)
- Installed `flet==0.85.3`, `flet-audio-recorder==0.85.3`, `flet-web==0.85.3` and
  built every one of the 8 screens (Home, Upload, Record, Result, History,
  Analytics, Settings, About) against the real API — including empty-state,
  no-confidence, and zero-confidence edge cases.
- Ran the actual `ft.run()` web server and confirmed it serves.
- Drove the real callbacks end-to-end: file pick → analyze → save → navigate to
  Result; dark-mode toggle → persisted + repainted; Export/Clear History → dialogs
  fire correctly.
- Spun up the FastAPI backend and hit `/health` (200 OK) and `/analyze` (correctly
  returns a clear 500 with a helpful message when `backend/stage1/audio_pipeline.py`
  isn't present yet — that's expected until you copy your STAGE1 files in).

## What you still need to do
Copy these into `backend/stage1/` (referenced in `pipeline_adapter.py`'s docstring):
`audio_pipeline.py`, `svm_model.pkl`, `scaler.pkl`, and anything else
`audio_pipeline.py` imports (e.g. `speech_language_detection.py`). The app and
backend now work correctly end-to-end; they just need your trained pipeline to
produce real predictions instead of the "not found" error.
