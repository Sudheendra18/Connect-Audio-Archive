"""Local persistence — gracefully handles SharedPreferences timeout.

Falls back to in-memory defaults if SharedPreferences isn't available
(common during desktop/web testing or before the page is fully mounted).
"""
import flet as ft
from models import AppState

HISTORY_KEY     = "analysis_history"
THEME_KEY       = "dark_mode"
BACKEND_URL_KEY = "backend_url"

_prefs: ft.SharedPreferences | None = None
_prefs_available: bool = True   # assume available until proven otherwise


def get_prefs(page: ft.Page) -> ft.SharedPreferences | None:
    global _prefs, _prefs_available
    if not _prefs_available:
        return None
    if _prefs is None:
        _prefs = ft.SharedPreferences()
        page.overlay.append(_prefs)
    return _prefs


async def _safe_get(prefs: ft.SharedPreferences | None, key: str):
    """Return value or None on any error (timeout, unavailable, etc.)."""
    global _prefs_available
    if prefs is None:
        return None
    try:
        return await prefs.get(key)
    except Exception:
        _prefs_available = False
        return None


async def _safe_set(prefs: ft.SharedPreferences | None, key: str, value) -> None:
    global _prefs_available
    if prefs is None:
        return
    try:
        await prefs.set(key, value)
    except Exception:
        _prefs_available = False


async def _safe_remove(prefs: ft.SharedPreferences | None, key: str) -> None:
    global _prefs_available
    if prefs is None:
        return
    try:
        await prefs.remove(key)
    except Exception:
        _prefs_available = False


async def load_state(page: ft.Page, state: AppState) -> None:
    prefs = get_prefs(page)

    history_json = await _safe_get(prefs, HISTORY_KEY)
    if isinstance(history_json, str):
        state.history = AppState.history_from_json(history_json)

    dark = await _safe_get(prefs, THEME_KEY)
    # Default to LIGHT (False) — the new light theme
    state.dark_mode = bool(dark) if dark is not None else False

    backend_url = await _safe_get(prefs, BACKEND_URL_KEY)
    if isinstance(backend_url, str) and backend_url:
        state.backend_url = backend_url


async def save_history(page: ft.Page, state: AppState) -> None:
    prefs = get_prefs(page)
    await _safe_set(prefs, HISTORY_KEY, state.history_to_json())


async def save_theme(page: ft.Page, state: AppState) -> None:
    prefs = get_prefs(page)
    await _safe_set(prefs, THEME_KEY, state.dark_mode)


async def save_backend_url(page: ft.Page, state: AppState) -> None:
    prefs = get_prefs(page)
    await _safe_set(prefs, BACKEND_URL_KEY, state.backend_url)


async def clear_history(page: ft.Page, state: AppState) -> None:
    state.history = []
    prefs = get_prefs(page)
    await _safe_remove(prefs, HISTORY_KEY)
