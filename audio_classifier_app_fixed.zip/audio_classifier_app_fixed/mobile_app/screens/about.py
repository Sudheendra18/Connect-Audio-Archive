"""About screen — model details, pipeline, and app version. Premium design."""
import flet as ft
import theme as th

APP_VERSION = "2.0.0"


def _tech_card(icon, color: str, title: str, lines: list[str]) -> ft.Container:
    bullet_rows = []
    for line in lines:
        bullet_rows.append(
            ft.Row(
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.START,
                controls=[
                    ft.Container(
                        width=6,
                        height=6,
                        border_radius=3,
                        bgcolor=color,
                        margin=ft.Margin.only(top=5),
                        shadow=ft.BoxShadow(
                            spread_radius=0,
                            blur_radius=6,
                            color=f"{color}88",
                        ),
                    ),
                    ft.Text(
                        line,
                        size=12,
                        color=th.ON_SURFACE_2,
                        expand=True,
                    ),
                ],
            )
        )

    return ft.Container(
        content=ft.Column(
            spacing=12,
            controls=[
                ft.Row(
                    spacing=12,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        th.neon_icon_container(
                            icon, color, size=20, container_size=40, border_radius=12
                        ),
                        ft.Text(
                            title,
                            size=14,
                            weight=ft.FontWeight.W_700,
                            color=th.ON_SURFACE,
                            expand=True,
                        ),
                    ],
                ),
                ft.Container(height=1, bgcolor=th.DIVIDER),
                ft.Column(spacing=8, controls=bullet_rows),
            ],
        ),
        padding=ft.Padding.all(18),
        border_radius=20,
        bgcolor=th.SURFACE_1,
        border=ft.Border.all(1, f"{color}30"),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=20,
            color=f"{color}15",
            offset=ft.Offset(0, 3),
        ),
    )


def _pipeline_step(step: str, detail: str, color: str, is_last: bool = False) -> ft.Column:
    return ft.Column(
        spacing=0,
        controls=[
            ft.Row(
                spacing=14,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Column(
                        spacing=0,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[
                            ft.Container(
                                width=12,
                                height=12,
                                border_radius=6,
                                bgcolor=color,
                                shadow=ft.BoxShadow(
                                    spread_radius=0,
                                    blur_radius=8,
                                    color=f"{color}88",
                                ),
                            ),
                            ft.Container(
                                width=2,
                                height=30,
                                bgcolor=th.DIVIDER if not is_last else ft.Colors.TRANSPARENT,
                                margin=ft.Margin.only(top=2),
                            ) if not is_last else ft.Container(height=30),
                        ],
                    ),
                    ft.Column(
                        spacing=3,
                        controls=[
                            ft.Text(step, size=13, color=th.ON_SURFACE,
                                    weight=ft.FontWeight.W_600),
                            ft.Text(detail, size=11, color=th.ON_SURFACE_2),
                        ],
                    ),
                ],
            ),
        ],
    )


def build_view(page: ft.Page, state) -> ft.View:
    # ── App header ────────────────────────────────────────────────
    app_header = ft.Container(
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=14,
            controls=[
                ft.Stack(
                    width=100,
                    height=100,
                    controls=[
                        ft.Container(
                            width=100,
                            height=100,
                            border_radius=50,
                            bgcolor=f"{th.CYAN}08",
                        ),
                        ft.Container(
                            width=74,
                            height=74,
                            border_radius=37,
                            bgcolor=f"{th.CYAN}15",
                            margin=ft.Margin.all(13),
                        ),
                        ft.Container(
                            width=52,
                            height=52,
                            border_radius=18,
                            bgcolor=f"{th.CYAN}25",
                            border=ft.Border.all(1, f"{th.CYAN}55"),
                            margin=ft.Margin.all(24),
                            alignment=ft.Alignment.CENTER,
                            content=ft.Icon(
                                ft.Icons.GRAPHIC_EQ_ROUNDED,
                                color=th.CYAN,
                                size=28,
                            ),
                            shadow=ft.BoxShadow(
                                spread_radius=0,
                                blur_radius=24,
                                color=f"{th.CYAN}40",
                            ),
                        ),
                    ],
                ),
                ft.Text(
                    "Audio Classifier",
                    size=24,
                    weight=ft.FontWeight.BOLD,
                    color=th.ON_SURFACE,
                ),
                ft.Container(
                    content=ft.Text(
                        f"v{APP_VERSION}  ·  Flet 0.85",
                        size=11,
                        color=th.ON_SURFACE_2,
                        weight=ft.FontWeight.W_600,
                        style=ft.TextStyle(letter_spacing=0.5),
                    ),
                    padding=ft.Padding.symmetric(horizontal=14, vertical=5),
                    border_radius=12,
                    bgcolor=th.SURFACE_2,
                    border=ft.Border.all(1, th.DIVIDER),
                ),
            ],
        ),
        padding=ft.Padding.symmetric(vertical=28),
    )

    # ── Pipeline visual ───────────────────────────────────────────
    pipeline_card = ft.Container(
        content=ft.Column(
            spacing=0,
            controls=[
                ft.Row(
                    spacing=12,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        th.neon_icon_container(
                            ft.Icons.ACCOUNT_TREE_ROUNDED, th.MUSIC_COLOR,
                            size=18, container_size=38, border_radius=12,
                        ),
                        ft.Text("Pipeline", size=14, weight=ft.FontWeight.W_700,
                                color=th.ON_SURFACE),
                    ],
                ),
                ft.Container(height=1, bgcolor=th.DIVIDER, margin=ft.Margin.symmetric(vertical=12)),
                _pipeline_step("Audio File", "WAV · MP3 · M4A · FLAC · OGG", th.VIOLET_LIGHT),
                _pipeline_step("SVM Classifier", "57 Librosa features → Speech / Music / Noise", th.CYAN),
                _pipeline_step("If Speech →", "Whisper Small → Language detection", th.SPEECH_COLOR),
                _pipeline_step("Result", "audio_type + language + confidence", th.GREEN, is_last=True),
            ],
        ),
        padding=ft.Padding.all(18),
        border_radius=20,
        bgcolor=th.SURFACE_1,
        border=ft.Border.all(1, f"{th.MUSIC_COLOR}30"),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=20,
            color=f"{th.MUSIC_COLOR}15",
            offset=ft.Offset(0, 3),
        ),
    )

    svm_card = _tech_card(
        ft.Icons.PSYCHOLOGY_ROUNDED,
        th.VIOLET_LIGHT,
        "Audio Type Classifier — SVM",
        [
            "Trained on the MUSAN dataset (music, noise, speech).",
            "57 features per clip via Librosa: 40 MFCC (20 mean + 20 std), 12 chroma means, spectral centroid, bandwidth, rolloff, zero-crossing rate, and RMS energy.",
            "Compared against Logistic Regression, KNN, Random Forest, Extra Trees, and XGBoost — SVM achieved best accuracy.",
        ],
    )

    whisper_card = _tech_card(
        ft.Icons.TRANSLATE_ROUNDED,
        th.SPEECH_COLOR,
        "Language Detection — Whisper Small",
        [
            "OpenAI Whisper (small model), runs only when audio is classified as Speech.",
            "Supports: English, French, German, Hindi, Kannada, Korean, Malayalam, Spanish, Tamil, Telugu, Urdu.",
            "Replaced a custom classifier — Whisper generalized significantly better across accents and noise levels.",
        ],
    )

    return ft.View(
        route="/about",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("About", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(
                icon=ft.Icons.ARROW_BACK_IOS_NEW_ROUNDED,
                icon_color=th.ON_SURFACE_2,
                icon_size=20,
                on_click=lambda e: page.navigate("/settings"),
            ),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                    controls=[
                        app_header,
                        pipeline_card,
                        svm_card,
                        whisper_card,
                    ],
                ),
            )
        ],
    )
