"""Upload screen — drop zone with neon feedback and file details."""
import flet as ft
from models import AppState, AnalysisRecord
import api_client
import storage as storage_mod
import theme as th


def build_view(page: ft.Page, state: AppState, file_picker: ft.FilePicker) -> ft.View:
    selected_name = ft.Ref[ft.Text]()
    status_text   = ft.Ref[ft.Text]()
    progress      = ft.Ref[ft.ProgressRing]()
    analyze_btn   = ft.Ref[ft.ElevatedButton]()
    drop_zone     = ft.Ref[ft.Container]()
    file_icon     = ft.Ref[ft.Icon]()
    file_info_row = ft.Ref[ft.Container]()
    dot_indicator = ft.Ref[ft.Container]()

    picked = {"path": None, "bytes": None, "name": None}

    async def choose_file(e):
        files = await file_picker.pick_files(
            dialog_title="Select an audio file",
            allowed_extensions=["wav", "mp3", "m4a", "flac", "ogg"],
            allow_multiple=False,
            with_data=True,
        )
        if not files:
            return
        f = files[0]
        picked["path"]  = f.path
        picked["bytes"] = f.bytes
        picked["name"]  = f.name

        selected_name.current.value  = f.name
        selected_name.current.color  = th.ON_SURFACE
        selected_name.current.weight = ft.FontWeight.W_600

        status_text.current.value = "File ready — tap Analyze to classify"
        status_text.current.color = th.GREEN

        drop_zone.current.border = ft.Border.all(2, th.VIOLET_LIGHT)
        drop_zone.current.bgcolor = f"{th.VIOLET}10"
        file_icon.current.color  = th.VIOLET_LIGHT
        file_info_row.current.visible = True
        dot_indicator.current.bgcolor = th.GREEN
        analyze_btn.current.disabled = False
        page.update()

    async def run_analysis(e):
        if not picked["name"]:
            return
        progress.current.visible      = True
        status_text.current.value     = "Analyzing with SVM + Whisper…"
        status_text.current.color     = th.ON_SURFACE_2
        analyze_btn.current.disabled  = True
        page.update()

        try:
            result = await api_client.analyze_audio(
                state.backend_url,
                file_path=picked["path"] if not picked["bytes"] else None,
                file_bytes=picked["bytes"],
                filename=picked["name"],
            )
            record = AnalysisRecord(
                audio_type=result.get("audio_type", "Unknown"),
                language=result.get("language"),
                confidence=result.get("confidence"),
                duration=result.get("duration", 0.0),
                filename=picked["name"],
            )
            state.add_record(record)
            state.current_result = record
            await storage_mod.save_history(page, state)
            await page.push_route("/result")
        except api_client.ApiError as exc:
            progress.current.visible      = False
            status_text.current.value     = str(exc)
            status_text.current.color     = th.DANGER
            analyze_btn.current.disabled  = False
            page.update()

    # ── Drop zone ────────────────────────────────────────────────
    format_chips = ft.Row(
        spacing=6,
        wrap=True,
        alignment=ft.MainAxisAlignment.CENTER,
        controls=[
            ft.Container(
                content=ft.Text(ext, size=10, color=th.ON_SURFACE_2, weight=ft.FontWeight.W_600),
                padding=ft.Padding.symmetric(horizontal=8, vertical=3),
                border_radius=6,
                bgcolor=th.SURFACE_3,
            )
            for ext in ["WAV", "MP3", "M4A", "FLAC", "OGG"]
        ],
    )

    drop_zone_widget = ft.Container(
        ref=drop_zone,
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=16,
            controls=[
                ft.Container(
                    content=ft.Icon(
                        ref=file_icon,
                        icon=ft.Icons.AUDIO_FILE_ROUNDED,
                        size=44,
                        color=th.ON_SURFACE_2,
                    ),
                    width=80,
                    height=80,
                    border_radius=24,
                    bgcolor=th.SURFACE_2,
                    border=ft.Border.all(1, th.DIVIDER),
                    alignment=ft.Alignment.CENTER,
                ),
                ft.Text(
                    "Tap to choose an audio file",
                    color=th.ON_SURFACE,
                    size=15,
                    weight=ft.FontWeight.W_600,
                ),
                format_chips,
            ],
        ),
        padding=ft.Padding.symmetric(vertical=36, horizontal=24),
        border_radius=24,
        bgcolor=th.SURFACE_1,
        border=ft.Border.all(2, th.DIVIDER),
        alignment=ft.Alignment.CENTER,
        on_click=choose_file,
        ink=True,
    )

    # ── File info row ─────────────────────────────────────────────
    file_info = ft.Container(
        ref=file_info_row,
        visible=False,
        content=ft.Container(
            content=ft.Row(
                spacing=12,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Container(
                        ref=dot_indicator,
                        width=8,
                        height=8,
                        border_radius=4,
                        bgcolor=th.ON_SURFACE_2,
                    ),
                    ft.Icon(ft.Icons.ATTACH_FILE_ROUNDED, color=th.ON_SURFACE_2, size=16),
                    ft.Text(
                        ref=selected_name,
                        value="No file selected",
                        color=th.ON_SURFACE_2,
                        size=13,
                        italic=True,
                        expand=True,
                        max_lines=1,
                        overflow=ft.TextOverflow.ELLIPSIS,
                    ),
                ],
            ),
            padding=ft.Padding.symmetric(horizontal=16, vertical=12),
            border_radius=12,
            bgcolor=th.SURFACE_2,
            border=ft.Border.all(1, th.DIVIDER),
        ),
    )

    status_row = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=10,
        controls=[
            ft.ProgressRing(
                ref=progress,
                visible=False,
                width=16,
                height=16,
                stroke_width=2,
                color=th.VIOLET,
            ),
            ft.Text(ref=status_text, value="", size=13, color=th.ON_SURFACE_2),
        ],
    )

    return ft.View(
        route="/upload",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Upload Audio", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(
                icon=ft.Icons.ARROW_BACK_IOS_NEW_ROUNDED,
                icon_color=th.ON_SURFACE_2,
                icon_size=20,
                on_click=lambda e: page.navigate("/"),
            ),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(20),
                content=ft.Column(
                    spacing=16,
                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                    controls=[
                        ft.Container(height=4),
                        drop_zone_widget,
                        file_info,
                        status_row,
                        ft.Container(expand=True),
                        ft.ElevatedButton(
                            ref=analyze_btn,
                            content=ft.Text("Analyze Audio"),
                            icon=ft.Icons.PLAY_ARROW_ROUNDED,
                            disabled=True,
                            style=ft.ButtonStyle(
                                bgcolor={
                                    ft.ControlState.DEFAULT: th.VIOLET,
                                    ft.ControlState.DISABLED: th.SURFACE_3,
                                },
                                color={
                                    ft.ControlState.DEFAULT: th.ON_PRIMARY,
                                    ft.ControlState.DISABLED: th.ON_SURFACE_2,
                                },
                                shape=ft.RoundedRectangleBorder(radius=16),
                                padding=ft.Padding.symmetric(horizontal=24, vertical=16),
                                elevation=0,
                            ),
                            on_click=run_analysis,
                            expand=True,
                        ),
                    ],
                ),
            )
        ],
    )
