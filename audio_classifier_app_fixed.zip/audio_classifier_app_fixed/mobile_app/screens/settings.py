"""Settings screen — theme, backend URL, data management. Flet 0.85.3."""
import flet as ft
from models import AppState
import storage as storage_mod
import theme as th


def _row(
    icon,
    icon_color: str,
    title: str,
    subtitle: str,
    trailing: ft.Control,
    on_click=None,
) -> ft.Container:
    return ft.Container(
        content=ft.Row(
            spacing=14,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                th.neon_icon_container(
                    icon, icon_color, size=18, container_size=40, border_radius=12
                ),
                ft.Column(
                    expand=True,
                    spacing=3,
                    controls=[
                        ft.Text(title, size=14, color=th.ON_SURFACE, weight=ft.FontWeight.W_600),
                        ft.Text(subtitle, size=11, color=th.ON_SURFACE_2),
                    ],
                ),
                trailing,
            ],
        ),
        padding=ft.Padding.symmetric(horizontal=0, vertical=10),
        on_click=on_click,
        ink=True if on_click else False,
        border_radius=12,
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    backend_field = ft.Ref[ft.TextField]()
    theme_switch  = ft.Ref[ft.Switch]()

    async def on_theme_change(e: ft.ControlEvent):
        state.dark_mode = e.control.value
        page.theme_mode = ft.ThemeMode.DARK if state.dark_mode else ft.ThemeMode.LIGHT
        th.apply_mode(state.dark_mode)
        page.bgcolor = th.SURFACE_0
        await storage_mod.save_theme(page, state)
        # Rebuild this screen in place so the new colors apply immediately
        # (controls bake in their bgcolor/color at build time, so swapping
        # th.* globals alone won't repaint an already-built view).
        page.views.clear()
        page.views.append(build_view(page, state))
        page.update()

    async def save_url(e):
        state.backend_url = backend_field.current.value or state.backend_url
        await storage_mod.save_backend_url(page, state)
        page.show_dialog(ft.SnackBar(
            content=ft.Text("Backend URL saved ✓", color=th.ON_SURFACE),
            bgcolor=th.SURFACE_2,
            duration=2000,
        ))
        page.update()

    async def export_history(e):
        if not state.history:
            page.show_dialog(ft.SnackBar(
                content=ft.Text("No history to export"),
                bgcolor=th.SURFACE_2,
            ))
            page.update()
            return
        await page.clipboard.set(state.history_to_json())
        page.show_dialog(ft.SnackBar(
            content=ft.Text("History copied to clipboard as JSON ✓"),
            bgcolor=th.SURFACE_2,
        ))
        page.update()

    async def do_clear(e):
        page.pop_dialog()
        await storage_mod.clear_history(page, state)
        page.show_dialog(ft.SnackBar(
            content=ft.Text("History cleared"),
            bgcolor=th.SURFACE_2,
        ))
        await page.push_route("/settings")

    def cancel_clear(e):
        page.pop_dialog()

    def confirm_clear(e):
        page.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Clear all history?", color=th.ON_SURFACE,
                              weight=ft.FontWeight.W_700),
                content=ft.Text(
                    "All saved analyses will be permanently deleted from this device.",
                    color=th.ON_SURFACE_2,
                    size=13,
                ),
                bgcolor=th.SURFACE_1,
                actions=[
                    ft.TextButton(
                        "Cancel",
                        style=ft.ButtonStyle(color=th.ON_SURFACE_2),
                        on_click=cancel_clear,
                    ),
                    ft.TextButton(
                        "Clear",
                        style=ft.ButtonStyle(color=th.DANGER),
                        on_click=do_clear,
                    ),
                ],
                actions_alignment=ft.MainAxisAlignment.END,
                shape=ft.RoundedRectangleBorder(radius=20),
            )
        )

    # ── Appearance ────────────────────────────────────────────────
    appearance_card = th.glass_card(
        content=ft.Column(
            spacing=4,
            controls=[
                th.section_label("Appearance"),
                ft.Container(height=6),
                _row(
                    ft.Icons.DARK_MODE_ROUNDED,
                    th.VIOLET_LIGHT,
                    "Dark Mode",
                    "Toggle dark / light theme",
                    ft.Switch(
                        ref=theme_switch,
                        value=state.dark_mode,
                        active_color=th.VIOLET,
                        on_change=on_theme_change,
                    ),
                ),
            ],
        ),
        padding=ft.Padding.all(18),
    )

    # ── Network ───────────────────────────────────────────────────
    network_card = th.glass_card(
        content=ft.Column(
            spacing=10,
            controls=[
                th.section_label("Network"),
                ft.Container(height=4),
                ft.Text("Backend URL", size=12, color=th.ON_SURFACE_2),
                ft.TextField(
                    ref=backend_field,
                    value=state.backend_url,
                    hint_text="http://192.168.1.50:8000",
                    hint_style=ft.TextStyle(color=th.ON_SURFACE_2),
                    text_style=ft.TextStyle(color=th.ON_SURFACE, size=13),
                    bgcolor=th.SURFACE_2,
                    border_color=th.DIVIDER,
                    focused_border_color=th.VIOLET_LIGHT,
                    border_radius=12,
                    content_padding=ft.Padding.symmetric(horizontal=14, vertical=12),
                    border_width=1,
                    prefix_icon=ft.Icons.LINK_ROUNDED,
                ),
                ft.Container(
                    content=ft.ElevatedButton(
                        "Save URL",
                        icon=ft.Icons.SAVE_ROUNDED,
                        style=ft.ButtonStyle(
                            bgcolor=th.VIOLET,
                            color=th.ON_PRIMARY,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            elevation=0,
                            padding=ft.Padding.symmetric(horizontal=20, vertical=12),
                        ),
                        on_click=save_url,
                    ),
                    alignment=ft.Alignment.CENTER_RIGHT,
                ),
            ],
        ),
        padding=ft.Padding.all(18),
    )

    # ── Data ──────────────────────────────────────────────────────
    data_card = th.glass_card(
        content=ft.Column(
            spacing=0,
            controls=[
                th.section_label("Data"),
                ft.Container(height=10),
                _row(
                    ft.Icons.IOS_SHARE_ROUNDED,
                    th.CYAN_DIM,
                    "Export History",
                    "Copy all analyses as JSON to clipboard",
                    ft.Icon(ft.Icons.CHEVRON_RIGHT_ROUNDED, color=th.DIVIDER, size=18),
                    on_click=export_history,
                ),
                ft.Container(height=1, bgcolor=th.DIVIDER,
                             margin=ft.Margin.only(left=54, top=6, bottom=6)),
                _row(
                    ft.Icons.DELETE_OUTLINE_ROUNDED,
                    th.DANGER,
                    "Clear History",
                    "Remove all saved analyses from device",
                    ft.Icon(ft.Icons.CHEVRON_RIGHT_ROUNDED, color=th.DIVIDER, size=18),
                    on_click=confirm_clear,
                ),
            ],
        ),
        padding=ft.Padding.all(18),
    )

    # ── About ─────────────────────────────────────────────────────
    about_card = th.glass_card(
        content=_row(
            ft.Icons.INFO_OUTLINE_ROUNDED,
            th.VIOLET_LIGHT,
            "About",
            "Models, pipeline, and version info",
            ft.Icon(ft.Icons.CHEVRON_RIGHT_ROUNDED, color=th.DIVIDER, size=18),
            on_click=lambda e: page.navigate("/about"),
        ),
        padding=ft.Padding.symmetric(horizontal=18, vertical=12),
    )

    return ft.View(
        route="/settings",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Settings", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
        ),
        navigation_bar=th.build_nav_bar(page, 3),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[
                        appearance_card,
                        network_card,
                        data_card,
                        about_card,
                    ],
                ),
            )
        ],
    )
