"""History screen — full scrollable list with search-bar feel and neon type rows."""
import flet as ft
from models import AppState
import theme as th


def _history_tile(r) -> ft.Container:
    color = th.type_color(r.audio_type)
    icon  = th.type_icon(r.audio_type)
    conf  = f"{r.confidence * 100:.0f}%" if r.confidence is not None else "—"
    lang  = r.language or "—"

    return ft.Container(
        content=ft.Row(
            spacing=14,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                th.neon_icon_container(icon, color, size=20, container_size=46, border_radius=14),
                ft.Column(
                    expand=True,
                    spacing=5,
                    controls=[
                        ft.Text(
                            r.filename,
                            size=13,
                            weight=ft.FontWeight.W_600,
                            color=th.ON_SURFACE,
                            max_lines=1,
                            overflow=ft.TextOverflow.ELLIPSIS,
                        ),
                        ft.Row(
                            spacing=8,
                            controls=[
                                th.type_badge(r.audio_type),
                                ft.Text(
                                    f"· {lang}  · {conf}  · {r.duration:.1f}s",
                                    size=11,
                                    color=th.ON_SURFACE_2,
                                ),
                            ],
                        ),
                        ft.Text(
                            r.display_time,
                            size=10,
                            color=th.ON_SURFACE_2,
                        ),
                    ],
                ),
                ft.Icon(
                    ft.Icons.CHEVRON_RIGHT_ROUNDED,
                    color=th.DIVIDER,
                    size=18,
                ),
            ],
        ),
        padding=ft.Padding.symmetric(horizontal=16, vertical=14),
        border_radius=18,
        bgcolor=th.SURFACE_1,
        border=ft.Border.all(1, f"{color}20"),
        margin=ft.Margin.only(bottom=10),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=12,
            color=f"{color}0A",
            offset=ft.Offset(0, 2),
        ),
    )


def _empty_state() -> ft.Container:
    return ft.Container(
        padding=ft.Padding.symmetric(vertical=60),
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=16,
            controls=[
                ft.Container(
                    content=ft.Icon(ft.Icons.HISTORY_ROUNDED, size=44, color=th.VIOLET_LIGHT),
                    width=80,
                    height=80,
                    border_radius=28,
                    bgcolor=f"{th.VIOLET}15",
                    border=ft.Border.all(1, f"{th.VIOLET}30"),
                    alignment=ft.Alignment.CENTER,
                    shadow=ft.BoxShadow(
                        spread_radius=0,
                        blur_radius=20,
                        color=f"{th.VIOLET}20",
                    ),
                ),
                ft.Text(
                    "No history yet",
                    color=th.ON_SURFACE,
                    size=16,
                    weight=ft.FontWeight.W_700,
                ),
                ft.Text(
                    "Analyses you run will appear here.\nStart by uploading or recording audio.",
                    color=th.ON_SURFACE_2,
                    size=12,
                    text_align=ft.TextAlign.CENTER,
                ),
            ],
        ),
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    if not state.history:
        body = _empty_state()
    else:
        tiles = [_history_tile(r) for r in state.history]
        body  = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO, controls=tiles)

    count_badge = ft.Container(
        content=ft.Text(
            str(len(state.history)),
            size=11,
            color=th.VIOLET_LIGHT,
            weight=ft.FontWeight.W_700,
        ),
        padding=ft.Padding.symmetric(horizontal=10, vertical=3),
        border_radius=10,
        bgcolor=f"{th.VIOLET}20",
        border=ft.Border.all(1, f"{th.VIOLET}40"),
    )

    return ft.View(
        route="/history",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Row(
                spacing=10,
                tight=True,
                controls=[
                    ft.Text(
                        "History",
                        color=th.ON_SURFACE,
                        weight=ft.FontWeight.W_700,
                        size=17,
                    ),
                    count_badge,
                ],
            ),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
        ),
        navigation_bar=th.build_nav_bar(page, 1),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.Padding.all(16),
                content=body,
            )
        ],
    )
