"""
Theme, design tokens, and shared UI components — Flet 0.85.3.

Visual identity: CLEAN LIGHT
──────────────────────────────────────────────────────────────────
• Surfaces: White / soft grey (#FFFFFF, #F7F8FA, #EEF0F4)
• Primary:  Indigo blue (#4F6EF7) with violet accent (#7C5CF6)
• Accent:   Teal (#0EA5B0)
• Success:  Green (#16A34A)
• Danger:   Red (#EF4444)
• Text:     Near-black (#111827), muted slate (#6B7280)
──────────────────────────────────────────────────────────────────
"""
import flet as ft

# ── Core palette ────────────────────────────────────────────────

PRIMARY       = "#4F6EF7"   # indigo blue
PRIMARY_LIGHT = "#7B93F9"
PRIMARY_DIM   = "#3B56D4"
VIOLET        = "#7C5CF6"
VIOLET_LIGHT  = "#9C7FF9"
MAGENTA       = "#D946A8"
TEAL          = "#0EA5B0"
TEAL_DIM      = "#0B8C96"
GREEN         = "#16A34A"

SPEECH_COLOR  = "#4F6EF7"   # blue
MUSIC_COLOR   = "#7C5CF6"   # violet
NOISE_COLOR   = "#F59E0B"   # amber

# Surfaces (light is the default/initial state; apply_mode() swaps these)
BG            = "#F7F8FA"   # page background
SURFACE_0     = "#F7F8FA"   # deepest background
SURFACE_1     = "#FFFFFF"   # card / nav bar
SURFACE_2     = "#EEF0F4"   # input / chip
SURFACE_3     = "#E2E5EC"   # divider / hover

ON_PRIMARY    = "#FFFFFF"
ON_SURFACE    = "#111827"   # near-black text
ON_SURFACE_2  = "#6B7280"   # muted / label
DIVIDER       = "#E5E7EB"

DANGER        = "#EF4444"

# ── Light / Dark surface tokens ─────────────────────────────────
# Only the structural surface/text tokens change between modes —
# accent colors (PRIMARY, VIOLET, type colors, etc.) stay constant
# so charts/badges/buttons keep their meaning in both themes.

_LIGHT = {
    "BG": "#F7F8FA", "SURFACE_0": "#F7F8FA", "SURFACE_1": "#FFFFFF",
    "SURFACE_2": "#EEF0F4", "SURFACE_3": "#E2E5EC",
    "ON_SURFACE": "#111827", "ON_SURFACE_2": "#6B7280", "DIVIDER": "#E5E7EB",
}

_DARK = {
    "BG": "#0E1117", "SURFACE_0": "#0E1117", "SURFACE_1": "#171B24",
    "SURFACE_2": "#1F2430", "SURFACE_3": "#2A303D",
    "ON_SURFACE": "#F3F4F6", "ON_SURFACE_2": "#94A0B4", "DIVIDER": "#262C38",
}


def apply_mode(dark: bool) -> None:
    """Swap the structural surface/text tokens for light or dark mode.

    Screens read `th.SURFACE_1`, `th.ON_SURFACE`, etc. fresh every time
    `build_view()` runs (they're plain module attributes, not captured
    at import time), so updating these globals before a view is built
    is enough to re-theme every screen — no per-screen changes needed.
    Call this before building/rebuilding any view.
    """
    globals().update(_DARK if dark else _LIGHT)


# ── Convenience aliases ─────────────────────────────────────────

ACCENT        = TEAL
ACCENT_DIM    = TEAL_DIM
CYAN          = TEAL
CYAN_DIM      = TEAL_DIM

# ── Semantic maps ────────────────────────────────────────────────

TYPE_COLORS = {
    "Speech": SPEECH_COLOR,
    "Music":  MUSIC_COLOR,
    "Noise":  NOISE_COLOR,
}

TYPE_ICONS = {
    "Speech": ft.Icons.RECORD_VOICE_OVER_ROUNDED,
    "Music":  ft.Icons.MUSIC_NOTE_ROUNDED,
    "Noise":  ft.Icons.GRAPHIC_EQ_ROUNDED,
}

NAV_ROUTES = ["/", "/history", "/analytics", "/settings"]

LANGUAGE_PALETTE = [
    "#4F6EF7", "#7C5CF6", "#0EA5B0", "#F59E0B",
    "#D946A8", "#2563EB", "#EF4444", "#9C7FF9",
    "#16A34A", "#F97316", "#06B6D4", "#EC4899",
]


# ── Theme ────────────────────────────────────────────────────────

def make_theme() -> ft.Theme:
    return ft.Theme(
        color_scheme_seed=PRIMARY,
        use_material3=True,
    )


# ── Color helpers ────────────────────────────────────────────────

def type_color(audio_type: str) -> str:
    return TYPE_COLORS.get(audio_type, PRIMARY)


def type_icon(audio_type: str):
    return TYPE_ICONS.get(audio_type, ft.Icons.AUDIOTRACK_ROUNDED)


# ── Shared UI components ─────────────────────────────────────────

def neon_icon_container(
    icon,
    color: str,
    size: int = 20,
    container_size: int = 44,
    border_radius: int = 14,
) -> ft.Container:
    """Icon in a soft tinted circle — light style."""
    return ft.Container(
        content=ft.Icon(icon, color=color, size=size),
        width=container_size,
        height=container_size,
        border_radius=border_radius,
        bgcolor=f"{color}18",
        border=ft.Border.all(1, f"{color}35"),
        alignment=ft.Alignment.CENTER,
    )


def stat_card(label: str, value: str, icon, color: str) -> ft.Container:
    return ft.Container(
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=4,
            controls=[
                ft.Container(
                    content=ft.Icon(icon, color=color, size=18),
                    width=38,
                    height=38,
                    border_radius=12,
                    bgcolor=f"{color}15",
                    border=ft.Border.all(1, f"{color}30"),
                    alignment=ft.Alignment.CENTER,
                ),
                ft.Text(
                    value,
                    size=18,
                    weight=ft.FontWeight.BOLD,
                    color=ON_SURFACE,
                ),
                ft.Text(
                    label,
                    size=10,
                    color=ON_SURFACE_2,
                ),
            ],
        ),
        padding=ft.Padding.symmetric(vertical=14, horizontal=8),
        border_radius=16,
        bgcolor=SURFACE_1,
        border=ft.Border.all(1, DIVIDER),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=8,
            color="#00000010",
            offset=ft.Offset(0, 2),
        ),
        alignment=ft.Alignment.CENTER,
    )


def glass_card(content: ft.Control, padding=None, glow_color: str | None = None) -> ft.Container:
    """White card with light shadow. Optionally tinted with a glow_color border/shadow."""
    border_color = f"{glow_color}30" if glow_color else DIVIDER
    shadow_color = f"{glow_color}18" if glow_color else "#00000012"
    return ft.Container(
        content=content,
        padding=padding or ft.Padding.all(16),
        border_radius=20,
        bgcolor=SURFACE_1,
        border=ft.Border.all(1, border_color),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=12,
            color=shadow_color,
            offset=ft.Offset(0, 3),
        ),
    )


def section_label(text: str, color: str = ON_SURFACE_2) -> ft.Text:
    return ft.Text(
        text.upper(),
        size=11,
        weight=ft.FontWeight.W_700,
        color=color,
        style=ft.TextStyle(letter_spacing=0.8),
    )


def type_badge(audio_type: str, large: bool = False) -> ft.Container:
    """Small colored pill showing an audio type (Speech/Music/Noise)."""
    color = type_color(audio_type)
    icon = type_icon(audio_type)
    size = 13 if large else 10
    icon_size = 14 if large else 11
    return ft.Container(
        content=ft.Row(
            spacing=5,
            tight=True,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Icon(icon, size=icon_size, color=color),
                ft.Text(
                    audio_type,
                    size=size,
                    weight=ft.FontWeight.W_700,
                    color=color,
                ),
            ],
        ),
        padding=ft.Padding.symmetric(horizontal=10 if large else 8, vertical=4 if large else 2),
        border_radius=20,
        bgcolor=f"{color}15",
        border=ft.Border.all(1, f"{color}35"),
    )


def ghost_button(text: str, icon, on_click, expand=False) -> ft.OutlinedButton:
    """Outlined, low-emphasis button."""
    return ft.OutlinedButton(
        content=ft.Text(text),
        icon=icon,
        on_click=on_click,
        expand=expand,
        style=ft.ButtonStyle(
            color=ON_SURFACE,
            side=ft.BorderSide(1, DIVIDER),
            shape=ft.RoundedRectangleBorder(radius=14),
            padding=ft.Padding.symmetric(horizontal=20, vertical=14),
        ),
    )


def accent_button(text: str, icon, on_click, expand=False) -> ft.ElevatedButton:
    """Filled, high-emphasis primary button."""
    return ft.ElevatedButton(
        content=ft.Text(text),
        icon=icon,
        on_click=on_click,
        expand=expand,
        style=ft.ButtonStyle(
            bgcolor=PRIMARY,
            color=ON_PRIMARY,
            shape=ft.RoundedRectangleBorder(radius=14),
            padding=ft.Padding.symmetric(horizontal=20, vertical=14),
            elevation=0,
        ),
    )


def build_nav_bar(page: ft.Page, selected: int) -> ft.NavigationBar:
    return ft.NavigationBar(
        selected_index=selected,
        bgcolor=SURFACE_1,
        indicator_color=f"{PRIMARY}18",
        shadow_color="#00000015",
        destinations=[
            ft.NavigationBarDestination(
                icon=ft.Icons.HOME_OUTLINED,
                selected_icon=ft.Icons.HOME_ROUNDED,
                label="Home",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.HISTORY_OUTLINED,
                selected_icon=ft.Icons.HISTORY_ROUNDED,
                label="History",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.BAR_CHART_OUTLINED,
                selected_icon=ft.Icons.BAR_CHART_ROUNDED,
                label="Analytics",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.SETTINGS_OUTLINED,
                selected_icon=ft.Icons.SETTINGS_ROUNDED,
                label="Settings",
            ),
        ],
        on_change=lambda e: page.navigate(NAV_ROUTES[e.control.selected_index]),
    )
