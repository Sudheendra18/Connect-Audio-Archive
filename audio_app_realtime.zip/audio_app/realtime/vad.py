"""
vad.py
======
Voice activity detection — the throughput multiplier.

On real audio a large fraction of every minute is silence, background noise,
or music. Running Whisper on those windows is wasted compute. The analysis
loop asks `vad.has_speech(block_audio)` first and only transcribes when the
answer is True; silent blocks are marked "analyzed, no beep" instantly.

Two implementations:

  EnergyVAD  (default, zero extra deps)
      Adaptive short-term-energy gate. Tracks a running noise floor and calls
      a frame "speech" when its energy sits `offset_db` above that floor. A
      block counts as speech if at least `min_speech_frac` of its frames do.
      Robust enough to drop true silence/steady noise; deliberately lenient so
      it never *hides* speech from the profanity check (false-accept is cheap —
      you just transcribe a bit more; false-reject would skip filtering).

  SileroVAD  (optional: pip install silero-vad torch)
      Neural VAD, much better on noisy/music-bed audio. Falls back to EnergyVAD
      automatically if torch / the model can't be loaded.

`make_vad(cfg)` returns the right one, or a pass-through when cfg.vad == "off".
"""

from __future__ import annotations

import sys
import numpy as np


class _AlwaysSpeech:
    """cfg.vad == 'off' — never gate; transcribe everything."""
    def has_speech(self, audio: np.ndarray) -> bool:
        return True


class EnergyVAD:
    def __init__(self, sample_rate: int, frame_ms: float = 20.0,
                 min_speech_frac: float = 0.15, offset_db: float = 8.0):
        self.sr = sample_rate
        self.frame = max(1, int(sample_rate * frame_ms / 1000.0))
        self.min_speech_frac = min_speech_frac
        self.offset = offset_db
        # noise floor tracked in dB, seeded low; adapts via asymmetric EMA
        self.noise_db = -60.0
        self._seeded = False

    @staticmethod
    def _frame_db(frames: np.ndarray) -> np.ndarray:
        rms = np.sqrt(np.mean(frames ** 2, axis=1) + 1e-12)
        return 20.0 * np.log10(rms + 1e-12)

    def _update_noise(self, frame_db: np.ndarray) -> None:
        # follow quiet frames quickly, loud frames slowly -> floor hugs silence
        cur_floor = float(np.percentile(frame_db, 15))
        if not self._seeded:
            self.noise_db = cur_floor
            self._seeded = True
            return
        if cur_floor < self.noise_db:
            self.noise_db += 0.4 * (cur_floor - self.noise_db)   # drop fast
        else:
            self.noise_db += 0.05 * (cur_floor - self.noise_db)  # rise slow

    def has_speech(self, audio: np.ndarray) -> bool:
        if audio.size < self.frame:
            return True  # too short to judge — don't risk skipping filtering
        n = audio.size // self.frame
        frames = audio[: n * self.frame].reshape(n, self.frame)
        fdb = self._frame_db(frames)
        self._update_noise(fdb)
        thresh = self.noise_db + self.offset
        speech_frac = float(np.mean(fdb > thresh))
        return speech_frac >= self.min_speech_frac


class SileroVAD:
    def __init__(self, sample_rate: int, min_speech_frac: float = 0.15):
        import torch  # noqa: F401
        from silero_vad import load_silero_vad, get_speech_timestamps
        self.sr = sample_rate
        self.model = load_silero_vad()
        self._get_ts = get_speech_timestamps
        self.min_speech_frac = min_speech_frac

    def has_speech(self, audio: np.ndarray) -> bool:
        import torch
        wav = torch.from_numpy(audio.astype(np.float32))
        ts = self._get_ts(wav, self.model, sampling_rate=self.sr)
        if not ts:
            return False
        speech = sum(t["end"] - t["start"] for t in ts)
        return (speech / max(1, audio.size)) >= self.min_speech_frac


def make_vad(cfg):
    if cfg.vad == "off":
        return _AlwaysSpeech()
    if cfg.vad == "silero":
        try:
            return SileroVAD(cfg.sample_rate, cfg.vad_min_speech_frac)
        except Exception as e:
            print(f"[vad] silero unavailable ({e}); falling back to energy VAD.",
                  file=sys.stderr)
    return EnergyVAD(cfg.sample_rate,
                     min_speech_frac=cfg.vad_min_speech_frac,
                     offset_db=cfg.vad_energy_offset_db)
