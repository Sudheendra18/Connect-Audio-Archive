"""
realtime_filter.py
==================
Real-time profanity filter that BEEPS profane speech, with a fixed broadcast
delay so verdicts are ready before audio reaches the speaker.

Pipeline per analysis pass
--------------------------
    buffer of 1s segments
        -> take next BLOCK seconds of new audio (+CONTEXT before, +LOOKAHEAD
           after, purely to give Whisper clean word boundaries)
        -> VAD: is there speech in the block?  no -> mark safe instantly (skip)
        -> language: detect once with the SMALL model, re-verify every ~2 min;
           pin it so transcription never re-detects per window
        -> transcribe the window with the LIGHTER model + word timestamps
        -> wordlist: flag exact profane words -> beep just those milliseconds
           model net: if the window reads toxic but no listed word matched,
           beep the whole block (fail-safe for obscured / contextual profanity)
        -> tag the block's segments with their beep ranges
    delayed playback pops each segment once it's older than DELAY and plays it,
    beeping the tagged ranges. Unverified-in-time audio fails CLOSED.

Run
---
    python realtime/realtime_filter.py                     # mic -> speaker
    python realtime/realtime_filter.py --input file \
           --file in.wav --output-file censored.wav        # offline file
    bumble-auracast receive --output stdout | \
        python realtime/realtime_filter.py --input stdin   # Auracast / pipe

    python realtime/realtime_filter.py --help              # all options
"""

from __future__ import annotations

import os
import sys
import time
import math
import threading
import collections

import numpy as np

# ── make sibling modules + profanity/ importable when run as a script ────────
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for _p in (HERE, ROOT, os.path.join(ROOT, "profanity")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from config import RealtimeConfig, parse_args
from transcription import TranscriptionEngine
from vad import make_vad
import audio_io
from audio_io import make_beep, apply_beep_ranges, make_source, write_wav_mono, read_wav_mono
import profanity_wordlist


# ═════════════════════════════════════════════════════════════════════════════
# Toxicity model — lazy, optional, honors cfg.tox_threshold
# ═════════════════════════════════════════════════════════════════════════════

def make_tox(cfg: RealtimeConfig):
    """Return a callable text -> verdict dict, or None if the net is disabled."""
    if not cfg.use_model_net:
        return None
    try:
        from profanity_detector import detect_profanity  # loads the model now
    except Exception as e:
        print(f"[tox] model unavailable ({e}); running wordlist-only.", file=sys.stderr)
        return None

    thr = cfg.tox_threshold

    def _tox(text: str) -> dict:
        r = dict(detect_profanity(text))
        # apply the configured threshold rather than the detector's built-in one
        r["is_profane"] = (r.get("score", 0.0) / 100.0) >= thr
        return r

    return _tox


# ═════════════════════════════════════════════════════════════════════════════
# Analyzer — the shared brain used by both the live engine and the file runner
# ═════════════════════════════════════════════════════════════════════════════

class ProfanityAnalyzer:
    """
    Stateless w.r.t. the audio buffer; holds only language state. Given a
    transcription window and where the finalizable BLOCK sits inside it,
    returns beep spans (t0, t1) measured from the window's start.
    """
    def __init__(self, cfg, engine, vad, wordlist, tox):
        self.cfg = cfg
        self.engine = engine
        self.vad = vad
        self.wordlist = wordlist
        self.tox = tox
        self.language = cfg.force_language
        self.last_detect_t: float | None = None

    # ── language handling ────────────────────────────────────────────────────
    def _need_detect(self, now: float) -> bool:
        if self.cfg.force_language:
            return False
        if self.language is None:
            return True
        if self.cfg.lang_reverify_seconds <= 0:
            return False
        return (now - (self.last_detect_t or 0.0)) >= self.cfg.lang_reverify_seconds

    def _ensure_language(self, window_audio: np.ndarray, now: float) -> None:
        if not self._need_detect(now):
            return
        try:
            code, prob = self.engine.detect_language(window_audio)
        except Exception as e:
            print(f"[lang] detection failed ({e}); keeping '{self.language}'.",
                  file=sys.stderr)
            return
        first = self.language is None
        changed = (self.language is not None) and (code != self.language)
        self.language = code
        self.last_detect_t = now
        if first:
            print(f"[lang] detected language: {code} (p={prob:.2f})")
        elif changed:
            print(f"[lang] language changed -> {code} (p={prob:.2f})")

    # ── main entry ───────────────────────────────────────────────────────────
    def analyze_window(self, window_audio: np.ndarray,
                       block_start_t: float, block_end_t: float,
                       now: float) -> list:
        sr = self.cfg.sample_rate
        b0 = max(0, int(block_start_t * sr))
        b1 = min(len(window_audio), int(block_end_t * sr))
        block_audio = window_audio[b0:b1]

        # 1) VAD gate — silence / non-speech blocks need no transcription
        if not self.vad.has_speech(block_audio):
            return []

        # 2) language (detect with the small model; pin for transcription)
        self._ensure_language(window_audio, now)

        # 3) transcribe the whole window (context+block+lookahead) with words
        try:
            words = self.engine.transcribe(window_audio, self.language)
        except Exception as e:
            # fail CLOSED: beep the whole block rather than risk unfiltered audio
            print(f"[analysis] transcription error ({e}); beeping block.",
                  file=sys.stderr)
            return [(block_start_t, block_end_t)]

        spans = []
        matched_word = False

        # 4a) wordlist -> precise per-word spans
        if self.cfg.use_wordlist and self.wordlist is not None:
            for w in self.wordlist.match_words(words):
                spans.append((w.start, w.end))
                matched_word = True

        # keep only spans overlapping the finalizable block region
        spans = [(max(s, block_start_t), min(e, block_end_t))
                 for (s, e) in spans if e > block_start_t and s < block_end_t]

        # chunk-level mode: beep the whole block if anything flagged
        if self.cfg.beep_granularity == "window":
            if spans or self._window_toxic(words):
                return [(block_start_t, block_end_t)]
            return []

        # 4b) model net -> whole-block beep when toxic but unlocalized
        if self.tox is not None and not matched_word and self._window_toxic(words):
            spans.append((block_start_t, block_end_t))

        # 5) pad each span a touch so the bleep fully covers the word
        pad = self.cfg.beep_pad_ms / 1000.0
        spans = [(s - pad, e + pad) for (s, e) in spans]
        return spans

    def _window_toxic(self, words) -> bool:
        if self.tox is None:
            return False
        text = " ".join(w.text for w in words).strip()
        if not text:
            return False
        try:
            return bool(self.tox(text).get("is_profane"))
        except Exception:
            return False


# ═════════════════════════════════════════════════════════════════════════════
# Live engine — mic / stdin, threaded, with broadcast delay
# ═════════════════════════════════════════════════════════════════════════════

class Segment:
    __slots__ = ("seq", "samples", "start_sample", "analyzed", "beep_ranges",
                 "captured_at")

    def __init__(self, seq, samples, start_sample):
        self.seq = seq
        self.samples = samples
        self.start_sample = start_sample
        self.analyzed = False
        self.beep_ranges = []
        self.captured_at = time.time()


class RealtimeEngine:
    def __init__(self, cfg: RealtimeConfig, analyzer: ProfanityAnalyzer):
        self.cfg = cfg
        self.analyzer = analyzer
        self.buffer = collections.deque()
        self.lock = threading.Lock()
        self.next_seq = 0
        self.sample_counter = 0
        self.next_analysis_seq = 0
        self.stop_event = threading.Event()
        self.source_done = threading.Event()
        self.analysis_done = threading.Event()
        self._measured_pass = None
        self.delay = cfg.resolved_delay()
        # stats
        self._played = 0
        self._beeped_samples = 0
        self._passes = 0
        self._unverified = 0
        self._last_stats = time.time()

    # ── capture: source -> buffer ────────────────────────────────────────────
    def _capture_loop(self, source):
        try:
            for chunk in source:
                if self.stop_event.is_set():
                    break
                with self.lock:
                    seg = Segment(self.next_seq, chunk, self.sample_counter)
                    self.buffer.append(seg)
                    self.next_seq += 1
                    self.sample_counter += len(chunk)
        except Exception as e:
            print(f"[capture] stopped: {e}", file=sys.stderr)
        finally:
            self.source_done.set()

    # ── analysis: buffer -> beep ranges ──────────────────────────────────────
    def _analysis_loop(self):
        cfg = self.cfg
        B, C, LA = cfg.block_segments, cfg.context_segments, cfg.lookahead_segments
        poll = min(0.2, cfg.segment / 2)

        while not self.stop_event.is_set():
            with self.lock:
                if not self.buffer:
                    empty, min_seq, max_seq, snapshot = True, None, None, []
                else:
                    empty = False
                    min_seq = self.buffer[0].seq
                    max_seq = self.buffer[-1].seq
                    snapshot = list(self.buffer)

            if empty:
                if self.source_done.is_set():
                    break
                time.sleep(poll)
                continue

            start_seq = max(self.next_analysis_seq, min_seq)

            # end of stream and nothing left to analyze -> done
            if self.source_done.is_set() and start_seq > max_seq:
                self.analysis_done.set()
                break

            block_end_seq = start_seq + B - 1

            if not self.source_done.is_set() and max_seq < block_end_seq + LA:
                time.sleep(poll)
                continue

            block_end_seq = min(block_end_seq, max_seq)
            by_seq = {s.seq: s for s in snapshot}
            block = [by_seq[q] for q in range(start_seq, block_end_seq + 1) if q in by_seq]
            if not block:
                self.next_analysis_seq = block_end_seq + 1
                time.sleep(poll)
                continue
            ctx = [by_seq[q] for q in range(start_seq - C, start_seq) if q in by_seq]
            la = [by_seq[q] for q in range(block_end_seq + 1, block_end_seq + 1 + LA)
                  if q in by_seq]
            window_segs = ctx + block + la

            window_audio = np.concatenate([s.samples for s in window_segs])
            sr = cfg.sample_rate
            ctx_samples = sum(len(s.samples) for s in ctx)
            block_samples = sum(len(s.samples) for s in block)
            block_start_t = ctx_samples / sr
            block_end_t = (ctx_samples + block_samples) / sr
            now = block[0].captured_at

            t0 = time.time()
            spans = self.analyzer.analyze_window(window_audio, block_start_t,
                                                 block_end_t, now)
            self._measured_pass = time.time() - t0
            self._passes += 1

            win_start_global = window_segs[0].start_sample
            block_g0 = block[0].start_sample
            block_g1 = block[-1].start_sample + len(block[-1].samples)
            with self.lock:
                for (s, e) in spans:
                    g0 = max(block_g0, win_start_global + int(s * sr))
                    g1 = min(block_g1, win_start_global + int(e * sr))
                    if g1 <= g0:
                        continue
                    for seg in block:
                        s0 = seg.start_sample
                        s1 = s0 + len(seg.samples)
                        a = max(g0, s0) - s0
                        b = min(g1, s1) - s0
                        if b > a:
                            seg.beep_ranges.append((a, b))
                for seg in block:
                    seg.analyzed = True

            self.next_analysis_seq = block_end_seq + 1
            if self.source_done.is_set() and self.next_analysis_seq > max_seq:
                self.analysis_done.set()

        self.analysis_done.set()

    # ── playback: delayed buffer -> sink ─────────────────────────────────────
    def _playback_loop(self, sink):
        cfg = self.cfg
        while not self.stop_event.is_set():
            ready = None
            drain = self.source_done.is_set() and self.analysis_done.is_set()
            with self.lock:
                if self.buffer:
                    head = self.buffer[0]
                    age = time.time() - head.captured_at
                    if drain or age >= self.delay:
                        ready = self.buffer.popleft()
                elif drain:
                    break

            if ready is None:
                time.sleep(0.01)
                continue

            out = self._render(ready)
            sink.write(out)
            self._played += 1
            self._maybe_stats()

        with self.lock:
            leftovers = list(self.buffer)
            self.buffer.clear()
        for ready in leftovers:
            sink.write(self._render(ready))
            self._played += 1

    def _render(self, seg: "Segment") -> np.ndarray:
        cfg = self.cfg
        if seg.analyzed:
            self._beeped_samples += sum(b - a for a, b in seg.beep_ranges)
            return apply_beep_ranges(seg.samples, seg.beep_ranges,
                                     cfg.sample_rate, cfg.beep_freq, cfg.beep_gain)
        self._unverified += 1
        if cfg.unverified_action == "mute":
            return np.zeros_like(seg.samples)
        if cfg.unverified_action == "beep":
            return make_beep(len(seg.samples), cfg.sample_rate,
                             cfg.beep_freq, cfg.beep_gain)
        return seg.samples  # "pass"

    def _maybe_stats(self):
        if self.cfg.stats_interval <= 0:
            return
        now = time.time()
        if now - self._last_stats < self.cfg.stats_interval:
            return
        self._last_stats = now
        with self.lock:
            depth = len(self.buffer)
        pass_ms = (self._measured_pass or 0) * 1000
        played_s = self._played * self.cfg.segment
        beep_s = self._beeped_samples / self.cfg.sample_rate
        print(f"[stats] played={played_s:5.1f}s  beeped={beep_s:4.1f}s  "
              f"buffer={depth:2d} seg  passes={self._passes:3d}  "
              f"last_pass={pass_ms:4.0f}ms  unverified={self._unverified}")
        if self.cfg.delay is None and self._measured_pass:
            want = self.cfg.auto_delay(self._measured_pass)
            if want > self.delay + 0.5:
                print(f"[stats] analysis slower than expected; raising delay "
                      f"{self.delay:.1f}s -> {want:.1f}s")
                self.delay = want

    # ── run ──────────────────────────────────────────────────────────────────
    def run(self, source, sink):
        print(f"  Broadcast delay: {self.delay:.1f}s   backend: "
              f"{self.analyzer.engine.backend_name}   vad: {self.cfg.vad}")
        print("  Ctrl+C to stop.\n")
        threads = [
            threading.Thread(target=self._capture_loop, args=(source,), daemon=True),
            threading.Thread(target=self._analysis_loop, daemon=True),
            threading.Thread(target=self._playback_loop, args=(sink,), daemon=True),
        ]
        for t in threads:
            t.start()
        try:
            while True:
                if self.source_done.is_set() and not threads[2].is_alive():
                    break
                time.sleep(0.2)
        except KeyboardInterrupt:
            print("\n  Stopping…")
        finally:
            self.stop_event.set()
            for t in threads:
                t.join(timeout=3)
            try:
                sink.close()
            except Exception:
                pass


# ═════════════════════════════════════════════════════════════════════════════
# Offline file runner — deterministic, no threads; writes a censored wav
# ═════════════════════════════════════════════════════════════════════════════

def run_file_offline(cfg: RealtimeConfig, analyzer: ProfanityAnalyzer) -> dict:
    sr = cfg.sample_rate
    seg = cfg.segment_samples
    audio = read_wav_mono(cfg.input_file, sr)
    orig_len = len(audio)
    n_seg = max(1, math.ceil(orig_len / seg))
    padded = np.zeros(n_seg * seg, dtype=np.float32)
    padded[:orig_len] = audio
    out = padded.copy()

    B, C, LA = cfg.block_segments, cfg.context_segments, cfg.lookahead_segments
    total_beep = 0
    s = 0
    while s < n_seg:
        block_end = min(s + B, n_seg)
        ctx_start = max(0, s - C)
        la_end = min(block_end + LA, n_seg)
        w0, w1 = ctx_start * seg, la_end * seg
        window = padded[w0:w1]
        block_start_t = (s * seg - w0) / sr
        block_end_t = (block_end * seg - w0) / sr
        now = s * cfg.segment

        spans = analyzer.analyze_window(window, block_start_t, block_end_t, now)

        bg0, bg1 = s * seg, block_end * seg
        for (t0, t1) in spans:
            g0 = max(bg0, w0 + int(t0 * sr))
            g1 = min(bg1, w0 + int(t1 * sr))
            if g1 > g0:
                out[g0:g1] = make_beep(g1 - g0, sr, cfg.beep_freq, cfg.beep_gain)
                total_beep += g1 - g0
        s = block_end

    out = out[:orig_len]
    if cfg.output_file:
        write_wav_mono(cfg.output_file, out, sr)
        print(f"[output] censored audio -> {cfg.output_file}")
    beep_s = total_beep / sr
    print(f"[done] {orig_len/sr:.1f}s processed, {beep_s:.2f}s beeped, "
          f"language={analyzer.language}")
    return {"samples": out, "beeped_seconds": beep_s, "language": analyzer.language}


# ═════════════════════════════════════════════════════════════════════════════
# Wiring
# ═════════════════════════════════════════════════════════════════════════════

def build(cfg: RealtimeConfig) -> ProfanityAnalyzer:
    engine = TranscriptionEngine(cfg)
    vad = make_vad(cfg)
    wordlist = profanity_wordlist.Wordlist(cfg.wordlist_dir) if cfg.use_wordlist else None
    tox = make_tox(cfg)
    return ProfanityAnalyzer(cfg, engine, vad, wordlist, tox)


def main(argv=None):
    cfg = parse_args(argv)
    analyzer = build(cfg)

    if cfg.input == "file":
        run_file_offline(cfg, analyzer)
        return

    source = make_source(cfg)
    sinks = []
    if cfg.play_output:
        try:
            sinks.append(audio_io.SpeakerSink(cfg))
        except Exception as e:
            print(f"[output] no speaker ({e}); continuing without playback.",
                  file=sys.stderr)
    if cfg.output_file:
        sinks.append(audio_io.WavWriterSink(cfg))
    sink = audio_io.FanoutSink(sinks) if len(sinks) != 1 else sinks[0]

    RealtimeEngine(cfg, analyzer).run(source, sink)


if __name__ == "__main__":
    main()
