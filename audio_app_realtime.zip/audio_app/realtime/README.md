# Real-time profanity filter

Streams audio through a short **broadcast delay** and **beeps profane speech**
before it reaches the speaker. Built to expand your file-upload pipeline to live
audio, with an input layer that swaps cleanly to an **Auracast BIS receiver**
later.

```
mic / stdin / wav ─▶ ring buffer ─▶ VAD ─▶ [language once, then transcribe+flag] ─▶ delayed playback (beeped)
```

---

## What changed vs. your original `realtime_filter.py`

| Your request | What it does now |
|---|---|
| Buffer audio in chunks | Same ring buffer, but each segment carries a global sample offset so beep spans are sample-accurate |
| Detect language on initial chunks, then just check profanity | Language is detected **once** with the `small` model, then **pinned**; transcription reuses it and never re-detects |
| Re-verify language every ~2 min | `--lang-reverify 120` (seconds). Detected changes are logged and switch the pinned language |
| Lighter model for transcription | **Two models:** `small` for detection (your accuracy), a lighter one (`base`/`tiny`) for continuous transcription — `--transcribe-model` |
| Speed it up / throughput | (1) pinned language skips per-window detection, (2) **VAD** skips silence so Whisper never runs on it, (3) optional **faster-whisper** backend (~4× on CPU), (4) greedy decoding |
| Beep the chunk on profanity | Beeps by default at **word granularity** — only the profane word, not the whole chunk — using word timestamps + a bleep-list. `--beep-granularity window` restores whole-chunk beeping |
| (improvement) precision | Wordlist gives exact word spans; the toxicity **model is a safety net** that beeps the whole chunk only when it flags toxicity with no listed word located |
| (improvement) Auracast goal | Input is pluggable: `mic`, `file`, or raw-PCM `stdin`. Pipe an Auracast receiver straight in — no code change |
| (improvement) testability | `--input file` runs the whole pipeline offline and writes a censored wav; `selftest.py` validates logic with **no heavy deps** |

Your original filter **muted** flagged windows and re-translated **every** 4 s window with `small`. This one beeps precisely, only transcribes speech, and never re-detects language once it's known.

---

## Install

```bash
pip install -r ../requirements.txt          # from the realtime/ folder
# Linux mic/speaker also needs PortAudio:
sudo apt install libportaudio2
```

The transcription backend is auto-selected: **faster-whisper** if installed, else **openai-whisper**, else a **mock** stub (so nothing crashes if models are missing — useful for wiring up the Auracast path first).

---

## Usage

```bash
# Live mic → speaker
python realtime_filter.py

# Live, force English and use the fastest transcription model
python realtime_filter.py --force-language en --transcribe-model tiny

# Offline: censor a wav file and write the result
python realtime_filter.py --input file --file in.wav --output-file censored.wav

# Auracast / any external PCM producer (float32 mono @16k on stdout)
bumble-auracast receive --output stdout | \
    python realtime_filter.py --input stdin

python realtime_filter.py --help            # every knob
```

---

## The two-model design (why it's fast)

Language ID and transcription have opposite needs:

- **Language detection** wants accuracy but runs rarely → keep your **`small`** model, run it on the first few seconds and again every `--lang-reverify` seconds.
- **Transcription** runs constantly and only needs to be good enough to spot swear words → use a **lighter** model (`--transcribe-model base`, or `tiny` for max speed).

The multiplier is **pinning the language**. Your old code called Whisper's `translate`/auto path every window, which silently re-runs language detection each time. Once we know the language we pass `language=<code>`, so the transcriber skips detection entirely — faster **and** more accurate (no language flip-flop on short windows).

Low on RAM? `--same-model` uses one model for both (still pins the language).

---

## VAD — the throughput win on real audio

Real audio is mostly silence, noise, or music. The analysis loop asks the VAD
"is there speech in this block?" first; if not, the block is marked safe
**instantly** and Whisper never runs on it.

- `--vad energy` (default) — adaptive energy gate, zero extra deps. Tracks a
  noise floor and calls a block "speech" when it sits `--vad-energy-offset-db`
  above the floor. Deliberately lenient: a false "speech" just costs a little
  extra transcription; it never hides speech from the filter.
- `--vad silero` — neural VAD (needs `silero-vad`+`torch`), better on noisy /
  music-bed audio. Auto-falls back to energy VAD if it can't load.
- `--vad off` — transcribe everything.

---

## Beeping

- `--beep-granularity word` (default) — beep only the flagged word's
  milliseconds, using word timestamps. Padded by `--beep-pad-ms` so the tone
  fully covers the word.
- `--beep-granularity window` — beep the whole block if anything is flagged
  (closest to "beep that chunk"; use if word timestamps look unreliable).
- Tone: `--beep-freq` (default 1000 Hz censor tone), `--beep-gain`. The beep has
  short cosine fades so there are no clicks.

**Audio that misses its verdict** (analysis fell behind the delay) fails
**closed**: `--unverified mute` (default) plays silence, `beep` plays a tone,
`pass` lets it through (not recommended).

---

## Profanity detection — two layers

1. **Wordlist** (`profanity/profanity_wordlist.py`) — fast set lookup with
   leetspeak folding (`sh1t`, `@sshole`) and multi-word phrases. Gives the
   **exact** word span, so beeping is precise. Extend it for production:

   ```bash
   python realtime_filter.py --wordlist-dir /path/to/lists
   ```
   One UTF-8 file per language code (`en.txt`, `te.txt`, `hi.txt`, `ta.txt`…),
   one word/phrase per line, `#` for comments. The community-standard **LDNOOBW**
   ("List of Dirty, Naughty, Obscene, and Otherwise Bad Words") ships exactly
   this format for dozens of languages and drops straight in.

2. **Toxicity model net** (`unitary/multilingual-toxic-xlm-roberta`, your
   existing detector) — catches contextual/obscured profanity the wordlist
   misses. It gives a sentence-level verdict, so when it fires **without** a
   located word it beeps the whole block. `--tox-threshold` sets sensitivity;
   `--no-model-net` runs wordlist-only (fastest, fully offline).

---

## Tuning latency & throughput

Timing (all seconds): the transcription window Whisper sees is
`context + block + lookahead`; only `block` is finalized per pass.

```
--segment 1.0     capture chunk size
--block 3.0       new audio finalized per pass  (bigger = fewer passes, more latency)
--context 1.0     look-back for clean word starts at the block's leading edge
--lookahead 1.0   look-ahead for words crossing the block's trailing edge
--delay auto      broadcast delay; auto = block + lookahead + one pass + margin
```

**Delay budget:** a segment is safe to play once its block has been finalized,
which needs `block + lookahead` of audio captured plus one transcription pass.
`--delay auto` derives this and **refines it from measured pass times** shown by
`--stats`. If you see rising `buffer=` depth or `unverified>0` in the stats line,
analysis isn't keeping up — switch to `--transcribe-model tiny`, install
faster-whisper, use `--device cuda`, or raise `--delay`.

Rough starting points:

| Hardware | backend / model | typical delay |
|---|---|---|
| CPU laptop | faster-whisper `base` int8 | ~4–5 s |
| CPU laptop, max speed | faster-whisper `tiny` int8 | ~3 s |
| GPU | faster-whisper `base` float16 | ~2 s |

Measure yours with `--stats-interval 5` rather than trusting the table.

---

## Auracast integration path (your end goal)

The capture layer is the only Auracast-specific part, and it's isolated in
`audio_io.py`. Two ready options:

- **Pipe (works today):** any receiver that writes **float32 mono PCM @16 kHz**
  to stdout feeds the filter via `--input stdin`. No code change.
- **Native source:** add a class in `audio_io.py` next to `MicSource` that reads
  BIS frames from your Auracast stack and yields `segment_samples`-length float32
  chunks. Register it in `make_source()`. Nothing else changes.

On the Samsung sink side, the same engine runs; you'd replace the source with the
platform's decoded-PCM callback and the sink with its audio-out path.

---

## Testing

```bash
python selftest.py
```

Runs with the **mock backend** (no Whisper/torch/transformers), so it works
anywhere. It validates beep generation, VAD, wordlist matching, config, and the
**full offline pipeline** — synthesizing audio with a known profane word at a
known time and asserting the beep lands exactly there and nowhere else.

---

## File reference

| File | Role |
|---|---|
| `realtime_filter.py` | Orchestrator: analyzer core, threaded live engine, offline file runner |
| `config.py` | `RealtimeConfig` dataclass + CLI parsing + auto-delay |
| `transcription.py` | Backend abstraction (faster-whisper / openai-whisper / mock), dual-model, word timestamps |
| `vad.py` | Energy VAD (default) + optional Silero |
| `audio_io.py` | Beep, pluggable input sources (mic/file/stdin), sinks, wav helpers |
| `selftest.py` | Dependency-light validation |
| `../profanity/profanity_wordlist.py` | Fast word-precise bleep list |
| `../profanity/profanity_detector.py` | Your ML toxicity model (used as the safety net) |
| `../audio_pipeline.py` | Your original file-upload pipeline (unchanged) |
