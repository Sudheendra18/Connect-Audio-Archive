"""
config.py
=========
Central configuration for the real-time profanity filter.

Everything tunable lives in one `RealtimeConfig` dataclass so you can
experiment from the command line without editing engine code. `parse_args()`
builds a config from argv; `RealtimeConfig()` gives you the defaults directly.

Timing model (all seconds):

    SEGMENT   size of one captured chunk appended to the buffer
    BLOCK     amount of *new* audio finalized per analysis pass
    CONTEXT   extra audio *before* the block fed to Whisper (boundary words)
    LOOKAHEAD extra audio *after*  the block fed to Whisper (boundary words)
    DELAY     how long every segment is held back before playback

    transcription window  = CONTEXT + BLOCK + LOOKAHEAD   (what Whisper sees)
    finalized per pass    = BLOCK                          (what we tag & advance)

DELAY must exceed  (BLOCK + LOOKAHEAD + one transcription pass + margin),
otherwise segments reach the speaker before their verdict is known and get
muted for being unverified (the filter fails CLOSED). If DELAY == "auto"
the engine derives a safe value and refines it from measured pass times.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field


@dataclass
class RealtimeConfig:
    # ── Audio format ─────────────────────────────────────────────────────────
    sample_rate: int = 16000          # Whisper wants 16 kHz mono
    channels: int = 1

    # ── Input / output ───────────────────────────────────────────────────────
    input: str = "mic"                # "mic" | "file" | "stdin"
    input_file: str | None = None     # required when input == "file"
    output_file: str | None = None    # file mode: write censored wav here
    play_output: bool = True          # mic/stdin: also play to speaker

    # ── Models ───────────────────────────────────────────────────────────────
    backend: str = "auto"             # "auto" | "faster" | "openai" | "mock"
    lang_model: str = "small"         # Whisper size for LANGUAGE DETECTION
    transcribe_model: str = "base"    # lighter size for CONTINUOUS transcription
    same_model: bool = False          # reuse lang_model for transcription too
    device: str = "cpu"               # "cpu" | "cuda"
    compute_type: str = "int8"        # faster-whisper: int8 / int8_float16 / float16

    # ── Timing (seconds) ─────────────────────────────────────────────────────
    segment: float = 1.0
    block: float = 3.0
    context: float = 1.0
    lookahead: float = 1.0
    delay: float | None = None        # None => auto

    # ── Language handling ────────────────────────────────────────────────────
    initial_lang_seconds: float = 5.0     # speech to gather before first detect
    lang_reverify_seconds: float = 120.0  # re-detect language every N s (0 = never)
    force_language: str | None = None     # skip detection, pin this code (e.g. "en")

    # ── VAD (voice activity detection) ───────────────────────────────────────
    vad: str = "energy"               # "energy" | "silero" | "off"
    vad_min_speech_frac: float = 0.15 # fraction of frames that must be speech
    vad_energy_offset_db: float = 8.0 # dB above the running noise floor = speech

    # ── Profanity detection ──────────────────────────────────────────────────
    use_wordlist: bool = True         # fast, word-precise bleep list
    use_model_net: bool = True        # toxicity model as a window-level safety net
    tox_threshold: float = 0.70       # >= this on any offensive label => flag
    wordlist_dir: str | None = None   # extra LDNOOBW-style word files (one per lang)

    # ── Beeping ──────────────────────────────────────────────────────────────
    beep_granularity: str = "word"    # "word" (precise) | "window" (whole chunk)
    beep_freq: float = 1000.0         # classic censor tone, Hz
    beep_gain: float = 0.5            # 0..1 amplitude
    beep_pad_ms: float = 60.0         # widen each flagged span by this on both sides
    unverified_action: str = "mute"   # what to do with audio that missed its verdict
                                      #   "mute" | "beep" | "pass"

    # ── Diagnostics ──────────────────────────────────────────────────────────
    stats_interval: float = 5.0       # print throughput stats every N s (0 = off)
    verbose: bool = False

    # derived / runtime (not set from CLI)
    _extra: dict = field(default_factory=dict)

    # ── Derived helpers ──────────────────────────────────────────────────────
    @property
    def segment_samples(self) -> int:
        return int(round(self.segment * self.sample_rate))

    @property
    def block_segments(self) -> int:
        return max(1, int(round(self.block / self.segment)))

    @property
    def context_segments(self) -> int:
        return max(0, int(round(self.context / self.segment)))

    @property
    def lookahead_segments(self) -> int:
        return max(0, int(round(self.lookahead / self.segment)))

    def auto_delay(self, measured_pass_seconds: float | None = None) -> float:
        """
        Safe playback delay = block + lookahead + a transcription pass + margin.
        If we have a measured pass time, use it (with headroom); otherwise guess
        conservatively from the transcription model size.
        """
        if measured_pass_seconds is not None:
            pass_cost = measured_pass_seconds * 1.6 + 0.3
        else:
            guess = {"tiny": 0.6, "base": 1.2, "small": 2.5,
                     "medium": 5.0, "large": 9.0}
            pass_cost = guess.get(self.transcribe_model, 1.5)
            if self.device == "cuda":
                pass_cost *= 0.35
        return round(self.block + self.lookahead + pass_cost + 0.5, 2)

    def resolved_delay(self, measured_pass_seconds: float | None = None) -> float:
        if self.delay is not None:
            return self.delay
        return self.auto_delay(measured_pass_seconds)


def parse_args(argv=None) -> RealtimeConfig:
    p = argparse.ArgumentParser(
        prog="realtime_filter",
        description="Real-time profanity filter (beeps profane speech with a broadcast delay).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    io = p.add_argument_group("input / output")
    io.add_argument("--input", choices=["mic", "file", "stdin"], default="mic")
    io.add_argument("--file", dest="input_file", help="input wav (with --input file)")
    io.add_argument("--output-file", dest="output_file",
                    help="write censored wav here (file mode)")
    io.add_argument("--no-play", dest="play_output", action="store_false",
                    help="do not play to the speaker (mic/stdin)")

    md = p.add_argument_group("models")
    md.add_argument("--backend", choices=["auto", "faster", "openai", "mock"], default="auto")
    md.add_argument("--lang-model", default="small",
                    help="Whisper size used ONLY for language detection")
    md.add_argument("--transcribe-model", default="base",
                    help="lighter Whisper size used for continuous transcription")
    md.add_argument("--same-model", action="store_true",
                    help="use --lang-model for transcription too (less RAM, slower)")
    md.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    md.add_argument("--compute-type", default="int8",
                    help="faster-whisper compute type (int8 / int8_float16 / float16)")

    tm = p.add_argument_group("timing (seconds)")
    tm.add_argument("--segment", type=float, default=1.0)
    tm.add_argument("--block", type=float, default=3.0)
    tm.add_argument("--context", type=float, default=1.0)
    tm.add_argument("--lookahead", type=float, default=1.0)
    tm.add_argument("--delay", default="auto",
                    help='playback delay in seconds, or "auto"')

    lg = p.add_argument_group("language")
    lg.add_argument("--initial-lang", dest="initial_lang_seconds", type=float, default=5.0)
    lg.add_argument("--lang-reverify", dest="lang_reverify_seconds", type=float, default=120.0,
                    help="re-detect language every N seconds (0 = never)")
    lg.add_argument("--force-language", default=None,
                    help='skip detection, pin this code e.g. "en", "te", "hi"')

    vd = p.add_argument_group("voice activity detection")
    vd.add_argument("--vad", choices=["energy", "silero", "off"], default="energy")
    vd.add_argument("--vad-min-speech-frac", type=float, default=0.15)
    vd.add_argument("--vad-energy-offset-db", type=float, default=8.0)

    pf = p.add_argument_group("profanity")
    pf.add_argument("--no-wordlist", dest="use_wordlist", action="store_false")
    pf.add_argument("--no-model-net", dest="use_model_net", action="store_false")
    pf.add_argument("--tox-threshold", type=float, default=0.70)
    pf.add_argument("--wordlist-dir", default=None,
                    help="folder of extra word files, one per language code (te.txt, hi.txt…)")

    bp = p.add_argument_group("beeping")
    bp.add_argument("--beep-granularity", choices=["word", "window"], default="word")
    bp.add_argument("--beep-freq", type=float, default=1000.0)
    bp.add_argument("--beep-gain", type=float, default=0.5)
    bp.add_argument("--beep-pad-ms", type=float, default=60.0)
    bp.add_argument("--unverified", dest="unverified_action",
                    choices=["mute", "beep", "pass"], default="mute")

    dg = p.add_argument_group("diagnostics")
    dg.add_argument("--stats-interval", type=float, default=5.0)
    dg.add_argument("-v", "--verbose", action="store_true")

    ns = p.parse_args(argv)

    delay = None if str(ns.delay).lower() == "auto" else float(ns.delay)

    return RealtimeConfig(
        input=ns.input,
        input_file=ns.input_file,
        output_file=ns.output_file,
        play_output=ns.play_output,
        backend=ns.backend,
        lang_model=ns.lang_model,
        transcribe_model=ns.transcribe_model,
        same_model=ns.same_model,
        device=ns.device,
        compute_type=ns.compute_type,
        segment=ns.segment,
        block=ns.block,
        context=ns.context,
        lookahead=ns.lookahead,
        delay=delay,
        initial_lang_seconds=ns.initial_lang_seconds,
        lang_reverify_seconds=ns.lang_reverify_seconds,
        force_language=ns.force_language,
        vad=ns.vad,
        vad_min_speech_frac=ns.vad_min_speech_frac,
        vad_energy_offset_db=ns.vad_energy_offset_db,
        use_wordlist=ns.use_wordlist,
        use_model_net=ns.use_model_net,
        tox_threshold=ns.tox_threshold,
        wordlist_dir=ns.wordlist_dir,
        beep_granularity=ns.beep_granularity,
        beep_freq=ns.beep_freq,
        beep_gain=ns.beep_gain,
        beep_pad_ms=ns.beep_pad_ms,
        unverified_action=ns.unverified_action,
        stats_interval=ns.stats_interval,
        verbose=ns.verbose,
    )
