"""Data models shared across the app."""
from dataclasses import dataclass, field, asdict
from typing import Optional, List
import json
import uuid
from datetime import datetime, timezone


@dataclass
class AnalysisRecord:
    audio_type: str
    language: Optional[str] = None
    confidence: Optional[float] = None
    duration: float = 0.0
    filename: str = "audio"
    timestamp: str = ""
    id: str = ""

    def __post_init__(self):
        if not self.id:
            self.id = uuid.uuid4().hex
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "AnalysisRecord":
        return AnalysisRecord(
            audio_type=d.get("audio_type", "Unknown"),
            language=d.get("language"),
            confidence=d.get("confidence"),
            duration=d.get("duration", 0.0),
            filename=d.get("filename", "audio"),
            timestamp=d.get("timestamp", ""),
            id=d.get("id", ""),
        )

    @property
    def display_time(self) -> str:
        try:
            dt = datetime.fromisoformat(self.timestamp)
            return dt.strftime("%b %d, %Y %I:%M %p")
        except Exception:
            return self.timestamp


@dataclass
class AppState:
    backend_url: str = "http://10.0.2.2:8000"
    history: List[AnalysisRecord] = field(default_factory=list)
    current_result: Optional[AnalysisRecord] = None
    dark_mode: bool = False

    def add_record(self, record: AnalysisRecord) -> None:
        self.history.insert(0, record)

    def history_to_json(self) -> str:
        return json.dumps([r.to_dict() for r in self.history])

    @staticmethod
    def history_from_json(s: str) -> List[AnalysisRecord]:
        if not s:
            return []
        try:
            return [AnalysisRecord.from_dict(d) for d in json.loads(s)]
        except Exception:
            return []

    def counts(self) -> dict:
        counts = {"Speech": 0, "Music": 0, "Noise": 0}
        for r in self.history:
            counts[r.audio_type] = counts.get(r.audio_type, 0) + 1
        return counts

    def language_distribution(self) -> dict:
        dist: dict = {}
        for r in self.history:
            if r.language:
                dist[r.language] = dist.get(r.language, 0) + 1
        return dist
