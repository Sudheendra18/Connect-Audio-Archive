"""Talks to the FastAPI backend that wraps the SVM + Whisper pipeline."""
from typing import Optional
import httpx


class ApiError(Exception):
    pass


async def check_health(backend_url: str) -> bool:
    url = f"{backend_url.rstrip('/')}/health"
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(url)
            return resp.status_code == 200
    except Exception:
        return False


async def analyze_audio(
    backend_url: str,
    file_path: Optional[str] = None,
    file_bytes: Optional[bytes] = None,
    filename: str = "audio.wav",
) -> dict:
    """
    Sends an audio file to the backend's /analyze endpoint.

    Returns a dict like:
        {
            "audio_type": "Speech",
            "language": "French",
            "confidence": 0.92,
            "duration": 4.3,
            "filename": "clip.wav",
            "timestamp": "2026-06-22T10:00:00+00:00"
        }
    """
    url = f"{backend_url.rstrip('/')}/analyze"

    if file_bytes is None and file_path is not None:
        with open(file_path, "rb") as f:
            file_bytes = f.read()

    if file_bytes is None:
        raise ApiError("No audio data provided")

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            files = {"file": (filename, file_bytes)}
            response = await client.post(url, files=files)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text
        raise ApiError(f"Server error ({exc.response.status_code}): {detail}") from exc
    except httpx.RequestError as exc:
        raise ApiError(f"Could not reach backend at {backend_url}: {exc}") from exc
