"""
Theme, design tokens, and shared UI components — Flet 0.85.3.

Visual identity: CLEAN LIGHT
──────────────────────────────────────────────────────────────────
• Surfaces: White / soft grey (#FFFFFF, #F7F8FA, #EEF0F4)
• Primary:  Indigo blue (#4F6EF7) with violet accent (#7C5CF6)
• Accent:   Teal (#0EA5B0)
• Success:  Green (#16A34A)
• Danger:   Red (#EF4444)
• Text:     Near-black (#111827), muted slate (#6B7280)
──────────────────────────────────────────────────────────────────
"""
import flet as ft

# ── Core palette ────────────────────────────────────────────────

PRIMARY       = "#4F6EF7"   # indigo blue
PRIMARY_LIGHT = "#7B93F9"
PRIMARY_DIM   = "#3B56D4"
VIOLET        = "#7C5CF6"
VIOLET_LIGHT  = "#9C7FF9"
MAGENTA       = "#D946A8"
TEAL          = "#0EA5B0"
TEAL_DIM      = "#0B8C96"
GREEN         = "#16A34A"

SPEECH_COLOR  = "#4F6EF7"   # blue
MUSIC_COLOR   = "#7C5CF6"   # violet
NOISE_COLOR   = "#F59E0B"   # amber

# Surfaces (light)
BG            = "#F7F8FA"   # page background
SURFACE_0     = "#F7F8FA"   # deepest background
SURFACE_1     = "#FFFFFF"   # card / nav bar
SURFACE_2     = "#EEF0F4"   # input / chip
SURFACE_3     = "#E2E5EC"   # divider / hover

ON_PRIMARY    = "#FFFFFF"
ON_SURFACE    = "#111827"   # near-black text
ON_SURFACE_2  = "#6B7280"   # muted / label
DIVIDER       = "#E5E7EB"

DANGER        = "#EF4444"

# ── Convenience aliases ─────────────────────────────────────────

ACCENT        = TEAL
ACCENT_DIM    = TEAL_DIM
CYAN          = TEAL
CYAN_DIM      = TEAL_DIM

# ── Semantic maps ────────────────────────────────────────────────

TYPE_COLORS = {
    "Speech": SPEECH_COLOR,
    "Music":  MUSIC_COLOR,
    "Noise":  NOISE_COLOR,
}

TYPE_ICONS = {
    "Speech": ft.Icons.RECORD_VOICE_OVER_ROUNDED,
    "Music":  ft.Icons.MUSIC_NOTE_ROUNDED,
    "Noise":  ft.Icons.GRAPHIC_EQ_ROUNDED,
}

NAV_ROUTES = ["/", "/history", "/analytics", "/settings"]

LANGUAGE_PALETTE = [
    "#4F6EF7", "#7C5CF6", "#0EA5B0", "#F59E0B",
    "#D946A8", "#2563EB", "#EF4444", "#9C7FF9",
    "#16A34A", "#F97316", "#06B6D4", "#EC4899",
]


# ── Theme ────────────────────────────────────────────────────────

def make_theme() -> ft.Theme:
    return ft.Theme(
        color_scheme_seed=PRIMARY,
        use_material3=True,
    )


# ── Color helpers ────────────────────────────────────────────────

def type_color(audio_type: str) -> str:
    return TYPE_COLORS.get(audio_type, PRIMARY)


def type_icon(audio_type: str):
    return TYPE_ICONS.get(audio_type, ft.Icons.AUDIOTRACK_ROUNDED)


# ── Shared UI components ─────────────────────────────────────────

def neon_icon_container(
    icon,
    color: str,
    size: int = 20,
    container_size: int = 44,
    border_radius: int = 14,
) -> ft.Container:
    """Icon in a soft tinted circle — light style."""
    return ft.Container(
        content=ft.Icon(icon, color=color, size=size),
        width=container_size,
        height=container_size,
        border_radius=border_radius,
        bgcolor=f"{color}18",
        border=ft.Border.all(1, f"{color}35"),
        alignment=ft.alignment.center,
    )


def type_badge(audio_type: str, large: bool = False) -> ft.Container:
    """Colored pill badge for audio type label."""
    color = type_color(audio_type)
    return ft.Container(
        content=ft.Text(
            audio_type,
            size=11 if not large else 13,
            color=color,
            weight=ft.FontWeight.W_700,
        ),
        padding=ft.padding.symmetric(horizontal=10 if not large else 14, vertical=3 if not large else 5),
        border_radius=20,
        bgcolor=f"{color}15",
        border=ft.Border.all(1, f"{color}35"),
    )


def stat_card(label: str, value: str, icon, color: str) -> ft.Container:
    return ft.Container(
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=4,
            controls=[
                ft.Container(
                    content=ft.Icon(icon, color=color, size=18),
                    width=38,
                    height=38,
                    border_radius=12,
                    bgcolor=f"{color}15",
                    border=ft.Border.all(1, f"{color}30"),
                    alignment=ft.alignment.center,
                ),
                ft.Text(
                    value,
                    size=18,
                    weight=ft.FontWeight.BOLD,
                    color=ON_SURFACE,
                ),
                ft.Text(
                    label,
                    size=10,
                    color=ON_SURFACE_2,
                ),
            ],
        ),
        padding=ft.padding.symmetric(vertical=14, horizontal=8),
        border_radius=16,
        bgcolor=SURFACE_1,
        border=ft.Border.all(1, DIVIDER),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=8,
            color="#00000010",
            offset=ft.Offset(0, 2),
        ),
        alignment=ft.alignment.center,
    )


def glass_card(content: ft.Control, padding=None, glow_color: str = None) -> ft.Container:
    """White card with light shadow. Accepts optional glow_color (unused visually but accepted)."""
    shadow_color = f"{glow_color}15" if glow_color else "#00000012"
    return ft.Container(
        content=content,
        padding=padding or ft.padding.all(16),
        border_radius=20,
        bgcolor=SURFACE_1,
        border=ft.Border.all(1, DIVIDER),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=12,
            color=shadow_color,
            offset=ft.Offset(0, 3),
        ),
    )


def section_label(text: str, color: str = None) -> ft.Text:
    return ft.Text(
        text.upper(),
        size=11,
        weight=ft.FontWeight.W_700,
        color=color or ON_SURFACE_2,
        style=ft.TextStyle(letter_spacing=0.8),
    )


def ghost_button(
    label: str,
    icon,
    on_click,
    expand: bool = False,
) -> ft.OutlinedButton:
    """Outlined ghost button."""
    return ft.OutlinedButton(
        content=ft.Row(
            spacing=6,
            alignment=ft.MainAxisAlignment.CENTER,
            controls=[
                ft.Icon(icon, size=16, color=ON_SURFACE_2),
                ft.Text(label, size=14, color=ON_SURFACE_2, weight=ft.FontWeight.W_600),
            ],
        ),
        style=ft.ButtonStyle(
            side=ft.BorderSide(1, DIVIDER),
            shape=ft.RoundedRectangleBorder(radius=14),
            padding=ft.padding.symmetric(horizontal=20, vertical=14),
            overlay_color=f"{PRIMARY}10",
        ),
        on_click=on_click,
        expand=expand,
    )


def accent_button(
    label: str,
    icon,
    on_click,
    expand: bool = False,
) -> ft.ElevatedButton:
    """Filled accent button."""
    return ft.ElevatedButton(
        content=ft.Row(
            spacing=6,
            alignment=ft.MainAxisAlignment.CENTER,
            controls=[
                ft.Icon(icon, size=16, color=ON_PRIMARY),
                ft.Text(label, size=14, color=ON_PRIMARY, weight=ft.FontWeight.W_600),
            ],
        ),
        style=ft.ButtonStyle(
            bgcolor={
                ft.ControlState.DEFAULT: PRIMARY,
                ft.ControlState.HOVERED: PRIMARY_DIM,
            },
            color=ON_PRIMARY,
            shape=ft.RoundedRectangleBorder(radius=14),
            padding=ft.padding.symmetric(horizontal=20, vertical=14),
            elevation=0,
        ),
        on_click=on_click,
        expand=expand,
    )


def build_nav_bar(page: ft.Page, selected: int) -> ft.NavigationBar:
    return ft.NavigationBar(
        selected_index=selected,
        bgcolor=SURFACE_1,
        indicator_color=f"{PRIMARY}18",
        shadow_color="#00000015",
        surface_tint_color=PRIMARY,
        destinations=[
            ft.NavigationBarDestination(
                icon=ft.Icons.HOME_OUTLINED,
                selected_icon=ft.Icons.HOME_ROUNDED,
                label="Home",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.HISTORY_OUTLINED,
                selected_icon=ft.Icons.HISTORY_ROUNDED,
                label="History",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.BAR_CHART_OUTLINED,
                selected_icon=ft.Icons.BAR_CHART_ROUNDED,
                label="Analytics",
            ),
            ft.NavigationBarDestination(
                icon=ft.Icons.SETTINGS_OUTLINED,
                selected_icon=ft.Icons.SETTINGS_ROUNDED,
                label="Settings",
            ),
        ],
        on_change=lambda e: page.go(NAV_ROUTES[e.control.selected_index]),
    )
