"""Local persistence using page.client_storage (Flet 0.85.3).

Falls back to in-memory defaults gracefully if client storage isn't available.
"""
import flet as ft
from models import AppState

HISTORY_KEY     = "analysis_history"
THEME_KEY       = "dark_mode"
BACKEND_URL_KEY = "backend_url"


async def _safe_get(page: ft.Page, key: str):
    """Return value or None on any error."""
    try:
        return await page.client_storage.get_async(key)
    except Exception:
        return None


async def _safe_set(page: ft.Page, key: str, value) -> None:
    try:
        await page.client_storage.set_async(key, value)
    except Exception:
        pass


async def _safe_remove(page: ft.Page, key: str) -> None:
    try:
        await page.client_storage.remove_async(key)
    except Exception:
        pass


async def load_state(page: ft.Page, state: AppState) -> None:
    history_json = await _safe_get(page, HISTORY_KEY)
    if isinstance(history_json, str):
        state.history = AppState.history_from_json(history_json)

    dark = await _safe_get(page, THEME_KEY)
    state.dark_mode = bool(dark) if dark is not None else False

    backend_url = await _safe_get(page, BACKEND_URL_KEY)
    if isinstance(backend_url, str) and backend_url:
        state.backend_url = backend_url


async def save_history(page: ft.Page, state: AppState) -> None:
    await _safe_set(page, HISTORY_KEY, state.history_to_json())


async def save_theme(page: ft.Page, state: AppState) -> None:
    await _safe_set(page, THEME_KEY, state.dark_mode)


async def save_backend_url(page: ft.Page, state: AppState) -> None:
    await _safe_set(page, BACKEND_URL_KEY, state.backend_url)


async def clear_history(page: ft.Page, state: AppState) -> None:
    state.history = []
    await _safe_remove(page, HISTORY_KEY)
