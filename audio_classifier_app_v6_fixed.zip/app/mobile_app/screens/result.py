"""Result screen — hero badge with glow and detail cards."""
import flet as ft
from models import AppState
import theme as th


def _detail_row(label: str, value: str, icon, color: str = th.ON_SURFACE_2) -> ft.Container:
    return ft.Container(
        content=ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Row(
                    spacing=12,
                    controls=[
                        ft.Container(
                            content=ft.Icon(icon, size=16, color=color),
                            width=32,
                            height=32,
                            border_radius=10,
                            bgcolor=f"{color}15",
                            alignment=ft.alignment.center,
                        ),
                        ft.Text(label, size=13, color=th.ON_SURFACE_2),
                    ],
                ),
                ft.Text(
                    value,
                    size=13,
                    weight=ft.FontWeight.W_700,
                    color=th.ON_SURFACE,
                ),
            ],
        ),
        padding=ft.padding.symmetric(horizontal=0, vertical=4),
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    record = state.current_result

    if record is None:
        body = ft.Container(
            padding=ft.padding.all(40),
            content=ft.Text("No result available.", color=th.ON_SURFACE_2),
        )
    else:
        color = th.type_color(record.audio_type)
        icon  = th.type_icon(record.audio_type)
        conf  = f"{record.confidence * 100:.1f}%" if record.confidence is not None else "—"
        lang  = record.language or "—"

        conf_val = record.confidence or 0
        conf_pct = int(conf_val * 100)

        # ── Hero ─────────────────────────────────────────────────
        hero = ft.Container(
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=16,
                controls=[
                    # Triple-ring orb
                    ft.Stack(
                        width=140,
                        height=140,
                        controls=[
                            ft.Container(
                                width=140,
                                height=140,
                                border_radius=70,
                                bgcolor=f"{color}08",
                            ),
                            ft.Container(
                                width=110,
                                height=110,
                                border_radius=55,
                                bgcolor=f"{color}15",
                                margin=ft.margin.all(15),
                            ),
                            ft.Container(
                                width=80,
                                height=80,
                                border_radius=40,
                                bgcolor=color,
                                margin=ft.margin.all(30),
                                alignment=ft.alignment.center,
                                content=ft.Icon(icon, color="#FFFFFF", size=36),
                                shadow=ft.BoxShadow(
                                    spread_radius=0,
                                    blur_radius=40,
                                    color=f"{color}80",
                                ),
                            ),
                        ],
                    ),

                    ft.Text(
                        record.audio_type,
                        size=30,
                        weight=ft.FontWeight.BOLD,
                        color=th.ON_SURFACE,
                    ),

                    th.type_badge(record.audio_type, large=True),

                    ft.Text(
                        record.filename,
                        size=12,
                        color=th.ON_SURFACE_2,
                        max_lines=1,
                        overflow=ft.TextOverflow.ELLIPSIS,
                    ),
                ],
            ),
            padding=ft.padding.symmetric(vertical=28, horizontal=16),
            border_radius=24,
            bgcolor=th.SURFACE_1,
            border=ft.Border.all(1, f"{color}30"),
            shadow=ft.BoxShadow(
                spread_radius=0,
                blur_radius=32,
                color=f"{color}20",
                offset=ft.Offset(0, 4),
            ),
        )

        # ── Confidence bar ────────────────────────────────────────
        conf_bar = ft.Container(
            content=ft.Column(
                spacing=10,
                controls=[
                    ft.Row(
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        controls=[
                            th.section_label("Confidence"),
                            ft.Text(
                                conf,
                                size=14,
                                weight=ft.FontWeight.BOLD,
                                color=color,
                            ),
                        ],
                    ),
                    ft.Container(
                        height=8,
                        border_radius=4,
                        bgcolor=th.SURFACE_3,
                        content=ft.Row(
                            expand=True,
                            controls=[
                                ft.Container(
                                    height=8,
                                    border_radius=4,
                                    bgcolor=color,
                                    expand=conf_pct if conf_pct > 0 else 1,
                                    shadow=ft.BoxShadow(
                                        spread_radius=0,
                                        blur_radius=8,
                                        color=f"{color}88",
                                    ),
                                ),
                                ft.Container(expand=max(100 - conf_pct, 0)),
                            ],
                        ),
                    ),
                ],
            ),
            padding=ft.padding.all(16),
            border_radius=16,
            bgcolor=th.SURFACE_1,
            border=ft.Border.all(1, th.DIVIDER),
        )

        # ── Detail card ───────────────────────────────────────────
        detail_card = ft.Container(
            content=ft.Column(
                spacing=0,
                controls=[
                    _detail_row("Language", lang,
                                ft.Icons.LANGUAGE_ROUNDED, th.SPEECH_COLOR),
                    ft.Container(height=1, bgcolor=th.DIVIDER,
                                 margin=ft.margin.symmetric(vertical=8)),
                    _detail_row("Duration", f"{record.duration:.1f}s",
                                ft.Icons.TIMER_ROUNDED, th.MUSIC_COLOR),
                    ft.Container(height=1, bgcolor=th.DIVIDER,
                                 margin=ft.margin.symmetric(vertical=8)),
                    _detail_row("Analyzed", record.display_time,
                                ft.Icons.SCHEDULE_ROUNDED, th.VIOLET_LIGHT),
                ],
            ),
            padding=ft.padding.all(16),
            border_radius=16,
            bgcolor=th.SURFACE_1,
            border=ft.Border.all(1, th.DIVIDER),
        )

        body = ft.Column(
            spacing=16,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
            controls=[hero, conf_bar, detail_card],
        )

    action_row = ft.Row(
        spacing=12,
        controls=[
            th.ghost_button(
                "History",
                ft.Icons.HISTORY_ROUNDED,
                lambda e: page.go("/history"),
                expand=True,
            ),
            th.accent_button(
                "Done",
                ft.Icons.CHECK_ROUNDED,
                lambda e: page.go("/"),
                expand=True,
            ),
        ],
    )

    return ft.View(
        route="/result",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Analysis Result", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(
                icon=ft.Icons.ARROW_BACK_IOS_NEW_ROUNDED,
                icon_color=th.ON_SURFACE_2,
                icon_size=20,
                on_click=lambda e: page.go("/"),
            ),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.all(20),
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                    controls=[body, action_row],
                ),
            )
        ],
    )
