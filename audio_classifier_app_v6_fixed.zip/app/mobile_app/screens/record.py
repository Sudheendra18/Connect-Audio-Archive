"""Record screen — microphone capture with live timer and animated waveform."""
import asyncio
import math
import os
import time
import flet as ft
from flet_audio_recorder import AudioRecorder, AudioRecorderConfiguration, AudioEncoder

from models import AppState, AnalysisRecord
import api_client
import storage as storage_mod
import theme as th


def _bar(height: int, color: str) -> ft.Container:
    return ft.Container(
        width=4,
        height=height,
        border_radius=2,
        bgcolor=color,
    )


def build_view(page: ft.Page, state: AppState, audio_recorder: AudioRecorder) -> ft.View:
    mic_icon_ref  = ft.Ref[ft.Icon]()
    mic_ring      = ft.Ref[ft.Container]()
    mic_core      = ft.Ref[ft.Container]()
    record_btn_text = ft.Ref[ft.Text]()
    status_text   = ft.Ref[ft.Text]()
    timer_text    = ft.Ref[ft.Text]()
    progress      = ft.Ref[ft.ProgressRing]()
    analyze_btn   = ft.Ref[ft.ElevatedButton]()
    wave_row      = ft.Ref[ft.Container]()

    rec_state = {"recording": False, "path": None, "start": 0.0}

    bar_refs = [ft.Ref[ft.Container]() for _ in range(11)]
    bar_heights = [8, 14, 22, 30, 38, 44, 38, 30, 22, 14, 8]

    async def animate_wave():
        t = 0
        while rec_state["recording"]:
            for i, ref in enumerate(bar_refs):
                if ref.current:
                    phase = t + i * 0.6
                    h = int(bar_heights[i] * (0.4 + 0.6 * abs(math.sin(phase))))
                    ref.current.height = max(4, h)
            page.update()
            await asyncio.sleep(0.08)
            t += 0.3

    async def tick():
        while rec_state["recording"]:
            elapsed = time.time() - rec_state["start"]
            mins, secs = divmod(int(elapsed), 60)
            timer_text.current.value = f"{mins:02d}:{secs:02d}"
            page.update()
            await asyncio.sleep(1)

    async def toggle_recording(e):
        if not rec_state["recording"]:
            has_perm = await audio_recorder.has_permission_async()
            if not has_perm:
                status_text.current.value = "Microphone permission denied"
                status_text.current.color = th.DANGER
                page.update()
                return

            tmp_dir = await page.get_upload_url_async("", 0) or "/tmp"
            # Use a temp path that works cross-platform
            import tempfile
            output_path = os.path.join(tempfile.gettempdir(), f"recording_{int(time.time())}.wav")

            await audio_recorder.start_recording_async(
                output_path=output_path,
                configuration=AudioRecorderConfiguration(encoder=AudioEncoder.WAV),
            )
            rec_state["recording"] = True
            rec_state["start"]     = time.time()
            rec_state["path"]      = output_path

            # UI → recording state
            mic_icon_ref.current.color  = "#FFFFFF"
            mic_core.current.bgcolor    = th.DANGER
            mic_ring.current.border     = ft.Border.all(2, th.DANGER)
            mic_ring.current.bgcolor    = f"{th.DANGER}18"
            record_btn_text.current.value = "Stop Recording"
            status_text.current.value   = "● Recording in progress…"
            status_text.current.color   = th.DANGER
            analyze_btn.current.disabled = True
            wave_row.current.visible    = True
            page.update()
            page.run_task(tick)
            page.run_task(animate_wave)
        else:
            path = await audio_recorder.stop_recording_async()
            rec_state["recording"] = False
            rec_state["path"]      = path or rec_state["path"]

            mic_icon_ref.current.color  = th.CYAN
            mic_core.current.bgcolor    = f"{th.CYAN}18"
            mic_ring.current.border     = ft.Border.all(2, th.CYAN)
            mic_ring.current.bgcolor    = f"{th.CYAN}0A"
            record_btn_text.current.value = "Start Recording"
            status_text.current.value   = "✓ Recording captured — tap Analyze"
            status_text.current.color   = th.GREEN
            analyze_btn.current.disabled = False
            wave_row.current.visible    = False
            page.update()

    async def run_analysis(e):
        if not rec_state["path"]:
            return
        progress.current.visible      = True
        status_text.current.value     = "Analyzing with SVM + Whisper…"
        status_text.current.color     = th.ON_SURFACE_2
        analyze_btn.current.disabled  = True
        page.update()

        try:
            filename = os.path.basename(rec_state["path"])
            result = await api_client.analyze_audio(
                state.backend_url,
                file_path=rec_state["path"],
                filename=filename,
            )
            record = AnalysisRecord(
                audio_type=result.get("audio_type", "Unknown"),
                language=result.get("language"),
                confidence=result.get("confidence"),
                duration=result.get("duration", 0.0),
                filename=filename,
            )
            state.add_record(record)
            state.current_result = record
            await storage_mod.save_history(page, state)
            page.go("/result")
        except api_client.ApiError as exc:
            progress.current.visible      = False
            status_text.current.value     = str(exc)
            status_text.current.color     = th.DANGER
            analyze_btn.current.disabled  = False
            page.update()

    # ── Wave bars ────────────────────────────────────────────────
    animated_bars = [
        ft.Container(
            ref=bar_refs[i],
            width=4,
            height=bar_heights[i],
            border_radius=2,
            bgcolor=th.DANGER,
        )
        for i in range(len(bar_heights))
    ]

    return ft.View(
        route="/record",
        bgcolor=th.SURFACE_0,
        padding=0,
        appbar=ft.AppBar(
            title=ft.Text("Record Audio", color=th.ON_SURFACE, weight=ft.FontWeight.W_700, size=17),
            bgcolor=th.SURFACE_1,
            elevation=0,
            center_title=True,
            leading=ft.IconButton(
                icon=ft.Icons.ARROW_BACK_IOS_NEW_ROUNDED,
                icon_color=th.ON_SURFACE_2,
                icon_size=20,
                on_click=lambda e: page.go("/"),
            ),
        ),
        controls=[
            ft.Container(
                expand=True,
                padding=ft.padding.only(left=24, top=24, right=24, bottom=24),
                content=ft.Column(
                    spacing=0,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Container(height=16),

                        # ── Mic orb (outer ring + core) ──────────
                        ft.Stack(
                            width=120,
                            height=120,
                            controls=[
                                # Outer ambient glow ring
                                ft.Container(
                                    ref=mic_ring,
                                    width=120,
                                    height=120,
                                    border_radius=60,
                                    bgcolor=f"{th.CYAN}0A",
                                    border=ft.Border.all(2, th.CYAN),
                                ),
                                # Inner lit core
                                ft.Container(
                                    ref=mic_core,
                                    width=80,
                                    height=80,
                                    border_radius=40,
                                    bgcolor=f"{th.CYAN}18",
                                    margin=ft.margin.all(20),
                                    alignment=ft.alignment.center,
                                    content=ft.Icon(
                                        ref=mic_icon_ref,
                                        name=ft.Icons.MIC_ROUNDED,
                                        size=36,
                                        color=th.CYAN,
                                    ),
                                    shadow=ft.BoxShadow(
                                        spread_radius=0,
                                        blur_radius=24,
                                        color=f"{th.CYAN}40",
                                    ),
                                ),
                            ],
                        ),

                        ft.Container(height=28),

                        # ── Timer ────────────────────────────────
                        ft.Text(
                            ref=timer_text,
                            value="00:00",
                            size=52,
                            weight=ft.FontWeight.BOLD,
                            color=th.ON_SURFACE,
                        ),

                        ft.Container(height=8),

                        # ── Animated waveform ────────────────────
                        ft.Container(
                            ref=wave_row,
                            visible=False,
                            content=ft.Row(
                                spacing=5,
                                alignment=ft.MainAxisAlignment.CENTER,
                                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                                controls=animated_bars,
                            ),
                        ),

                        ft.Container(height=16),

                        # ── Status label ─────────────────────────
                        ft.Text(
                            ref=status_text,
                            value="Tap the button to start recording",
                            color=th.ON_SURFACE_2,
                            size=13,
                            text_align=ft.TextAlign.CENTER,
                        ),

                        ft.Container(height=32),

                        # ── Record toggle button ─────────────────
                        ft.ElevatedButton(
                            content=ft.Row(
                                spacing=8,
                                alignment=ft.MainAxisAlignment.CENTER,
                                controls=[
                                    ft.Icon(ft.Icons.MIC_ROUNDED, size=18, color=th.ON_PRIMARY),
                                    ft.Text(
                                        ref=record_btn_text,
                                        value="Start Recording",
                                        color=th.ON_PRIMARY,
                                        size=15,
                                        weight=ft.FontWeight.W_600,
                                    ),
                                ],
                            ),
                            style=ft.ButtonStyle(
                                bgcolor=th.VIOLET,
                                color=th.ON_PRIMARY,
                                shape=ft.RoundedRectangleBorder(radius=16),
                                padding=ft.padding.symmetric(horizontal=36, vertical=16),
                                elevation=0,
                                shadow_color=f"{th.VIOLET}44",
                            ),
                            on_click=toggle_recording,
                        ),

                        ft.Container(expand=True),

                        # ── Analyzing progress row ───────────────
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=10,
                            controls=[
                                ft.ProgressRing(
                                    ref=progress,
                                    visible=False,
                                    width=18,
                                    height=18,
                                    stroke_width=2,
                                    color=th.VIOLET,
                                ),
                            ],
                        ),

                        ft.Container(height=12),

                        # ── Analyze button ───────────────────────
                        ft.ElevatedButton(
                            ref=analyze_btn,
                            content=ft.Text("Analyze Recording"),
                            icon=ft.Icons.PLAY_ARROW_ROUNDED,
                            disabled=True,
                            style=ft.ButtonStyle(
                                bgcolor={
                                    ft.ControlState.DEFAULT: th.CYAN,
                                    ft.ControlState.DISABLED: th.SURFACE_3,
                                },
                                color={
                                    ft.ControlState.DEFAULT: "#0A0A0A",
                                    ft.ControlState.DISABLED: th.ON_SURFACE_2,
                                },
                                shape=ft.RoundedRectangleBorder(radius=16),
                                padding=ft.padding.symmetric(horizontal=36, vertical=16),
                                elevation=0,
                            ),
                            on_click=run_analysis,
                            expand=True,
                        ),
                    ],
                ),
            )
        ],
    )
