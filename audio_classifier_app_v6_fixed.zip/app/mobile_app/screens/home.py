"""Home screen — clean light UI."""
import flet as ft
from models import AppState
import theme as th


def _hero_section(page: ft.Page) -> ft.Container:
    return ft.Container(
        content=ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Column(
                    spacing=2,
                    controls=[
                        ft.Text(
                            "Audio Classifier",
                            size=22,
                            weight=ft.FontWeight.BOLD,
                            color=th.ON_SURFACE,
                        ),
                        ft.Text(
                            "SVM · Whisper · ML Pipeline",
                            size=11,
                            color=th.ON_SURFACE_2,
                        ),
                    ],
                ),
                ft.Container(
                    content=ft.Icon(
                        ft.Icons.GRAPHIC_EQ_ROUNDED,
                        color=th.PRIMARY,
                        size=24,
                    ),
                    width=46,
                    height=46,
                    border_radius=14,
                    bgcolor=f"{th.PRIMARY}15",
                    border=ft.Border.all(1, f"{th.PRIMARY}30"),
                    alignment=ft.alignment.center,
                ),
            ],
        ),
        padding=ft.padding.symmetric(horizontal=20, vertical=16),
        bgcolor=th.SURFACE_1,
        border=ft.Border.only(bottom=ft.BorderSide(1, th.DIVIDER)),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=6,
            color="#00000010",
            offset=ft.Offset(0, 2),
        ),
    )


def _stat_row(counts: dict, total: int) -> ft.Row:
    return ft.Row(
        spacing=8,
        controls=[
            ft.Container(
                expand=1,
                content=th.stat_card("Total", str(total), ft.Icons.ANALYTICS_ROUNDED, th.PRIMARY),
            ),
            ft.Container(
                expand=1,
                content=th.stat_card("Speech", str(counts.get("Speech", 0)), ft.Icons.RECORD_VOICE_OVER_ROUNDED, th.SPEECH_COLOR),
            ),
            ft.Container(
                expand=1,
                content=th.stat_card("Music", str(counts.get("Music", 0)), ft.Icons.MUSIC_NOTE_ROUNDED, th.MUSIC_COLOR),
            ),
            ft.Container(
                expand=1,
                content=th.stat_card("Noise", str(counts.get("Noise", 0)), ft.Icons.GRAPHIC_EQ_ROUNDED, th.NOISE_COLOR),
            ),
        ],
    )


def _action_card(icon, label: str, subtitle: str, color: str, on_click) -> ft.Container:
    return ft.Container(
        expand=True,
        content=ft.Container(
            content=ft.Column(
                spacing=0,
                controls=[
                    ft.Container(
                        content=ft.Icon(icon, color=color, size=28),
                        width=52,
                        height=52,
                        border_radius=16,
                        bgcolor=f"{color}15",
                        border=ft.Border.all(1, f"{color}35"),
                        alignment=ft.alignment.center,
                    ),
                    ft.Container(height=12),
                    ft.Text(
                        label,
                        color=th.ON_SURFACE,
                        size=15,
                        weight=ft.FontWeight.W_700,
                    ),
                    ft.Container(height=3),
                    ft.Text(
                        subtitle,
                        color=th.ON_SURFACE_2,
                        size=11,
                    ),
                ],
            ),
            padding=ft.padding.all(18),
            border_radius=20,
            bgcolor=th.SURFACE_1,
            border=ft.Border.all(1, th.DIVIDER),
            on_click=on_click,
            ink=True,
            shadow=ft.BoxShadow(
                spread_radius=0,
                blur_radius=12,
                color="#00000012",
                offset=ft.Offset(0, 3),
            ),
        ),
    )


def _recent_tile(r) -> ft.Container:
    color = th.type_color(r.audio_type)
    icon  = th.type_icon(r.audio_type)
    lang_part = f"  ·  {r.language}" if r.language else ""
    conf_part = f"  ·  {r.confidence * 100:.0f}%" if r.confidence is not None else ""

    return ft.Container(
        content=ft.Row(
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                th.neon_icon_container(icon, color, size=17, container_size=40, border_radius=12),
                ft.Column(
                    spacing=3,
                    expand=True,
                    controls=[
                        ft.Text(
                            r.filename,
                            size=13,
                            weight=ft.FontWeight.W_600,
                            color=th.ON_SURFACE,
                            max_lines=1,
                            overflow=ft.TextOverflow.ELLIPSIS,
                        ),
                        ft.Text(
                            f"{r.audio_type}{lang_part}{conf_part}",
                            size=11,
                            color=th.ON_SURFACE_2,
                        ),
                    ],
                ),
                ft.Text(r.display_time, size=10, color=th.ON_SURFACE_2),
            ],
        ),
        padding=ft.padding.symmetric(horizontal=14, vertical=12),
        border_radius=14,
        bgcolor=th.SURFACE_1,
        border=ft.Border.all(1, th.DIVIDER),
        margin=ft.margin.only(bottom=8),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=6,
            color="#00000008",
            offset=ft.Offset(0, 1),
        ),
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    counts = state.counts()
    total  = len(state.history)

    quick_actions = ft.Row(
        spacing=12,
        controls=[
            _action_card(
                ft.Icons.UPLOAD_FILE_ROUNDED,
                "Upload",
                "Pick from storage",
                th.PRIMARY,
                lambda e: page.go("/upload"),
            ),
            _action_card(
                ft.Icons.MIC_ROUNDED,
                "Record",
                "Use microphone",
                th.VIOLET,
                lambda e: page.go("/record"),
            ),
        ],
    )

    recent = state.history[:5]
    if recent:
        recent_tiles = [_recent_tile(r) for r in recent]
        recent_body  = ft.Column(spacing=0, controls=recent_tiles)
    else:
        recent_body = ft.Container(
            padding=ft.padding.symmetric(vertical=28),
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10,
                controls=[
                    ft.Container(
                        content=ft.Icon(
                            ft.Icons.QUEUE_MUSIC_ROUNDED,
                            size=40,
                            color=th.ON_SURFACE_2,
                        ),
                        width=68,
                        height=68,
                        border_radius=22,
                        bgcolor=f"{th.PRIMARY}10",
                        border=ft.Border.all(1, th.DIVIDER),
                        alignment=ft.alignment.center,
                    ),
                    ft.Text(
                        "No analyses yet",
                        color=th.ON_SURFACE,
                        size=14,
                        weight=ft.FontWeight.W_600,
                    ),
                    ft.Text(
                        "Upload or record your first audio clip\nto get started.",
                        color=th.ON_SURFACE_2,
                        size=12,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ],
            ),
        )

    recent_header = ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
        controls=[
            th.section_label("Recent Analyses"),
            ft.TextButton(
                "See all →",
                style=ft.ButtonStyle(color=th.PRIMARY),
                on_click=lambda e: page.go("/history"),
            ) if recent else ft.Container(),
        ],
    )

    scroll_body = ft.Column(
        spacing=20,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            _stat_row(counts, total),
            ft.Container(
                content=ft.Column(
                    spacing=12,
                    controls=[
                        th.section_label("Classify Audio"),
                        quick_actions,
                    ],
                ),
            ),
            ft.Container(
                content=ft.Column(
                    spacing=12,
                    controls=[
                        recent_header,
                        recent_body,
                    ],
                ),
            ),
        ],
    )

    return ft.View(
        route="/",
        bgcolor=th.BG,
        padding=0,
        navigation_bar=th.build_nav_bar(page, 0),
        controls=[
            ft.Column(
                expand=True,
                spacing=0,
                controls=[
                    _hero_section(page),
                    ft.Container(
                        expand=True,
                        padding=ft.padding.only(left=16, top=20, right=16, bottom=16),
                        content=scroll_body,
                    ),
                ],
            )
        ],
    )
