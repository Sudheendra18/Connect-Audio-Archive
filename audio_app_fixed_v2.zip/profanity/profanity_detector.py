from transformers import pipeline

print("Loading Profanity Detection Model...")

classifier = pipeline(
    task="text-classification",
    model="unitary/multilingual-toxic-xlm-roberta",
    top_k=None,
)

print("Profanity Model Loaded!\n")

OFFENSIVE_LABELS = [
    "toxic",
    "obscene",
    "insult",
    "threat",
    "identity_attack",
    "sexual_explicit",
]

PROFANITY_THRESHOLD = 0.70  # 70 % confidence → flagged


def detect_profanity(text: str) -> dict:
    """
    Analyse ``text`` for toxic content.

    Parameters
    ----------
    text : str
        The English (or multilingual) text to analyse.

    Returns
    -------
    dict
        is_profane  : bool   — True when any offensive label ≥ threshold
        category    : str    — highest-scoring offensive label, or "Safe"
        score       : float  — that label's score as a percentage (0–100)
        all_scores  : dict   — {label: score} for every label the model returns
    """
    if not text or not text.strip():
        return {
            "is_profane": False,
            "category":   "Safe",
            "score":      0.0,
            "all_scores": {},
        }

    predictions = classifier(text)[0]

    all_scores = {item["label"]: round(item["score"], 4) for item in predictions}

    max_score = 0.0
    category  = "Safe"

    for label in OFFENSIVE_LABELS:
        if label in all_scores and all_scores[label] > max_score:
            max_score = all_scores[label]
            category  = label

    return {
        "is_profane": max_score >= PROFANITY_THRESHOLD,
        "category":   category,
        "score":      round(max_score * 100, 2),
        "all_scores": all_scores,
    }
