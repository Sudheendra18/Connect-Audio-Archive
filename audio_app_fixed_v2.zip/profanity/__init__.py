"""Profanity detection subpackage.

`detect_profanity` (the ML toxicity model) is imported lazily so that simply
importing this package — e.g. to reach `profanity_wordlist.Wordlist` — does
NOT load the heavy transformer model. The model loads only when
`detect_profanity` is actually accessed.
"""

__all__ = ["detect_profanity", "Wordlist"]


def __getattr__(name):
    if name == "detect_profanity":
        from .profanity_detector import detect_profanity
        return detect_profanity
    if name == "Wordlist":
        from .profanity_wordlist import Wordlist
        return Wordlist
    raise AttributeError(f"module 'profanity' has no attribute {name!r}")
