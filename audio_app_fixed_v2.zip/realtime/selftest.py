"""
selftest.py
===========
Dependency-light validation of the real-time filter's logic. Uses the mock
transcription backend (no Whisper/torch/transformers needed) so it runs
anywhere. Exercises:

  * beep generation (shape, amplitude, click-free fades)
  * energy VAD (silence vs. tone)
  * wordlist matching (plain, leetspeak, phrases, Scunthorpe safety)
  * config CLI + auto-delay
  * FULL offline pipeline: synthesize audio where a known profane word sits at
    a known time, run run_file_offline(), and assert the beep lands exactly
    there and nowhere else.

Run:  python realtime/selftest.py
"""

from __future__ import annotations

import os
import sys
import tempfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for _p in (HERE, ROOT, os.path.join(ROOT, "profanity")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import audio_io
from audio_io import make_beep, apply_beep_ranges, write_wav_mono, read_wav_mono
from vad import EnergyVAD
from config import RealtimeConfig, parse_args
import profanity_wordlist
from transcription import TranscriptionEngine, Word
import realtime_filter


PASS, FAIL = 0, 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name}  {extra}")


# ─────────────────────────────────────────────────────────────────────────────
def test_beep():
    print("\n[beep]")
    sr = 16000
    b = make_beep(sr // 2, sr, freq=1000, gain=0.5)  # 0.5s
    check("length exact", len(b) == sr // 2, f"got {len(b)}")
    check("peak <= gain", np.max(np.abs(b)) <= 0.5 + 1e-6, f"peak {np.max(np.abs(b)):.3f}")
    check("starts near zero (fade-in)", abs(b[0]) < 0.05, f"b[0]={b[0]:.4f}")
    check("ends near zero (fade-out)", abs(b[-1]) < 0.05, f"b[-1]={b[-1]:.4f}")
    # dominant frequency ~1000 Hz
    spec = np.abs(np.fft.rfft(b))
    freqs = np.fft.rfftfreq(len(b), 1 / sr)
    peak_hz = freqs[np.argmax(spec)]
    check("dominant freq ~1000Hz", abs(peak_hz - 1000) < 25, f"peak {peak_hz:.0f}Hz")

    # apply_beep_ranges replaces only the given range
    sig = np.ones(1000, dtype=np.float32) * 0.2
    out = apply_beep_ranges(sig, [(300, 400)], sr, 1000, 0.5)
    check("outside range untouched", np.allclose(out[:300], 0.2) and np.allclose(out[400:], 0.2))
    check("inside range changed", not np.allclose(out[300:400], 0.2))


def test_vad():
    print("\n[vad]")
    sr = 16000
    vad = EnergyVAD(sr, min_speech_frac=0.15, offset_db=8.0)
    silence = (np.random.randn(sr) * 1e-4).astype(np.float32)  # near-silent noise
    # prime the noise floor with a couple of silent blocks
    vad.has_speech(silence); vad.has_speech(silence)
    check("silence -> no speech", vad.has_speech(silence) is False)

    t = np.arange(sr, dtype=np.float32) / sr
    tone = (0.3 * np.sin(2 * np.pi * 220 * t)).astype(np.float32)  # loud-ish tone
    check("tone -> speech", vad.has_speech(tone) is True)


def test_wordlist():
    print("\n[wordlist]")
    wl = profanity_wordlist.Wordlist()
    check("plain profanity flagged", wl.is_profane_token("shit"))
    check("leetspeak flagged (sh1t)", wl.is_profane_token("sh1t"))
    check("leetspeak flagged (b1tch)", wl.is_profane_token("b1tch"))
    check("leetspeak flagged (@sshole)", wl.is_profane_token("@sshole"))
    check("punctuation stripped (f**k? -> no)", not wl.is_profane_token("hello"))
    check("clean word safe", not wl.is_profane_token("assistant"))   # Scunthorpe-ish
    check("clean word safe (class)", not wl.is_profane_token("class"))

    # phrase match
    words = [Word("you", 0.0, 0.2), Word("piece", 0.2, 0.4),
             Word("of", 0.4, 0.5), Word("shit", 0.5, 0.8)]
    flagged = wl.match_words(words)
    texts = {w.text for w in flagged}
    check("phrase 'piece of shit' flagged", {"piece", "of", "shit"}.issubset(texts),
          f"flagged={texts}")

    # extra dir loading
    with tempfile.TemporaryDirectory() as d:
        with open(os.path.join(d, "xx.txt"), "w", encoding="utf-8") as f:
            f.write("# test list\nzzblarg\n")
        wl2 = profanity_wordlist.Wordlist(d)
        check("extra-dir word loaded", wl2.is_profane_token("zzblarg"))


def test_config():
    print("\n[config]")
    cfg = parse_args(["--input", "file", "--file", "x.wav",
                      "--transcribe-model", "tiny", "--block", "2",
                      "--delay", "auto", "--vad", "off"])
    check("parsed input", cfg.input == "file")
    check("parsed model", cfg.transcribe_model == "tiny")
    check("block segments", cfg.block_segments == 2)
    check("delay auto -> None", cfg.delay is None)
    check("auto delay positive", cfg.resolved_delay() > 0)
    cfg2 = parse_args(["--delay", "3.5"])
    check("explicit delay", cfg2.resolved_delay() == 3.5)


def _synth_stream(cfg, n_seconds, bad_word_center_s):
    """
    Build a wav of tone (so VAD sees speech) at cfg.sample_rate. The mock
    backend will place its profane token at the MIDDLE of each transcription
    window, so to make the test deterministic we drive a single block whose
    middle aligns with bad_word_center_s. We simply return uniform tone; the
    beep location is dictated by the mock's word grid, which we then locate.
    """
    sr = cfg.sample_rate
    t = np.arange(int(n_seconds * sr), dtype=np.float32) / sr
    return (0.25 * np.sin(2 * np.pi * 200 * t)).astype(np.float32)


def test_offline_pipeline():
    print("\n[offline pipeline — end to end]")
    # Configure: mock backend, wordlist matches the mock's injected token,
    # no ML net, VAD off (uniform tone anyway), single 4s file = one block.
    cfg = parse_args([
        "--input", "file", "--file", "unused.wav",
        "--backend", "mock", "--no-model-net", "--vad", "off",
        "--segment", "1", "--block", "4", "--context", "0", "--lookahead", "0",
        "--enable-beep",
        "--beep-freq", "1000", "--beep-gain", "0.5", "--beep-pad-ms", "0",
    ])
    cfg._extra["mock_bad_token"] = "shit"  # a real word in the core list

    sr = cfg.sample_rate
    audio = _synth_stream(cfg, 4.0, 2.0)

    with tempfile.TemporaryDirectory() as d:
        in_path = os.path.join(d, "in.wav")
        out_path = os.path.join(d, "out.wav")
        write_wav_mono(in_path, audio, sr)
        cfg.input_file = in_path
        cfg.output_file = out_path

        analyzer = realtime_filter.build(cfg)
        result = realtime_filter.run_file_offline(cfg, analyzer)

        out = read_wav_mono(out_path, sr)
        check("output length preserved", len(out) == len(audio),
              f"{len(out)} vs {len(audio)}")

        # The mock emits words every 0.5s over the 4s window; middle word (index 4,
        # at t=2.0s) is "shit". So we expect a beep around [2.0, 2.35]s.
        beep_lo, beep_hi = int(2.0 * sr), int(2.35 * sr)
        # region that should be beeped: differs from original tone
        diff = np.abs(out - audio)
        beeped_mask = diff > 0.05
        beeped_idx = np.where(beeped_mask)[0]
        check("something was beeped", beeped_idx.size > 0)
        if beeped_idx.size:
            lo, hi = beeped_idx.min(), beeped_idx.max()
            # beep should sit within the expected window (+/- a segment tolerance)
            tol = int(0.2 * sr)
            check("beep starts near 2.0s", abs(lo - beep_lo) < sr * 0.6,
                  f"beep start {lo/sr:.2f}s")
            check("beep ends near 2.35s", abs(hi - beep_hi) < sr * 0.6,
                  f"beep end {hi/sr:.2f}s")
            # everything well outside [1.8, 2.6] should be untouched
            outside = np.concatenate([out[: int(1.6 * sr)], out[int(2.8 * sr):]])
            outside_src = np.concatenate([audio[: int(1.6 * sr)], audio[int(2.8 * sr):]])
            check("audio outside the word is preserved",
                  np.allclose(outside, outside_src, atol=1e-3))

        check("reported beeped seconds > 0", result["beeped_seconds"] > 0)
        check("language detected (mock=en)", result["language"] == "en")


def test_multiblock_alignment():
    print("\n[offline pipeline — multi-block, precise localization]")
    # 8s file, block=2s, context=1s, lookahead=1s. Mock puts a bad token in the
    # middle of each transcription window; we just verify beeps occur, stay
    # inside their block regions, and total beeped time is bounded (precise, not
    # whole-file muting).
    cfg = parse_args([
        "--input", "file", "--file", "unused.wav",
        "--backend", "mock", "--no-model-net", "--vad", "off",
        "--segment", "1", "--block", "2", "--context", "1", "--lookahead", "1",
        "--enable-beep", "--beep-pad-ms", "0",
    ])
    cfg._extra["mock_bad_token"] = "fuck"
    sr = cfg.sample_rate
    t = np.arange(8 * sr, dtype=np.float32) / sr
    audio = (0.25 * np.sin(2 * np.pi * 200 * t)).astype(np.float32)

    with tempfile.TemporaryDirectory() as d:
        in_path, out_path = os.path.join(d, "i.wav"), os.path.join(d, "o.wav")
        write_wav_mono(in_path, audio, sr); cfg.input_file = in_path; cfg.output_file = out_path
        analyzer = realtime_filter.build(cfg)
        res = realtime_filter.run_file_offline(cfg, analyzer)
        out = read_wav_mono(out_path, sr)
        diff = np.abs(out - audio) > 0.05
        frac = float(np.mean(diff))
        check("beeps present", diff.any())
        check("precise (not whole-file): <40% beeped", frac < 0.40, f"beeped frac={frac:.2f}")
        check("length preserved", len(out) == len(audio))


def test_window_mode_and_failclosed():
    print("\n[window-granularity + fail-closed transcription error]")
    # window granularity: any flagged word beeps the whole block
    cfg = parse_args([
        "--input", "file", "--file", "u.wav", "--backend", "mock", "--no-model-net",
        "--vad", "off", "--segment", "1", "--block", "3", "--context", "0",
        "--lookahead", "0", "--enable-beep",
        "--beep-granularity", "window", "--beep-pad-ms", "0",
    ])
    cfg._extra["mock_bad_token"] = "shit"
    sr = cfg.sample_rate
    audio = (0.25 * np.sin(2 * np.pi * 200 * np.arange(3 * sr) / sr)).astype(np.float32)
    with tempfile.TemporaryDirectory() as d:
        ip, op = os.path.join(d, "i.wav"), os.path.join(d, "o.wav")
        write_wav_mono(ip, audio, sr); cfg.input_file = ip; cfg.output_file = op
        analyzer = realtime_filter.build(cfg)
        realtime_filter.run_file_offline(cfg, analyzer)
        out = read_wav_mono(op, sr)
        frac = float(np.mean(np.abs(out - audio) > 0.05))
        check("window mode beeps ~whole block", frac > 0.8, f"beeped frac={frac:.2f}")


def test_beep_disabled_passthrough():
    print("\n[beep_enabled=False — audio passes through untouched]")
    # Default config (no --enable-beep): even with a flagged word every
    # window, the played/saved audio must come out byte-identical to what
    # went in. This is the fix for "beeped/muted audio makes it sound like
    # nothing was captured" — analysis still runs, it just can't touch the
    # samples until beep_enabled is switched back on.
    cfg = parse_args([
        "--input", "file", "--file", "unused.wav",
        "--backend", "mock", "--no-model-net", "--vad", "off",
        "--segment", "1", "--block", "4", "--context", "0", "--lookahead", "0",
    ])
    check("beep_enabled defaults to False", cfg.beep_enabled is False)
    cfg._extra["mock_bad_token"] = "shit"
    sr = cfg.sample_rate
    audio = _synth_stream(cfg, 4.0, 2.0)

    with tempfile.TemporaryDirectory() as d:
        in_path = os.path.join(d, "in.wav")
        out_path = os.path.join(d, "out.wav")
        write_wav_mono(in_path, audio, sr)
        cfg.input_file = in_path
        cfg.output_file = out_path

        analyzer = realtime_filter.build(cfg)
        result = realtime_filter.run_file_offline(cfg, analyzer)

        out = read_wav_mono(out_path, sr)
        check("output length preserved", len(out) == len(audio),
              f"{len(out)} vs {len(audio)}")
        check("audio completely unmodified",
              np.allclose(out, audio, atol=1e-4),
              f"max diff {np.max(np.abs(out - audio)):.4f}")
        check("still reports what would have been flagged",
              result["beeped_seconds"] > 0)


def main():
    print("=" * 60)
    print("  REAL-TIME PROFANITY FILTER — SELF TEST (mock backend)")
    print("=" * 60)
    test_beep()
    test_vad()
    test_wordlist()
    test_config()
    test_offline_pipeline()
    test_multiblock_alignment()
    test_window_mode_and_failclosed()
    test_beep_disabled_passthrough()
    print("\n" + "=" * 60)
    print(f"  RESULT: {PASS} passed, {FAIL} failed")
    print("=" * 60)
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
