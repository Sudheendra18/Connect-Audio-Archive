"""
audio_io.py
===========
Everything that touches raw audio bytes: the censor beep, the pluggable input
sources, the speaker sink, and small wav read/write helpers.

Input sources (the Auracast hook lives here)
--------------------------------------------
Every source is an iterator yielding float32 mono chunks of `segment_samples`.
Swapping the capture path for an Auracast BIS receiver later means adding one
class here (read PCM frames from `bumble-auracast receive --output stdout`) —
nothing in the engine changes. `StdinPCMSource` already does exactly this for
any process that writes raw float32 PCM to stdout:

    bumble-auracast receive --output stdout | \
        python -m realtime.realtime_filter --input stdin
"""

from __future__ import annotations

import sys
import math
import struct
import wave
import numpy as np


# ═════════════════════════════════════════════════════════════════════════════
# Censor beep
# ═════════════════════════════════════════════════════════════════════════════

def make_beep(n_samples: int, sample_rate: int, freq: float = 1000.0,
              gain: float = 0.5, fade_ms: float = 5.0) -> np.ndarray:
    """A sine 'bleep' of exactly n_samples with short cosine fades (no clicks)."""
    if n_samples <= 0:
        return np.zeros(0, dtype=np.float32)
    t = np.arange(n_samples, dtype=np.float32) / sample_rate
    tone = (gain * np.sin(2.0 * np.pi * freq * t)).astype(np.float32)
    fade = min(int(sample_rate * fade_ms / 1000.0), n_samples // 2)
    if fade > 0:
        env = 0.5 * (1.0 - np.cos(np.linspace(0.0, np.pi, fade, dtype=np.float32)))
        tone[:fade] *= env
        tone[-fade:] *= env[::-1]
    return tone


def apply_beep_ranges(samples: np.ndarray, ranges, sample_rate: int,
                      freq: float, gain: float) -> np.ndarray:
    """
    Return a copy of `samples` with every (start, end) local sample range
    replaced by a beep tone. Ranges are clamped to bounds and may overlap.
    """
    if not ranges:
        return samples
    out = samples.copy()
    for a, b in ranges:
        a = max(0, int(a))
        b = min(len(out), int(b))
        if b > a:
            out[a:b] = make_beep(b - a, sample_rate, freq, gain)
    return out


# ═════════════════════════════════════════════════════════════════════════════
# WAV helpers
# ═════════════════════════════════════════════════════════════════════════════

def read_wav_mono(path: str, target_sr: int) -> np.ndarray:
    """
    Load a wav as float32 mono at target_sr. Uses stdlib `wave` + numpy for
    16-bit PCM (no external deps); for anything else it tries soundfile.
    """
    try:
        with wave.open(path, "rb") as w:
            n_ch = w.getnchannels()
            sw = w.getsampwidth()
            sr = w.getframerate()
            raw = w.readframes(w.getnframes())
        if sw == 2:
            data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        elif sw == 4:
            data = np.frombuffer(raw, dtype=np.int32).astype(np.float32) / 2147483648.0
        elif sw == 1:
            data = (np.frombuffer(raw, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
        else:
            raise ValueError(f"unsupported sample width {sw}")
        if n_ch > 1:
            data = data.reshape(-1, n_ch).mean(axis=1)
        if sr != target_sr:
            data = _resample(data, sr, target_sr)
        return data.astype(np.float32)
    except (wave.Error, EOFError):
        import soundfile as sf  # optional, for non-PCM/other formats
        data, sr = sf.read(path, dtype="float32", always_2d=False)
        if data.ndim > 1:
            data = data.mean(axis=1)
        if sr != target_sr:
            data = _resample(data, sr, target_sr)
        return data.astype(np.float32)


def write_wav_mono(path: str, samples: np.ndarray, sample_rate: int) -> None:
    clipped = np.clip(samples, -1.0, 1.0)
    pcm = (clipped * 32767.0).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(pcm.tobytes())


def _resample(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    """Linear resample — fine for a filtering front-end; no scipy required."""
    if sr_in == sr_out or x.size == 0:
        return x
    n_out = int(round(x.size * sr_out / sr_in))
    xp = np.linspace(0.0, 1.0, x.size, endpoint=False)
    fp = np.linspace(0.0, 1.0, n_out, endpoint=False)
    return np.interp(fp, xp, x).astype(np.float32)


# ═════════════════════════════════════════════════════════════════════════════
# Input sources — iterators of float32 mono chunks
# ═════════════════════════════════════════════════════════════════════════════

class MicSource:
    """
    Live microphone via sounddevice. Blocking read of fixed-size chunks.

    Most consumer mics/drivers (esp. on Windows/Bluetooth) don't actually run
    at 16 kHz — they run at their own native rate (44.1k/48k are typical) and
    silently resample or misreport if you just ask PortAudio for 16000
    directly. Opening the stream at *that* device's native rate and doing our
    own resample down to cfg.sample_rate (same linear resample already used
    for file I/O and speaker output) keeps capture honest: every segment we
    hand to the buffer actually spans cfg.segment seconds of real time, so
    downstream timing/analysis/playback all stay in sync instead of drifting
    into sped-up, thin-sounding, glitchy audio.
    """
    def __init__(self, cfg):
        import sounddevice as sd
        self._sd = sd
        self.cfg = cfg

        try:
            dev_index = sd.default.device[0]  # (input, output)
            info = sd.query_devices(dev_index)
            native_sr = int(round(info.get("default_samplerate") or cfg.sample_rate))
        except Exception:
            native_sr = cfg.sample_rate

        self._native_sr = native_sr
        self._resample_in = native_sr != cfg.sample_rate
        # Read enough native-rate samples that, once resampled down, we get
        # (at least) segment_samples out — round up so segments never come up
        # short.
        self._native_blocksize = int(math.ceil(
            cfg.segment_samples * native_sr / cfg.sample_rate)) if self._resample_in \
            else cfg.segment_samples

        self.stream = sd.InputStream(
            samplerate=native_sr, channels=cfg.channels,
            blocksize=self._native_blocksize, dtype="float32",
            latency=getattr(cfg, "input_latency", "high"),
        )

    def __iter__(self):
        self.stream.start()
        try:
            while True:
                data, _ = self.stream.read(self._native_blocksize)
                mono = data[:, 0].copy() if data.ndim > 1 else data.copy()
                if self._resample_in:
                    mono = _resample(mono, self._native_sr, self.cfg.sample_rate)
                    # linear resample can land 1 sample off target; pin it so
                    # every yielded chunk is exactly segment_samples long —
                    # otherwise the buffer's timing math (seq * segment) drifts.
                    n = self.cfg.segment_samples
                    if len(mono) < n:
                        mono = np.pad(mono, (0, n - len(mono)))
                    elif len(mono) > n:
                        mono = mono[:n]
                yield mono
        finally:
            self.stream.stop()
            self.stream.close()


class WavFileSource:
    """
    Read a wav in `segment_samples` chunks. If `realtime` is True, sleeps to
    emulate real-time arrival (so you can watch the delay/beeping behave as it
    would live); if False, yields as fast as possible (fast offline test).
    """
    def __init__(self, cfg, realtime: bool = False):
        self.cfg = cfg
        self.realtime = realtime
        self.audio = read_wav_mono(cfg.input_file, cfg.sample_rate)

    def __iter__(self):
        import time
        n = self.cfg.segment_samples
        for i in range(0, len(self.audio), n):
            chunk = self.audio[i:i + n]
            if len(chunk) < n:  # pad final chunk so segments stay uniform
                chunk = np.pad(chunk, (0, n - len(chunk)))
            if self.realtime:
                time.sleep(self.cfg.segment)
            yield chunk


class StdinPCMSource:
    """
    Read raw float32 little-endian PCM from stdin in fixed chunks. This is the
    generic Auracast / external-pipeline hook: any producer that writes float32
    PCM to stdout feeds the filter with no code change.
    """
    def __init__(self, cfg):
        self.cfg = cfg

    def __iter__(self):
        n = self.cfg.segment_samples
        nbytes = n * 4  # float32
        buf = sys.stdin.buffer
        while True:
            raw = buf.read(nbytes)
            if not raw:
                break
            if len(raw) < nbytes:
                raw = raw + b"\x00" * (nbytes - len(raw))
            yield np.frombuffer(raw, dtype="<f4").astype(np.float32).copy()


def make_source(cfg, realtime_file: bool = False):
    if cfg.input == "mic":
        return MicSource(cfg)
    if cfg.input == "file":
        if not cfg.input_file:
            raise SystemExit("--input file requires --file PATH")
        return WavFileSource(cfg, realtime=realtime_file)
    if cfg.input == "stdin":
        return StdinPCMSource(cfg)
    raise SystemExit(f"unknown input source: {cfg.input}")


# ═════════════════════════════════════════════════════════════════════════════
# Output sink
# ═════════════════════════════════════════════════════════════════════════════

class SpeakerSink:
    """
    Play float32 mono chunks to the default output device.

    Records which physical device it actually opened (name + host API) so the
    caller can show "you should be hearing this on <device>" instead of audio
    silently going to a device the user doesn't have selected.
    """
    def __init__(self, cfg):
        import sounddevice as sd
        self._sd = sd
        self.cfg = cfg
        try:
            dev_index = sd.default.device[1]  # (input, output)
            info = sd.query_devices(dev_index)
        except Exception:
            dev_index, info = None, {}
        self.device_index = dev_index
        self.device_name = info.get("name", "default output device")
        self.device_samplerate = info.get("default_samplerate")

        # Bluetooth codecs (SBC/AAC/aptX) glitch easily if the driver has to
        # resample AND keep up with a small buffer at the same time — and
        # CPU contention from Whisper running concurrently makes that worse.
        # We resample to the device's own native rate ourselves (cheap linear
        # resample, already used for file I/O) and ask PortAudio for a bigger
        # buffer via latency="high", so the driver just plays what we hand it.
        self._src_sr = cfg.sample_rate
        self._out_sr = cfg.sample_rate
        self._resample_out = False
        if self.device_samplerate and abs(self.device_samplerate - cfg.sample_rate) > 1:
            self._out_sr = int(round(self.device_samplerate))
            self._resample_out = True

        self._latency = getattr(cfg, "output_latency", "high")
        self.stream = sd.OutputStream(
            samplerate=self._out_sr, channels=cfg.channels, dtype="float32",
            latency=self._latency)
        self.stream.start()

    def write(self, samples: np.ndarray) -> None:
        if self._resample_out:
            samples = _resample(samples, self._src_sr, self._out_sr)
        try:
            self.stream.write(samples)
        except Exception:
            # A Bluetooth device dropping out and reconnecting mid-stream
            # shouldn't take the whole engine down with it — reopen once and
            # retry; if that also fails, drop this chunk and keep going.
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            try:
                self.stream = self._sd.OutputStream(
                    samplerate=self._out_sr, channels=self.cfg.channels,
                    dtype="float32", latency=self._latency)
                self.stream.start()
                self.stream.write(samples)
            except Exception:
                pass

    def describe(self) -> str:
        rate_note = ""
        if self._resample_out:
            rate_note = f" (resampled {self._src_sr}→{self._out_sr} Hz for this device)"
        return f"{self.device_name}{rate_note}"

    def close(self) -> None:
        self.stream.stop()
        self.stream.close()


class WavWriterSink:
    """Accumulate played audio and write one censored wav at the end."""
    def __init__(self, cfg):
        self.cfg = cfg
        self._chunks: list[np.ndarray] = []

    def write(self, samples: np.ndarray) -> None:
        self._chunks.append(samples.copy())

    def close(self) -> None:
        if self._chunks and self.cfg.output_file:
            full = np.concatenate(self._chunks)
            write_wav_mono(self.cfg.output_file, full, self.cfg.sample_rate)
            print(f"[output] censored audio written to {self.cfg.output_file} "
                  f"({len(full)/self.cfg.sample_rate:.1f}s)")


class FanoutSink:
    """Write to several sinks at once (e.g. speaker + wav file)."""
    def __init__(self, sinks):
        self.sinks = [s for s in sinks if s is not None]

    def write(self, samples: np.ndarray) -> None:
        for s in self.sinks:
            s.write(samples)

    def close(self) -> None:
        for s in self.sinks:
            s.close()


class DebugTapSink:
    """
    Continuously writes exactly what was sent to playback (post-beep) into a
    rolling wav file on disk, so "where can I hear it" has a concrete answer
    that doesn't depend on the live speaker working: open the file afterwards
    and listen to precisely what the filter produced, beeps included.

    Rolls over to a fresh file every `max_seconds` of audio so a long session
    doesn't grow one huge file; keeps the last `keep_files` rollovers.
    """
    def __init__(self, cfg, out_dir: str, max_seconds: float = 120.0, keep_files: int = 3):
        import os as _os
        import glob as _glob
        import time as _time
        self._os, self._glob, self._time = _os, _glob, _time
        self.cfg = cfg
        self.out_dir = out_dir
        self.max_samples = int(max_seconds * cfg.sample_rate)
        self.keep_files = keep_files
        _os.makedirs(out_dir, exist_ok=True)
        self._n = 0
        self._writer: wave.Wave_write | None = None
        self.current_path: str | None = None
        self._rollover()

    def _open_writer(self, path: str) -> "wave.Wave_write":
        w = wave.open(path, "wb")
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(self.cfg.sample_rate)
        return w

    def _rollover(self) -> None:
        if self._writer is not None:
            self._writer.close()
        stamp = self._time.strftime("%Y%m%d-%H%M%S")
        self._file_counter = getattr(self, "_file_counter", 0) + 1
        self.current_path = self._os.path.join(
            self.out_dir, f"live_monitor_{stamp}_{self._file_counter:04d}.wav")
        self._writer = self._open_writer(self.current_path)
        self._n = 0
        old = sorted(self._glob.glob(self._os.path.join(self.out_dir, "live_monitor_*.wav")))
        for p in old[:-self.keep_files]:
            try:
                self._os.remove(p)
            except OSError:
                pass

    def write(self, samples: np.ndarray) -> None:
        clipped = np.clip(samples, -1.0, 1.0)
        pcm = (clipped * 32767.0).astype(np.int16)
        self._writer.writeframes(pcm.tobytes())
        self._n += len(samples)
        if self._n >= self.max_samples:
            self._rollover()

    def close(self) -> None:
        if self._writer is not None:
            self._writer.close()
            self._writer = None
