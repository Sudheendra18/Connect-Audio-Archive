# Audio Classification & Language Detection App

Two parts:

- **backend/** - FastAPI server wrapping your existing SVM + Whisper pipeline
  (`audio_pipeline.py`). Exposes `POST /analyze`.
- **mobile_app/** - Flet 0.85.3 app (Home, Upload, Record, History, Analytics,
  Settings, About). Calls the backend over HTTP and stores history on-device.

## Why client-server, not fully on-device

Whisper depends on PyTorch, which doesn't currently have official wheels for
Android. `flet build apk` packages pure-Python / precompiled dependencies via
`serious_python`, and torch isn't one of them - so the SVM+Whisper pipeline
can't run *inside* the APK itself. The APK is a thin client; the backend runs
wherever you already run Python (your machine, a small VPS, etc.) and the
app talks to it over HTTP. This also keeps the APK small.

## 1. Wire up the backend

```bash
cd backend
pip install -r requirements.txt
```

Copy your existing files into `backend/stage1/`:
- `audio_pipeline.py`
- `svm_model.pkl`
- `scaler.pkl`
- anything else `audio_pipeline.py` imports (e.g. `speech_language_detection.py`)

Open `pipeline_adapter.py` - if your pipeline's main function isn't named
`process_audio`, update the import there.

Run it:
```bash
python main.py
```

Test it:
```bash
curl -X POST http://localhost:8000/analyze -F "file=@/path/to/clip.wav"
```

## 2. Run the mobile app (desktop/dev mode first)

```bash
cd mobile_app
pip install flet==0.85.3 flet-audio-recorder==0.85.3 flet-charts==0.85.3 httpx
flet run
```

This opens the app in a desktop window so you can test navigation, upload,
and the backend connection before building an APK. In Settings, point the
backend URL at wherever your FastAPI server is reachable from your phone
(e.g. `http://192.168.1.50:8000` - your computer's LAN IP, not `localhost`).

## 3. Build the APK

```bash
cd mobile_app
flet build apk
```

The APK will be in `mobile_app/build/apk/`. Install it on your device and
set the backend URL in Settings to your server's reachable address.

## Notes

- The default backend URL (`http://10.0.2.2:8000`) only works in the Android
  emulator. On a real device, change it in Settings to your server's LAN IP
  or a public URL.
- History and theme preference are stored on-device via Flet's
  `shared_preferences` - nothing is sent anywhere except the audio file
  itself, to your own backend, for analysis.
- `confidence` is optional end-to-end. If your pipeline doesn't return it yet,
  the app just displays "-" instead of a percentage.
