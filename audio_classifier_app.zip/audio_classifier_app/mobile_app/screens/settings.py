"""Settings screen: theme, backend URL, export/clear history."""
import flet as ft

from models import AppState
import storage as storage_mod
import theme as theme_mod


def build_view(page: ft.Page, state: AppState) -> ft.View:
    backend_field = ft.Ref[ft.TextField]()

    async def on_theme_change(e: ft.ControlEvent):
        state.dark_mode = e.control.value
        page.theme_mode = ft.ThemeMode.DARK if state.dark_mode else ft.ThemeMode.LIGHT
        await storage_mod.save_theme(page, state)
        page.update()

    async def save_backend_url(e):
        state.backend_url = backend_field.current.value or state.backend_url
        await storage_mod.save_backend_url(page, state)
        page.show_dialog(ft.SnackBar(content=ft.Text("Backend URL saved")))

    async def export_history(e):
        if not state.history:
            page.show_dialog(ft.SnackBar(content=ft.Text("No history to export")))
            return
        await page.clipboard.set(state.history_to_json())
        page.show_dialog(ft.SnackBar(content=ft.Text("History copied to clipboard as JSON")))

    async def do_clear_history(e):
        page.pop_dialog()
        await storage_mod.clear_history(page, state)
        page.show_dialog(ft.SnackBar(content=ft.Text("History cleared")))
        page.go("/settings")

    def cancel_clear(e):
        page.pop_dialog()

    def confirm_clear_history(e):
        page.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Clear history?"),
                content=ft.Text("This deletes all saved analyses on this device. This cannot be undone."),
                actions=[
                    ft.TextButton("Cancel", on_click=cancel_clear),
                    ft.TextButton("Clear", on_click=do_clear_history),
                ],
            )
        )

    def go_about(e):
        page.go("/about")

    return ft.View(
        route="/settings",
        appbar=ft.AppBar(title=ft.Text("Settings")),
        navigation_bar=theme_mod.build_nav_bar(page, 3),
        controls=[
            ft.Container(
                padding=16,
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[
                        ft.Card(
                            content=ft.Container(
                                padding=12,
                                content=ft.Column(
                                    controls=[
                                        ft.Switch(
                                            label="Dark Mode",
                                            value=state.dark_mode,
                                            on_change=on_theme_change,
                                        ),
                                    ]
                                ),
                            )
                        ),
                        ft.Card(
                            content=ft.Container(
                                padding=12,
                                content=ft.Column(
                                    spacing=10,
                                    controls=[
                                        ft.Text("Backend URL", weight=ft.FontWeight.BOLD),
                                        ft.TextField(
                                            ref=backend_field,
                                            value=state.backend_url,
                                            hint_text="http://192.168.1.50:8000",
                                        ),
                                        ft.ElevatedButton("Save", icon=ft.Icons.SAVE, on_click=save_backend_url),
                                    ],
                                ),
                            )
                        ),
                        ft.Card(
                            content=ft.Container(
                                padding=0,
                                content=ft.Column(
                                    controls=[
                                        ft.ListTile(
                                            leading=ft.Icon(ft.Icons.IOS_SHARE),
                                            title=ft.Text("Export History"),
                                            subtitle=ft.Text("Copy all analyses as JSON"),
                                            on_click=export_history,
                                        ),
                                        ft.Divider(height=1),
                                        ft.ListTile(
                                            leading=ft.Icon(ft.Icons.DELETE_OUTLINE, color=ft.Colors.RED),
                                            title=ft.Text("Clear History", color=ft.Colors.RED),
                                            on_click=confirm_clear_history,
                                        ),
                                    ],
                                ),
                            )
                        ),
                        ft.Card(
                            content=ft.ListTile(
                                leading=ft.Icon(ft.Icons.INFO_OUTLINE),
                                title=ft.Text("About"),
                                trailing=ft.Icon(ft.Icons.CHEVRON_RIGHT),
                                on_click=go_about,
                            )
                        ),
                    ],
                ),
            )
        ],
    )
