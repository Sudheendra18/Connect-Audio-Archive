"""Record screen: capture audio with the device microphone, then analyze it."""
import asyncio
import os
import time
import flet as ft
from flet_audio_recorder import AudioRecorder, AudioRecorderConfiguration, AudioEncoder

from models import AppState, AnalysisRecord
import api_client
import storage as storage_mod


def build_view(page: ft.Page, state: AppState, audio_recorder: AudioRecorder) -> ft.View:
    mic_icon = ft.Ref[ft.Icon]()
    record_btn = ft.Ref[ft.ElevatedButton]()
    status_text = ft.Ref[ft.Text]()
    timer_text = ft.Ref[ft.Text]()
    progress = ft.Ref[ft.ProgressRing]()
    analyze_btn = ft.Ref[ft.ElevatedButton]()

    rec_state = {"recording": False, "path": None, "start": 0.0}

    async def tick():
        while rec_state["recording"]:
            elapsed = time.time() - rec_state["start"]
            mins, secs = divmod(int(elapsed), 60)
            timer_text.current.value = f"{mins:02d}:{secs:02d}"
            page.update()
            await asyncio.sleep(1)

    async def toggle_recording(e):
        if not rec_state["recording"]:
            has_perm = await audio_recorder.has_permission()
            if not has_perm:
                status_text.current.value = "Microphone permission denied"
                page.update()
                return

            tmp_dir = await page.storage_paths.get_temporary_directory()
            output_path = os.path.join(tmp_dir, f"recording_{int(time.time())}.wav")

            await audio_recorder.start_recording(
                output_path=output_path,
                configuration=AudioRecorderConfiguration(encoder=AudioEncoder.WAV),
            )
            rec_state["recording"] = True
            rec_state["start"] = time.time()
            rec_state["path"] = output_path

            mic_icon.current.color = ft.Colors.RED
            record_btn.current.content = "Stop Recording"
            record_btn.current.icon = ft.Icons.STOP
            status_text.current.value = "Recording\u2026"
            analyze_btn.current.disabled = True
            page.update()
            page.run_task(tick)
        else:
            path = await audio_recorder.stop_recording()
            rec_state["recording"] = False
            rec_state["path"] = path or rec_state["path"]

            mic_icon.current.color = ft.Colors.DEEP_PURPLE
            record_btn.current.content = "Start Recording"
            record_btn.current.icon = ft.Icons.MIC
            status_text.current.value = "Recording captured. Ready to analyze."
            analyze_btn.current.disabled = False
            page.update()

    async def run_analysis(e):
        if not rec_state["path"]:
            return
        progress.current.visible = True
        status_text.current.value = "Analyzing\u2026"
        analyze_btn.current.disabled = True
        page.update()

        try:
            filename = os.path.basename(rec_state["path"])
            result = await api_client.analyze_audio(
                state.backend_url,
                file_path=rec_state["path"],
                filename=filename,
            )
            record = AnalysisRecord(
                audio_type=result.get("audio_type", "Unknown"),
                language=result.get("language"),
                confidence=result.get("confidence"),
                duration=result.get("duration", 0.0),
                filename=filename,
            )
            state.add_record(record)
            state.current_result = record
            await storage_mod.save_history(page, state)
            page.go("/result")
        except api_client.ApiError as exc:
            progress.current.visible = False
            status_text.current.value = str(exc)
            analyze_btn.current.disabled = False
            page.update()

    return ft.View(
        route="/record",
        appbar=ft.AppBar(title=ft.Text("Record Audio")),
        controls=[
            ft.Container(
                padding=20,
                content=ft.Column(
                    spacing=16,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(ref=mic_icon, icon=ft.Icons.MIC, size=72, color=ft.Colors.DEEP_PURPLE),
                        ft.Text("00:00", ref=timer_text, size=28, weight=ft.FontWeight.BOLD),
                        ft.ElevatedButton(
                            "Start Recording",
                            ref=record_btn,
                            icon=ft.Icons.MIC,
                            on_click=toggle_recording,
                        ),
                        ft.Text("Tap to start recording", ref=status_text, color=ft.Colors.ON_SURFACE_VARIANT),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=8,
                            controls=[ft.ProgressRing(ref=progress, visible=False, width=18, height=18, stroke_width=2)],
                        ),
                        ft.ElevatedButton(
                            "Analyze",
                            ref=analyze_btn,
                            icon=ft.Icons.PLAY_ARROW,
                            disabled=True,
                            on_click=run_analysis,
                        ),
                    ],
                ),
            )
        ],
    )
