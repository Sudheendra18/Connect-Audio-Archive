"""History screen: list of all past analyses, newest first."""
import flet as ft

from models import AppState
import theme as theme_mod


def build_view(page: ft.Page, state: AppState) -> ft.View:
    if not state.history:
        body = ft.Container(
            padding=40,
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(ft.Icons.INBOX_OUTLINED, size=48, color=ft.Colors.ON_SURFACE_VARIANT),
                    ft.Text("No analyses yet", color=ft.Colors.ON_SURFACE_VARIANT),
                ],
            ),
        )
    else:
        tiles = []
        for r in state.history:
            confidence_str = f"{r.confidence * 100:.0f}%" if r.confidence is not None else "\u2014"
            subtitle = r.audio_type
            if r.language:
                subtitle += f" \u00b7 {r.language}"
            subtitle += f" \u00b7 {confidence_str} \u00b7 {r.duration:.1f}s"

            tiles.append(
                ft.ListTile(
                    leading=ft.Icon(theme_mod.type_icon(r.audio_type), color=theme_mod.type_color(r.audio_type)),
                    title=ft.Text(r.filename, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                    subtitle=ft.Text(subtitle, size=12),
                    trailing=ft.Text(r.display_time, size=11, color=ft.Colors.ON_SURFACE_VARIANT),
                )
            )
            tiles.append(ft.Divider(height=1))

        body = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO, controls=tiles)

    return ft.View(
        route="/history",
        appbar=ft.AppBar(title=ft.Text("History")),
        navigation_bar=theme_mod.build_nav_bar(page, 1),
        controls=[ft.Container(expand=True, content=body)],
    )
