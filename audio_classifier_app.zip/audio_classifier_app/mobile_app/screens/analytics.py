"""Analytics screen: summary counts and language distribution."""
import flet as ft
from flet_charts import PieChart, PieChartSection

from models import AppState
import theme as theme_mod

PALETTE = [
    ft.Colors.DEEP_PURPLE,
    ft.Colors.BLUE,
    ft.Colors.GREEN,
    ft.Colors.ORANGE,
    ft.Colors.RED,
    ft.Colors.TEAL,
    ft.Colors.PINK,
    ft.Colors.INDIGO,
]


def build_view(page: ft.Page, state: AppState) -> ft.View:
    counts = state.counts()
    total = len(state.history)
    lang_dist = state.language_distribution()

    stats_row = ft.ResponsiveRow(
        spacing=10,
        run_spacing=10,
        controls=[
            ft.Container(col=6, content=theme_mod.stat_card("Total Analyses", str(total), ft.Icons.GRAPHIC_EQ, ft.Colors.DEEP_PURPLE)),
            ft.Container(col=6, content=theme_mod.stat_card("Speech", str(counts.get("Speech", 0)), ft.Icons.RECORD_VOICE_OVER, theme_mod.type_color("Speech"))),
            ft.Container(col=6, content=theme_mod.stat_card("Music", str(counts.get("Music", 0)), ft.Icons.MUSIC_NOTE, theme_mod.type_color("Music"))),
            ft.Container(col=6, content=theme_mod.stat_card("Noise", str(counts.get("Noise", 0)), ft.Icons.GRAPHIC_EQ, theme_mod.type_color("Noise"))),
        ],
    )

    if lang_dist:
        sections = []
        legend_items = []
        for i, (lang, count) in enumerate(sorted(lang_dist.items(), key=lambda kv: -kv[1])):
            color = PALETTE[i % len(PALETTE)]
            sections.append(
                PieChartSection(
                    value=count,
                    title=str(count),
                    color=color,
                    radius=60,
                )
            )
            legend_items.append(
                ft.Row(
                    spacing=8,
                    controls=[
                        ft.Container(width=12, height=12, bgcolor=color, border_radius=6),
                        ft.Text(f"{lang} ({count})", size=13),
                    ],
                )
            )

        language_section = ft.Card(
            content=ft.Container(
                padding=16,
                content=ft.Column(
                    spacing=12,
                    controls=[
                        ft.Text("Language Distribution", size=16, weight=ft.FontWeight.BOLD),
                        ft.Container(
                            height=200,
                            content=PieChart(sections=sections, sections_space=2, center_space_radius=30),
                        ),
                        ft.Column(spacing=6, controls=legend_items),
                    ],
                ),
            )
        )
    else:
        language_section = ft.Card(
            content=ft.Container(
                padding=24,
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(ft.Icons.LANGUAGE, size=36, color=ft.Colors.ON_SURFACE_VARIANT),
                        ft.Text("No speech analyses with a detected language yet", color=ft.Colors.ON_SURFACE_VARIANT, text_align=ft.TextAlign.CENTER),
                    ],
                ),
            )
        )

    return ft.View(
        route="/analytics",
        appbar=ft.AppBar(title=ft.Text("Analytics")),
        navigation_bar=theme_mod.build_nav_bar(page, 2),
        controls=[
            ft.Container(
                padding=16,
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[stats_row, language_section],
                ),
            )
        ],
    )
