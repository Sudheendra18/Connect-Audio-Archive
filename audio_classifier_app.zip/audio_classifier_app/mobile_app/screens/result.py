"""Result screen: shows the outcome of the most recent analysis."""
import flet as ft

from models import AppState
import theme as theme_mod


def result_row(label: str, value: str, icon) -> ft.Row:
    return ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        controls=[
            ft.Row(
                spacing=8,
                controls=[ft.Icon(icon, size=18, color=ft.Colors.ON_SURFACE_VARIANT), ft.Text(label)],
            ),
            ft.Text(value, weight=ft.FontWeight.BOLD),
        ],
    )


def build_view(page: ft.Page, state: AppState) -> ft.View:
    record = state.current_result

    if record is None:
        body = ft.Container(
            padding=40,
            content=ft.Text("No analysis result available.", color=ft.Colors.ON_SURFACE_VARIANT),
        )
    else:
        color = theme_mod.type_color(record.audio_type)
        icon = theme_mod.type_icon(record.audio_type)
        confidence_str = f"{record.confidence * 100:.1f}%" if record.confidence is not None else "\u2014"
        language_str = record.language or "\u2014"

        body = ft.Column(
            spacing=18,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.CircleAvatar(
                    content=ft.Icon(icon, color=ft.Colors.WHITE, size=36),
                    bgcolor=color,
                    radius=40,
                ),
                ft.Text(record.audio_type, size=24, weight=ft.FontWeight.BOLD),
                ft.Text(record.filename, color=ft.Colors.ON_SURFACE_VARIANT),
                ft.Card(
                    content=ft.Container(
                        padding=16,
                        content=ft.Column(
                            spacing=10,
                            controls=[
                                result_row("Language", language_str, ft.Icons.LANGUAGE),
                                ft.Divider(height=1),
                                result_row("Confidence", confidence_str, ft.Icons.VERIFIED),
                                ft.Divider(height=1),
                                result_row("Duration", f"{record.duration:.1f}s", ft.Icons.TIMER),
                                ft.Divider(height=1),
                                result_row("Analyzed", record.display_time, ft.Icons.SCHEDULE),
                            ],
                        ),
                    ),
                ),
            ],
        )

    def go_home(e):
        page.go("/")

    def go_history(e):
        page.go("/history")

    return ft.View(
        route="/result",
        appbar=ft.AppBar(title=ft.Text("Result")),
        controls=[
            ft.Container(
                padding=20,
                content=ft.Column(
                    spacing=20,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[
                        body,
                        ft.Row(
                            spacing=10,
                            controls=[
                                ft.OutlinedButton(
                                    "View History", icon=ft.Icons.HISTORY, expand=True, on_click=go_history
                                ),
                                ft.ElevatedButton(
                                    "Done", icon=ft.Icons.CHECK, expand=True, on_click=go_home
                                ),
                            ],
                        ),
                    ],
                ),
            )
        ],
    )
