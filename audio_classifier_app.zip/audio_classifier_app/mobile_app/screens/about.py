"""About screen: model details and app version."""
import flet as ft


APP_VERSION = "1.0.0"


def info_card(title: str, icon, color: str, lines: list[str]) -> ft.Card:
    return ft.Card(
        content=ft.Container(
            padding=16,
            content=ft.Column(
                spacing=8,
                controls=[
                    ft.Row(
                        spacing=8,
                        controls=[ft.Icon(icon, color=color), ft.Text(title, size=16, weight=ft.FontWeight.BOLD)],
                    ),
                    *[ft.Text(line, size=13, color=ft.Colors.ON_SURFACE_VARIANT) for line in lines],
                ],
            ),
        )
    )


def build_view(page: ft.Page, state) -> ft.View:
    return ft.View(
        route="/about",
        appbar=ft.AppBar(title=ft.Text("About")),
        controls=[
            ft.Container(
                padding=16,
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(ft.Icons.GRAPHIC_EQ, size=56, color=ft.Colors.DEEP_PURPLE),
                        ft.Text("Audio Classifier", size=20, weight=ft.FontWeight.BOLD),
                        ft.Text(f"Version {APP_VERSION}", color=ft.Colors.ON_SURFACE_VARIANT),
                        info_card(
                            "Audio Type Classifier",
                            ft.Icons.GRAPHIC_EQ,
                            ft.Colors.DEEP_PURPLE,
                            [
                                "Support Vector Machine (SVM), trained on the MUSAN dataset.",
                                "Classifies clips as Speech, Music, or Noise.",
                                "57 audio features per clip via Librosa: 40 MFCC "
                                "(mean + std), 12 chroma means, and 5 spectral "
                                "features (centroid, bandwidth, rolloff, zero-"
                                "crossing rate, RMS energy).",
                                "Selected after comparison against Logistic "
                                "Regression, KNN, Random Forest, Extra Trees, "
                                "and XGBoost.",
                            ],
                        ),
                        info_card(
                            "Language Detection",
                            ft.Icons.LANGUAGE,
                            ft.Colors.BLUE,
                            [
                                "OpenAI Whisper (small model), run only when the "
                                "clip is classified as Speech.",
                                "Covers English, French, German, Hindi, Kannada, "
                                "Korean, Malayalam, Spanish, Tamil, Telugu, and Urdu.",
                            ],
                        ),
                        info_card(
                            "Pipeline",
                            ft.Icons.ACCOUNT_TREE,
                            ft.Colors.GREEN,
                            [
                                "Audio \u2192 SVM \u2192 Speech? \u2192 Whisper Small \u2192 Language.",
                                "Music and Noise clips skip language detection.",
                            ],
                        ),
                    ],
                ),
            )
        ],
    )
