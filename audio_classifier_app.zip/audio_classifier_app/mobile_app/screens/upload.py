"""Upload screen: pick an audio file from device storage and analyze it."""
import flet as ft

from models import AppState, AnalysisRecord
import api_client
import storage as storage_mod


def build_view(page: ft.Page, state: AppState, file_picker: ft.FilePicker) -> ft.View:
    selected_name = ft.Ref[ft.Text]()
    status_text = ft.Ref[ft.Text]()
    progress = ft.Ref[ft.ProgressRing]()
    analyze_btn = ft.Ref[ft.ElevatedButton]()

    picked = {"path": None, "bytes": None, "name": None}

    async def choose_file(e):
        files = await file_picker.pick_files(
            dialog_title="Select an audio file",
            allowed_extensions=["wav", "mp3", "m4a", "flac", "ogg"],
            allow_multiple=False,
            with_data=True,
        )
        if not files:
            return
        f = files[0]
        picked["path"] = f.path
        picked["bytes"] = f.bytes
        picked["name"] = f.name
        selected_name.current.value = f.name
        selected_name.current.italic = False
        status_text.current.value = "Ready to analyze"
        analyze_btn.current.disabled = False
        page.update()

    async def run_analysis(e):
        if not picked["name"]:
            return
        progress.current.visible = True
        status_text.current.value = "Analyzing\u2026"
        analyze_btn.current.disabled = True
        page.update()

        try:
            result = await api_client.analyze_audio(
                state.backend_url,
                file_path=picked["path"] if not picked["bytes"] else None,
                file_bytes=picked["bytes"],
                filename=picked["name"],
            )
            record = AnalysisRecord(
                audio_type=result.get("audio_type", "Unknown"),
                language=result.get("language"),
                confidence=result.get("confidence"),
                duration=result.get("duration", 0.0),
                filename=picked["name"],
            )
            state.add_record(record)
            state.current_result = record
            await storage_mod.save_history(page, state)
            page.go("/result")
        except api_client.ApiError as exc:
            progress.current.visible = False
            status_text.current.value = str(exc)
            analyze_btn.current.disabled = False
            page.update()

    return ft.View(
        route="/upload",
        appbar=ft.AppBar(title=ft.Text("Upload Audio")),
        controls=[
            ft.Container(
                padding=20,
                content=ft.Column(
                    spacing=16,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(ft.Icons.UPLOAD_FILE, size=64, color=ft.Colors.DEEP_PURPLE),
                        ft.Text(
                            "Choose a speech, music, or noise clip to classify.",
                            text_align=ft.TextAlign.CENTER,
                            color=ft.Colors.ON_SURFACE_VARIANT,
                        ),
                        ft.ElevatedButton("Choose Audio File", icon=ft.Icons.FOLDER_OPEN, on_click=choose_file),
                        ft.Text("No file selected", ref=selected_name, italic=True),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=8,
                            controls=[
                                ft.ProgressRing(ref=progress, visible=False, width=18, height=18, stroke_width=2),
                                ft.Text("", ref=status_text),
                            ],
                        ),
                        ft.ElevatedButton(
                            "Analyze",
                            ref=analyze_btn,
                            icon=ft.Icons.PLAY_ARROW,
                            disabled=True,
                            on_click=run_analysis,
                        ),
                    ],
                ),
            )
        ],
    )
