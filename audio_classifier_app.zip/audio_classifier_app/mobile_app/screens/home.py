"""Home screen: quick actions, stat cards, recent analyses."""
import flet as ft
from models import AppState
import theme as theme_mod


def build_view(page: ft.Page, state: AppState) -> ft.View:
    counts = state.counts()
    total = len(state.history)

    stats_row = ft.ResponsiveRow(
        spacing=10,
        run_spacing=10,
        controls=[
            ft.Container(col=6, content=theme_mod.stat_card("Total", str(total), ft.Icons.GRAPHIC_EQ, ft.Colors.DEEP_PURPLE)),
            ft.Container(col=6, content=theme_mod.stat_card("Speech", str(counts.get("Speech", 0)), ft.Icons.RECORD_VOICE_OVER, theme_mod.type_color("Speech"))),
            ft.Container(col=6, content=theme_mod.stat_card("Music", str(counts.get("Music", 0)), ft.Icons.MUSIC_NOTE, theme_mod.type_color("Music"))),
            ft.Container(col=6, content=theme_mod.stat_card("Noise", str(counts.get("Noise", 0)), ft.Icons.GRAPHIC_EQ, theme_mod.type_color("Noise"))),
        ],
    )

    def go_upload(e):
        page.go("/upload")

    def go_record(e):
        page.go("/record")

    quick_actions = ft.Row(
        spacing=10,
        controls=[
            ft.ElevatedButton(
                "Upload Audio",
                icon=ft.Icons.UPLOAD_FILE,
                expand=True,
                on_click=go_upload,
            ),
            ft.OutlinedButton(
                "Record Audio",
                icon=ft.Icons.MIC,
                expand=True,
                on_click=go_record,
            ),
        ],
    )

    recent = state.history[:3]
    if recent:
        recent_controls = []
        for r in recent:
            recent_controls.append(
                ft.ListTile(
                    leading=ft.Icon(theme_mod.type_icon(r.audio_type), color=theme_mod.type_color(r.audio_type)),
                    title=ft.Text(r.filename, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                    subtitle=ft.Text(f"{r.audio_type}" + (f" \u00b7 {r.language}" if r.language else "")),
                    trailing=ft.Text(r.display_time, size=11, color=ft.Colors.ON_SURFACE_VARIANT),
                )
            )
        recent_section = ft.Column(spacing=0, controls=recent_controls)
    else:
        recent_section = ft.Container(
            padding=20,
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(ft.Icons.INBOX_OUTLINED, size=40, color=ft.Colors.ON_SURFACE_VARIANT),
                    ft.Text("No analyses yet", color=ft.Colors.ON_SURFACE_VARIANT),
                ],
            ),
        )

    def go_history(e):
        page.go("/history")

    return ft.View(
        route="/",
        appbar=ft.AppBar(title=ft.Text("Audio Classifier"), center_title=False),
        navigation_bar=theme_mod.build_nav_bar(page, 0),
        controls=[
            ft.Container(
                padding=16,
                content=ft.Column(
                    spacing=16,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[
                        quick_actions,
                        stats_row,
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.Text("Recent Analyses", size=16, weight=ft.FontWeight.BOLD),
                                ft.TextButton("See all", on_click=go_history),
                            ],
                        ),
                        ft.Card(content=ft.Container(padding=0, content=recent_section)),
                    ],
                ),
            )
        ],
    )
