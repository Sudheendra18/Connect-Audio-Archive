"""Local on-device persistence (history + theme preference)."""
import flet as ft
from models import AppState

HISTORY_KEY = "analysis_history"
THEME_KEY = "dark_mode"
BACKEND_URL_KEY = "backend_url"


async def load_state(page: ft.Page, state: AppState) -> None:
    history_json = await page.shared_preferences.get(HISTORY_KEY)
    if isinstance(history_json, str):
        state.history = state.history_from_json(history_json)

    dark = await page.shared_preferences.get(THEME_KEY)
    state.dark_mode = bool(dark) if dark is not None else False

    backend_url = await page.shared_preferences.get(BACKEND_URL_KEY)
    if isinstance(backend_url, str) and backend_url:
        state.backend_url = backend_url


async def save_history(page: ft.Page, state: AppState) -> None:
    await page.shared_preferences.set(HISTORY_KEY, state.history_to_json())


async def save_theme(page: ft.Page, state: AppState) -> None:
    await page.shared_preferences.set(THEME_KEY, state.dark_mode)


async def save_backend_url(page: ft.Page, state: AppState) -> None:
    await page.shared_preferences.set(BACKEND_URL_KEY, state.backend_url)


async def clear_history(page: ft.Page, state: AppState) -> None:
    state.history = []
    await page.shared_preferences.remove(HISTORY_KEY)
