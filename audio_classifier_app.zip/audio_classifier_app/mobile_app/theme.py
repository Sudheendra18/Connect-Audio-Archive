"""Shared theme, colors, and small UI helpers used across screens."""
import flet as ft

SEED_COLOR = ft.Colors.DEEP_PURPLE

TYPE_COLORS = {
    "Speech": ft.Colors.BLUE,
    "Music": ft.Colors.GREEN,
    "Noise": ft.Colors.ORANGE,
}

TYPE_ICONS = {
    "Speech": ft.Icons.RECORD_VOICE_OVER,
    "Music": ft.Icons.MUSIC_NOTE,
    "Noise": ft.Icons.GRAPHIC_EQ,
}

NAV_ROUTES = ["/", "/history", "/analytics", "/settings"]


def make_theme() -> ft.Theme:
    return ft.Theme(color_scheme_seed=SEED_COLOR, use_material3=True)


def type_color(audio_type: str | None) -> str:
    return TYPE_COLORS.get(audio_type or "", ft.Colors.GREY)


def type_icon(audio_type: str | None):
    return TYPE_ICONS.get(audio_type or "", ft.Icons.HELP_OUTLINE)


def build_nav_bar(page: ft.Page, selected_index: int) -> ft.NavigationBar:
    def on_change(e: ft.ControlEvent):
        page.go(NAV_ROUTES[e.control.selected_index])

    return ft.NavigationBar(
        selected_index=selected_index,
        on_change=on_change,
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME_OUTLINED, selected_icon=ft.Icons.HOME, label="Home"),
            ft.NavigationBarDestination(icon=ft.Icons.HISTORY, label="History"),
            ft.NavigationBarDestination(icon=ft.Icons.BAR_CHART_OUTLINED, selected_icon=ft.Icons.BAR_CHART, label="Stats"),
            ft.NavigationBarDestination(icon=ft.Icons.SETTINGS_OUTLINED, selected_icon=ft.Icons.SETTINGS, label="Settings"),
        ],
    )


def stat_card(title: str, value: str, icon, color: str) -> ft.Card:
    return ft.Card(
        elevation=2,
        content=ft.Container(
            padding=16,
            content=ft.Column(
                spacing=6,
                controls=[
                    ft.Row(
                        controls=[ft.Icon(icon, color=color, size=20)],
                    ),
                    ft.Text(value, size=24, weight=ft.FontWeight.BOLD),
                    ft.Text(title, size=12, color=ft.Colors.ON_SURFACE_VARIANT),
                ],
            ),
        ),
    )
