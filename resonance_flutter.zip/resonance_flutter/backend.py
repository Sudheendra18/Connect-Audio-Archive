"""
Resonance FastAPI Backend
=========================
Wraps audio_pipeline.py for the Flutter app.

Run with:
    uvicorn backend:app --host 0.0.0.0 --port 8000 --reload

The Flutter Android app connects to:
  - Android Emulator : http://10.0.2.2:8000
  - Physical device  : http://<your-PC-IP>:8000   (e.g. http://192.168.1.5:8000)
"""

import os
import shutil
import tempfile
import traceback

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

# ─── Pipeline import (same graceful fallback as Flet app) ─────────────────────
try:
    from audio_pipeline import analyze_audio as _analyze_audio
    _PIPELINE_READY = True
    _PIPELINE_ERR   = None
except Exception as _e:
    _PIPELINE_READY = False
    _PIPELINE_ERR   = str(_e)

# ─── Duration helper ──────────────────────────────────────────────────────────
def _get_duration(path: str) -> Optional[str]:
    try:
        import librosa
        try:
            secs = librosa.get_duration(path=path)
        except TypeError:
            secs = librosa.get_duration(filename=path)
        return f"{secs:.1f}s" if secs < 60 else f"{int(secs//60)}:{int(secs%60):02d}"
    except Exception:
        pass
    try:
        import wave
        with wave.open(path, "rb") as w:
            secs = w.getnframes() / float(w.getframerate())
        return f"{secs:.1f}s" if secs < 60 else f"{int(secs//60)}:{int(secs%60):02d}"
    except Exception:
        pass
    return None

# ─── App ──────────────────────────────────────────────────────────────────────
app = FastAPI(title="Resonance Backend", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class AnalysisResult(BaseModel):
    audio_type: str
    language: Optional[str] = None
    duration: Optional[str] = None

@app.get("/health")
def health():
    return {
        "status": "ok",
        "pipeline_ready": _PIPELINE_READY,
        "pipeline_error": _PIPELINE_ERR,
    }

@app.post("/analyze", response_model=AnalysisResult)
async def analyze(file: UploadFile = File(...)):
    if not _PIPELINE_READY:
        raise HTTPException(
            status_code=503,
            detail=f"Pipeline not available: {_PIPELINE_ERR}"
        )

    # Save upload to a temp file
    suffix = os.path.splitext(file.filename or "audio.wav")[1] or ".wav"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        shutil.copyfileobj(file.file, tmp)
        tmp.close()

        result   = _analyze_audio(tmp.name)
        duration = _get_duration(tmp.name)

        return AnalysisResult(
            audio_type=result.get("audio_type", "Noise"),
            language=result.get("language"),
            duration=duration,
        )
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        try:
            os.unlink(tmp.name)
        except Exception:
            pass
