import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── Analysis record ──────────────────────────────────────────────────────────
class AnalysisRecord {
  final String filename;
  final String audioType;
  final String? language;
  final String? duration;
  final String timestamp;

  AnalysisRecord({
    required this.filename,
    required this.audioType,
    this.language,
    this.duration,
    required this.timestamp,
  });

  factory AnalysisRecord.fromJson(Map<String, dynamic> j) => AnalysisRecord(
        filename:  j['filename']   ?? 'unknown',
        audioType: j['audio_type'] ?? 'Noise',
        language:  j['language'],
        duration:  j['duration'],
        timestamp: j['timestamp']  ?? '',
      );

  Map<String, dynamic> toJson() => {
        'filename':   filename,
        'audio_type': audioType,
        'language':   language,
        'duration':   duration,
        'timestamp':  timestamp,
      };
}

// ─── App state (ChangeNotifier → rebuilds all consumers) ─────────────────────
class AppState extends ChangeNotifier {
  // Settings
  bool   _isDark         = true;
  double _glassIntensity = 1.0;

  // Navigation
  String _currentScreen = 'home';

  // Analysis state
  String?           _filePath;
  String?           _fileName;
  bool              _analyzing = false;
  String            _statusMessage = 'No file selected yet';
  Map<String, dynamic>? _result;
  String?           _duration;

  // History
  List<AnalysisRecord> _history = [];

  // Backend URL (configurable from Settings)
  String _backendUrl = 'http://10.0.2.2:8000'; // Android emulator → localhost

  // ── Getters ──────────────────────────────────────────────────────────────
  bool   get isDark         => _isDark;
  double get glassIntensity => _glassIntensity;
  String get currentScreen  => _currentScreen;
  String? get filePath      => _filePath;
  String? get fileName      => _fileName;
  bool   get analyzing      => _analyzing;
  String get statusMessage  => _statusMessage;
  Map<String, dynamic>? get result => _result;
  String? get duration      => _duration;
  List<AnalysisRecord> get history => _history;
  String get backendUrl     => _backendUrl;

  // ── Init ──────────────────────────────────────────────────────────────────
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _isDark         = prefs.getBool('isDark') ?? true;
    _glassIntensity = prefs.getDouble('glassIntensity') ?? 1.0;
    _backendUrl     = prefs.getString('backendUrl') ?? 'http://10.0.2.2:8000';

    final raw = prefs.getString('history');
    if (raw != null) {
      try {
        final List decoded = jsonDecode(raw);
        _history = decoded.map((e) => AnalysisRecord.fromJson(e)).toList();
      } catch (_) {}
    }
    notifyListeners();
  }

  // ── Settings ──────────────────────────────────────────────────────────────
  Future<void> setTheme(bool dark) async {
    _isDark = dark;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDark', dark);
    notifyListeners();
  }

  Future<void> setGlassIntensity(double v) async {
    _glassIntensity = v;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('glassIntensity', v);
    notifyListeners();
  }

  Future<void> setBackendUrl(String url) async {
    _backendUrl = url;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('backendUrl', url);
    notifyListeners();
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void navigate(String screen) {
    _currentScreen = screen;
    notifyListeners();
  }

  // ── Analysis ─────────────────────────────────────────────────────────────
  void startAnalysis(String path, String name) {
    _filePath      = path;
    _fileName      = name;
    _result        = null;
    _duration      = null;
    _analyzing     = true;
    _statusMessage = 'Analyzing $name…';
    notifyListeners();
  }

  void setResult(Map<String, dynamic> result, String? duration) {
    _result    = result;
    _duration  = duration;
    _analyzing = false;
    _statusMessage = 'Done';

    final now = DateTime.now();
    final ts  = '${now.year}-${_p2(now.month)}-${_p2(now.day)} '
                '${_p2(now.hour)}:${_p2(now.minute)}';

    final record = AnalysisRecord(
      filename:  _fileName ?? 'unknown',
      audioType: result['audio_type'] ?? 'Noise',
      language:  result['language'],
      duration:  duration,
      timestamp: ts,
    );
    _history.insert(0, record);
    if (_history.length > 200) _history = _history.sublist(0, 200);
    _persistHistory();
    notifyListeners();
  }

  void setError(String msg) {
    _analyzing     = false;
    _statusMessage = 'Error: $msg';
    _result        = null;
    notifyListeners();
  }

  // ── History ───────────────────────────────────────────────────────────────
  Future<void> clearHistory() async {
    _history = [];
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('history');
    notifyListeners();
  }

  String exportText() {
    final buf = StringBuffer()
      ..writeln('Resonance — Analysis History')
      ..writeln('=' * 40);
    for (final r in _history) {
      buf
        ..writeln('\nDate     : ${r.timestamp}')
        ..writeln('File     : ${r.filename}')
        ..writeln('Type     : ${r.audioType}');
      if (r.language != null) buf.writeln('Language : ${r.language}');
      if (r.duration  != null) buf.writeln('Duration : ${r.duration}');
      buf.writeln('-' * 30);
    }
    return buf.toString();
  }

  // ── Stats ─────────────────────────────────────────────────────────────────
  Map<String, dynamic> stats() {
    int speech = 0, music = 0, noise = 0;
    final langDist = <String, int>{};
    for (final r in _history) {
      if (r.audioType == 'Speech') speech++;
      else if (r.audioType == 'Music') music++;
      else if (r.audioType == 'Noise') noise++;
      if (r.language != null) {
        langDist[r.language!] = (langDist[r.language!] ?? 0) + 1;
      }
    }
    final total = _history.length;
    String mostCommon = '—';
    if (total > 0) {
      final m = {'Speech': speech, 'Music': music, 'Noise': noise};
      mostCommon = m.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
    }
    return {
      'total': total, 'speech': speech, 'music': music, 'noise': noise,
      'lang_dist': langDist, 'most_common': mostCommon,
    };
  }

  List<MapEntry<String, int>> weeklyVolume() {
    final today = DateTime.now();
    final days = List.generate(7, (i) => today.subtract(Duration(days: 6 - i)));
    final counts = <String, int>{};
    for (final d in days) {
      counts[_dayKey(d)] = 0;
    }
    for (final r in _history) {
      try {
        final parts = r.timestamp.split(' ');
        if (parts.isEmpty) continue;
        final dateParts = parts[0].split('-');
        if (dateParts.length < 3) continue;
        final d = DateTime(int.parse(dateParts[0]),
            int.parse(dateParts[1]), int.parse(dateParts[2]));
        final k = _dayKey(d);
        if (counts.containsKey(k)) counts[k] = counts[k]! + 1;
      } catch (_) {}
    }
    final labels = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    return days.map((d) => MapEntry(_shortDay(d, labels), counts[_dayKey(d)] ?? 0)).toList();
  }

  // ── Privates ──────────────────────────────────────────────────────────────
  Future<void> _persistHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('history', jsonEncode(_history.map((r) => r.toJson()).toList()));
  }

  String _p2(int v) => v.toString().padLeft(2, '0');
  String _dayKey(DateTime d) => '${d.year}-${_p2(d.month)}-${_p2(d.day)}';
  String _shortDay(DateTime d, List<String> labels) => labels[d.weekday - 1];
}
