import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

// ─── Glass card ───────────────────────────────────────────────────────────────
class GlassCard extends StatelessWidget {
  final Widget child;
  final AppPalette pal;
  final double intensity;
  final double radius;
  final EdgeInsets? padding;
  final double? width;
  final double? height;
  final VoidCallback? onTap;

  const GlassCard({
    super.key,
    required this.child,
    required this.pal,
    this.intensity = 1.0,
    this.radius = 26,
    this.padding,
    this.width,
    this.height,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: pal.blur * intensity, sigmaY: pal.blur * intensity),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            width: width,
            height: height,
            padding: padding ?? const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: pal.glassColor(intensity),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(color: pal.borderColor(intensity), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: pal.shadowColor(intensity),
                  blurRadius: 34,
                  offset: const Offset(0, 14),
                ),
              ],
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ─── Inset card ───────────────────────────────────────────────────────────────
class InsetCard extends StatelessWidget {
  final Widget child;
  final AppPalette pal;
  final double radius;
  final EdgeInsets? padding;
  final double? height;

  const InsetCard({
    super.key,
    required this.child,
    required this.pal,
    this.radius = 18,
    this.padding,
    this.height,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: pal.insetColor(),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: pal.borderColor(0.7), width: 1),
      ),
      child: child,
    );
  }
}

// ─── Icon badge ───────────────────────────────────────────────────────────────
class IconBadge extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;
  final double iconSize;

  const IconBadge({
    super.key,
    required this.icon,
    required this.color,
    this.size = 46,
    this.iconSize = 22,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color.withOpacity(0.16),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Icon(icon, color: color, size: iconSize),
      alignment: Alignment.center,
    );
  }
}

// ─── Chip ─────────────────────────────────────────────────────────────────────
class TypeChip extends StatelessWidget {
  final String label;
  final Color color;

  const TypeChip({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(100),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7, height: 7,
            decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(7)),
          ),
          const SizedBox(width: 7),
          Text(label,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
        ],
      ),
    );
  }
}

class CountChip extends StatelessWidget {
  final String label;
  final Color color;

  const CountChip({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(100),
      ),
      child: Text(label,
        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)),
    );
  }
}

// ─── Pill button ──────────────────────────────────────────────────────────────
class PillButton extends StatelessWidget {
  final AppPalette pal;
  final String label;
  final IconData icon;
  final VoidCallback? onTap;
  final bool primary;
  final bool expand;

  const PillButton({
    super.key,
    required this.pal,
    required this.label,
    required this.icon,
    this.onTap,
    this.primary = false,
    this.expand = false,
  });

  @override
  Widget build(BuildContext context) {
    final content = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
      children: [
        Icon(icon, size: 18, color: primary ? kOnAcc : pal.text),
        const SizedBox(width: 8),
        Text(label,
          style: TextStyle(
            fontSize: 14, fontWeight: FontWeight.w600,
            color: primary ? kOnAcc : pal.text,
          )),
      ],
    );

    if (primary) {
      return GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
          decoration: BoxDecoration(
            gradient: onTap == null
                ? LinearGradient(colors: [kAccent.withOpacity(0.4), kViolet.withOpacity(0.4)])
                : const LinearGradient(colors: [kAccent, kViolet]),
            borderRadius: BorderRadius.circular(100),
            boxShadow: onTap == null ? [] : [
              BoxShadow(color: kAccent.withOpacity(0.45), blurRadius: 22, offset: const Offset(0, 6)),
            ],
          ),
          child: expand ? content : content,
        ),
      );
    }

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(pal.isDark ? 0.06 : 0.6),
          borderRadius: BorderRadius.circular(100),
          border: Border.all(color: pal.borderColor(1.0), width: 1.2),
        ),
        child: content,
      ),
    );
  }
}

// ─── Equalizer bars ───────────────────────────────────────────────────────────
class EqualizerBars extends StatefulWidget {
  final int bars;
  final double maxHeight;
  final int seed;
  final bool animated;

  const EqualizerBars({
    super.key,
    this.bars = 28,
    this.maxHeight = 70,
    this.seed = 7,
    this.animated = false,
  });

  @override
  State<EqualizerBars> createState() => _EqualizerBarsState();
}

class _EqualizerBarsState extends State<EqualizerBars>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    if (widget.animated) _controller.repeat();
  }

  @override
  void didUpdateWidget(EqualizerBars old) {
    super.didUpdateWidget(old);
    if (widget.animated && !_controller.isAnimating) {
      _controller.repeat();
    } else if (!widget.animated && _controller.isAnimating) {
      _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        final phase = _controller.value * 2 * math.pi;
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: List.generate(widget.bars, (i) {
            final env = math.sin(math.pi * (i + 0.5) / widget.bars);
            double h;
            if (widget.animated) {
              h = math.max(6,
                (0.2 + 0.8 * env) *
                (0.3 + 0.7 * (math.sin(phase + i * 0.45)).abs()) *
                widget.maxHeight);
            } else {
              final jitter = 0.35 + 0.65 *
                  (((i * 9301 + widget.seed * 49297) % 233280) / 233280);
              h = math.max(8, (0.25 + 0.75 * env) * jitter * widget.maxHeight);
            }
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Container(
                width: 5,
                height: h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  gradient: const LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [kAccent2, kAccent, kViolet],
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}

// ─── Gradient divider ─────────────────────────────────────────────────────────
class GlassDivider extends StatelessWidget {
  final AppPalette pal;
  const GlassDivider({super.key, required this.pal});

  @override
  Widget build(BuildContext context) =>
      Container(height: 1, color: pal.dividerColor());
}

// ─── Background blobs ─────────────────────────────────────────────────────────
class AuroraBackground extends StatelessWidget {
  final AppPalette pal;
  final Widget child;

  const AuroraBackground({super.key, required this.pal, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      // bg gradient
      Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: pal.bg,
          ),
        ),
      ),
      // blobs
      if (pal.isDark) ...[
        _blob(const Color(0xFF2747D8), 0.52, 560, left: -120, top: -140),
        _blob(kViolet,                 0.42, 620, right: -160, bottom: -180),
        _blob(kAccent2,                0.32, 460, right: 240,  top: -120),
      ] else ...[
        _blob(kAccent,  0.30, 560, left: -120, top: -140),
        _blob(kViolet,  0.26, 620, right: -160, bottom: -180),
        _blob(kAccent2, 0.24, 460, right: 240,  top: -120),
      ],
      child,
    ]);
  }

  Widget _blob(Color color, double opacity, double size,
      {double? left, double? top, double? right, double? bottom}) {
    return Positioned(
      left: left, top: top, right: right, bottom: bottom,
      child: Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color.withOpacity(opacity), color.withOpacity(0)],
          ),
        ),
      ),
    );
  }
}

// ─── Segmented control ────────────────────────────────────────────────────────
class SegmentedToggle extends StatelessWidget {
  final AppPalette pal;
  final List<String> options;
  final String active;
  final void Function(String) onSelect;

  const SegmentedToggle({
    super.key,
    required this.pal,
    required this.options,
    required this.active,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: pal.insetColor(),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: pal.borderColor(0.7), width: 1),
      ),
      child: Row(
        children: options.map((opt) {
          final isActive = opt == active;
          return Expanded(
            child: GestureDetector(
              onTap: () => onSelect(opt),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: isActive ? kAccent : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center,
                child: Text(opt,
                  style: TextStyle(
                    fontSize: 13.5, fontWeight: FontWeight.w600,
                    color: isActive ? kOnAcc : pal.text2,
                  )),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ─── Spec row (key / value) ───────────────────────────────────────────────────
class SpecRow extends StatelessWidget {
  final AppPalette pal;
  final String keyText;
  final String valueText;

  const SpecRow({super.key, required this.pal, required this.keyText, required this.valueText});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(keyText,   style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500, color: pal.muted)),
        const Spacer(),
        Text(valueText, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: pal.text)),
      ],
    );
  }
}

// ─── Setting block ────────────────────────────────────────────────────────────
class SettingBlock extends StatelessWidget {
  final AppPalette pal;
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final Widget control;

  const SettingBlock({
    super.key,
    required this.pal,
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.control,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          IconBadge(icon: icon, color: color, size: 42, iconSize: 20),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,    style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600, color: pal.text)),
                Text(subtitle, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500, color: pal.muted)),
              ],
            ),
          ),
          control,
        ],
      ),
    );
  }
}

// ─── Vertical bar (for chart) ─────────────────────────────────────────────────
class VBar extends StatelessWidget {
  final double value;
  final double maxValue;
  final Color color;
  final double width;
  final double maxH;

  const VBar({
    super.key,
    required this.value,
    required this.maxValue,
    this.color = kAccent,
    this.width = 20,
    this.maxH = 150,
  });

  @override
  Widget build(BuildContext context) {
    final h = maxValue > 0 ? math.max(6.0, (value / maxValue) * maxH) : 6.0;
    return SizedBox(
      width: this.width,
      height: maxH,
      child: Column(
        children: [
          Expanded(child: Container()),
          Container(
            width: this.width,
            height: h,
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [color.withOpacity(0.85), color.withOpacity(0.45)],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
