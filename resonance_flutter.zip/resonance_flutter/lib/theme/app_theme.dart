import 'package:flutter/material.dart';

// ─── Brand palette ────────────────────────────────────────────────────────────
const Color kAccent  = Color(0xFF2E6BFF);
const Color kAccent2 = Color(0xFF00C2FF);
const Color kViolet  = Color(0xFF7C5CFF);
const Color kMint    = Color(0xFF27C58D);
const Color kWarn    = Color(0xFFF4A63A);
const Color kErr     = Color(0xFFFF6B81);
const Color kOnAcc   = Color(0xFFFFFFFF);

// ─── Dark theme palette ───────────────────────────────────────────────────────
const List<Color> kDarkBg = [
  Color(0xFF070B1E),
  Color(0xFF0D1430),
  Color(0xFF0A1024),
];

class DarkPalette {
  static const Color text    = Color(0xFFF1F3FF);
  static const Color text2   = Color(0xFFA6ADD0);
  static const Color muted   = Color(0xFF717A9F);
  static const double glass  = 0.07;
  static const double brd    = 0.14;
  static const double inset  = 0.05;
  static const double shadow = 0.38;
  static const double blur   = 20;
  static const double field  = 0.06;
}

// ─── Light theme palette ──────────────────────────────────────────────────────
const List<Color> kLightBg = [
  Color(0xFFE9F0FF),
  Color(0xFFEFEAFF),
  Color(0xFFE3F6FF),
];

class LightPalette {
  static const Color text    = Color(0xFF0E1330);
  static const Color text2   = Color(0xFF565E86);
  static const Color muted   = Color(0xFF8A90B4);
  static const double glass  = 0.55;
  static const double brd    = 0.75;
  static const double inset  = 0.45;
  static const double shadow = 0.10;
  static const double blur   = 18;
  static const double field  = 0.55;
}

// ─── App palette accessor ─────────────────────────────────────────────────────
class AppPalette {
  final bool isDark;
  const AppPalette(this.isDark);

  Color get text   => isDark ? DarkPalette.text   : LightPalette.text;
  Color get text2  => isDark ? DarkPalette.text2  : LightPalette.text2;
  Color get muted  => isDark ? DarkPalette.muted  : LightPalette.muted;
  double get glass => isDark ? DarkPalette.glass  : LightPalette.glass;
  double get brd   => isDark ? DarkPalette.brd    : LightPalette.brd;
  double get inset => isDark ? DarkPalette.inset  : LightPalette.inset;
  double get shadow=> isDark ? DarkPalette.shadow : LightPalette.shadow;
  double get blur  => isDark ? DarkPalette.blur   : LightPalette.blur;
  List<Color> get bg => isDark ? kDarkBg : kLightBg;

  Color glassColor  (double intensity) => Colors.white.withOpacity(glass * intensity);
  Color borderColor (double intensity) => Colors.white.withOpacity(brd   * intensity);
  Color insetColor  ()                 => Colors.white.withOpacity(inset);
  Color shadowColor (double intensity) => Colors.black.withOpacity(shadow* intensity);
  Color dividerColor()                 => text.withOpacity(0.10);
}

// ─── Classification meta ──────────────────────────────────────────────────────
Map<String, Map<String, dynamic>> kClassMeta = {
  'Speech': {'icon': Icons.mic_rounded,        'color': kAccent},
  'Music':  {'icon': Icons.music_note_rounded,  'color': kViolet},
  'Noise':  {'icon': Icons.graphic_eq_rounded,  'color': kAccent2},
};

IconData classIcon(String label) =>
    kClassMeta[label]?['icon'] as IconData? ?? Icons.graphic_eq_rounded;

Color classColor(String label) =>
    kClassMeta[label]?['color'] as Color? ?? kAccent;

// ─── Languages ────────────────────────────────────────────────────────────────
const List<String> kLanguages = [
  'English', 'French', 'German', 'Hindi',
  'Kannada', 'Korean', 'Malayalam', 'Spanish',
  'Tamil', 'Telugu', 'Urdu',
];
