import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_widgets.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state  = context.watch<AppState>();
    final pal    = AppPalette(state.isDark);
    final gi     = state.glassIntensity;
    final stats  = state.stats();
    final total  = stats['total']  as int;
    final speech = stats['speech'] as int;
    final music  = stats['music']  as int;
    final noise  = stats['noise']  as int;

    // ── Stat tiles 2×2 ──────────────────────────────────────────────────────
    Widget statCard(IconData icon, Color color, int value, String label) =>
        GlassCard(
          pal: pal, intensity: gi, padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              IconBadge(icon: icon, color: color, size: 38, iconSize: 18),
              const SizedBox(height: 8),
              Text('$value',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700,
                    color: pal.text, letterSpacing: 0.3)),
              Text(label,
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: pal.text2)),
            ],
          ),
        );

    final statGrid = GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.5,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        statCard(Icons.stacked_bar_chart, kAccent,  total,  'Total'),
        statCard(Icons.mic_rounded,       kAccent,  speech, 'Speech'),
        statCard(Icons.music_note_rounded, kViolet, music,  'Music'),
        statCard(Icons.graphic_eq_rounded, kAccent2,noise,  'Noise'),
      ],
    );

    // ── Weekly volume chart ──────────────────────────────────────────────────
    final days = state.weeklyVolume();
    final mx   = days.isEmpty ? 1 : days.map((e) => e.value).reduce((a, b) => a > b ? a : b);
    final maxV = mx == 0 ? 1 : mx.toDouble();

    final volumeChart = GlassCard(
      pal: pal, intensity: gi,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Volume', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: pal.text)),
          Text('Last 7 days', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: pal.muted)),
          const SizedBox(height: 16),
          SizedBox(
            height: 180,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: days.map((e) => Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  VBar(value: e.value.toDouble(), maxValue: maxV,
                      color: kAccent, width: 34, maxH: 130),
                  const SizedBox(height: 6),
                  Text(e.key,
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: pal.text2)),
                  Text('${e.value}',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: pal.muted)),
                ],
              )).toList(),
            ),
          ),
        ],
      ),
    );

    // ── Type distribution ────────────────────────────────────────────────────
    final cat = [
      ('Speech', speech, kAccent),
      ('Music',  music,  kViolet),
      ('Noise',  noise,  kAccent2),
    ];
    final catTotal = speech + music + noise;

    Widget meter;
    if (catTotal > 0) {
      meter = Row(
        children: cat
            .where((c) => c.$2 > 0)
            .map((c) => Expanded(
                  flex: c.$2,
                  child: Container(
                    height: 16,
                    decoration: BoxDecoration(
                      color: c.$3,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                  ),
                ))
            .toList(),
      );
    } else {
      meter = Container(
        height: 16,
        decoration: BoxDecoration(
          color: pal.insetColor(),
          borderRadius: BorderRadius.circular(8),
        ),
      );
    }

    Widget legItem(String label, int cnt, Color color) => Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 8, height: 8,
            decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(4))),
        const SizedBox(width: 6),
        Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: pal.muted)),
        const SizedBox(width: 4),
        Text('$cnt', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)),
      ],
    );

    final distCard = GlassCard(
      pal: pal, intensity: gi,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('TYPE DISTRIBUTION',
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: pal.muted, letterSpacing: 1)),
          const SizedBox(height: 14),
          meter,
          const SizedBox(height: 16),
          Wrap(
            spacing: 18, runSpacing: 8,
            children: cat.map((c) => legItem(c.$1, c.$2, c.$3)).toList(),
          ),
        ],
      ),
    );

    // ── Language breakdown ───────────────────────────────────────────────────
    final langDist = stats['lang_dist'] as Map<String, int>;
    final langItems = langDist.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final top8 = langItems.take(8).toList();

    final langCard = GlassCard(
      pal: pal, intensity: gi,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Language Breakdown',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: pal.text)),
          const SizedBox(height: 14),
          if (top8.isNotEmpty)
            ...top8.map((e) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(children: [
                Text(e.key,
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: pal.text)),
                const Spacer(),
                CountChip(label: '${e.value}', color: kAccent),
              ]),
            ))
          else
            Text('No speech detected yet.',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: pal.muted)),
        ],
      ),
    );

    return Column(children: [
      statGrid,
      const SizedBox(height: 16),
      volumeChart,
      const SizedBox(height: 16),
      distCard,
      const SizedBox(height: 16),
      langCard,
    ]);
  }
}
