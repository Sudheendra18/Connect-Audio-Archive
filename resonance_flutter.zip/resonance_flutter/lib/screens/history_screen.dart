import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_widgets.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state   = context.watch<AppState>();
    final pal     = AppPalette(state.isDark);
    final gi      = state.glassIntensity;
    final records = state.history;

    final headerCol = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('${records.length} ANALYSES'.toUpperCase(),
          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
              color: pal.muted, letterSpacing: 1.2)),
        const SizedBox(height: 2),
        Text('History',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: pal.text)),
      ],
    );

    Widget body;
    if (records.isNotEmpty) {
      final items = <Widget>[];
      for (int i = 0; i < records.length; i++) {
        final r     = records[i];
        final atype = r.audioType;
        final sub   = [
          atype,
          if (r.language != null) r.language!,
          if (r.timestamp.isNotEmpty) r.timestamp,
        ].join(' · ');

        items.add(Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              IconBadge(icon: classIcon(atype), color: classColor(atype), size: 44, iconSize: 20),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r.filename,
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: pal.text),
                      overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text(sub,
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: pal.muted),
                      overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
              TypeChip(label: atype, color: classColor(atype)),
            ],
          ),
        ));

        if (i < records.length - 1) {
          items.add(Container(
            height: 1,
            margin: const EdgeInsets.only(left: 58),
            color: pal.dividerColor(),
          ));
        }
      }
      body = GlassCard(pal: pal, intensity: gi, padding: const EdgeInsets.all(14),
          child: Column(children: items));
    } else {
      body = GlassCard(
        pal: pal,
        intensity: gi,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 36),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.history_rounded, size: 36, color: pal.muted),
              const SizedBox(height: 12),
              Text('No history yet',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: pal.text),
                textAlign: TextAlign.center),
              const SizedBox(height: 4),
              Text('Analyze an audio file to see it here.',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: pal.muted),
                textAlign: TextAlign.center),
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        headerCol,
        const SizedBox(height: 16),
        body,
      ],
    );
  }
}
