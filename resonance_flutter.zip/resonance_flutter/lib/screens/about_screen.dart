import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_widgets.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final pal   = AppPalette(state.isDark);
    final gi    = state.glassIntensity;

    // Hero
    final hero = GlassCard(
      pal: pal, intensity: gi,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
      child: Column(
        children: [
          Container(
            width: 88, height: 88,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [kAccent, kViolet],
              ),
              boxShadow: [
                BoxShadow(color: kAccent.withOpacity(0.45), blurRadius: 26, offset: const Offset(0, 8)),
              ],
            ),
            child: const Icon(Icons.graphic_eq_rounded, color: kOnAcc, size: 38),
          ),
          const SizedBox(height: 16),
          Text('Audio Classifier',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: pal.text),
            textAlign: TextAlign.center),
          const SizedBox(height: 4),
          Text('v1.0.0  ·  Speech / Music / Noise',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: pal.muted),
            textAlign: TextAlign.center),
        ],
      ),
    );

    // SVM card
    final svm = GlassCard(
      pal: pal, intensity: gi, padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            IconBadge(icon: Icons.model_training_rounded, color: kAccent, size: 44, iconSize: 22),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('SVM Classifier',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: pal.text)),
                Text('Audio type detection',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: pal.muted)),
              ],
            ),
          ]),
          const SizedBox(height: 14),
          GlassDivider(pal: pal),
          const SizedBox(height: 12),
          ...[ 
            ('Purpose',  'Audio type classification'),
            ('Classes',  'Speech · Music · Noise'),
            ('Features', '57 (MFCC, Chroma, Spectral)'),
            ('Dataset',  'MUSAN'),
            ('Kernel',   'RBF'),
          ].map((r) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: SpecRow(pal: pal, keyText: r.$1, valueText: r.$2),
          )),
        ],
      ),
    );

    // Whisper card
    final whisper = GlassCard(
      pal: pal, intensity: gi, padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            IconBadge(icon: Icons.translate_rounded, color: kViolet, size: 44, iconSize: 22),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Whisper (OpenAI)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: pal.text)),
                Text('Language detection',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: pal.muted)),
              ],
            ),
          ]),
          const SizedBox(height: 14),
          GlassDivider(pal: pal),
          const SizedBox(height: 12),
          ...[ 
            ('Purpose',    'Language identification'),
            ('Model size', 'Small'),
            ('Languages',  '11 supported'),
            ('Method',     'Log-mel spectrogram'),
          ].map((r) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: SpecRow(pal: pal, keyText: r.$1, valueText: r.$2),
          )),
        ],
      ),
    );

    // Language chips
    final langs = GlassCard(
      pal: pal, intensity: gi,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('SUPPORTED LANGUAGES',
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                color: pal.muted, letterSpacing: 1.2)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: kLanguages.map((lang) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: pal.insetColor(),
                borderRadius: BorderRadius.circular(100),
                border: Border.all(color: pal.borderColor(0.7)),
              ),
              child: Text(lang,
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: pal.text2)),
            )).toList(),
          ),
        ],
      ),
    );

    // Footer
    final footer = GlassCard(
      pal: pal, intensity: gi,
      child: Row(children: [
        IconBadge(icon: Icons.code_rounded, color: kAccent2, size: 40, iconSize: 18),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Resonance  ·  Audio Intelligence',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: pal.text)),
            Text('Version 1.0.0  ·  Flutter',
              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500, color: pal.muted)),
          ],
        ),
      ]),
    );

    return Column(children: [
      hero,
      const SizedBox(height: 16),
      svm,
      const SizedBox(height: 16),
      whisper,
      const SizedBox(height: 16),
      langs,
      const SizedBox(height: 16),
      footer,
    ]);
  }
}
