import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_widgets.dart';

class SettingsScreen extends StatefulWidget {
  final VoidCallback onExport;
  final VoidCallback onClear;

  const SettingsScreen({super.key, required this.onExport, required this.onClear});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _urlCtrl;

  @override
  void initState() {
    super.initState();
    final state = context.read<AppState>();
    _urlCtrl = TextEditingController(text: state.backendUrl);
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final pal   = AppPalette(state.isDark);
    final gi    = state.glassIntensity;

    // ── Appearance ───────────────────────────────────────────────────────────
    final appearance = GlassCard(
      pal: pal, intensity: gi,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Appearance',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: pal.text)),
          const SizedBox(height: 4),
          SettingBlock(
            pal: pal,
            icon: Icons.palette_outlined, color: kViolet,
            title: 'Theme',
            subtitle: 'Switch between Light and Dark aurora glass',
            control: SizedBox(
              width: 150,
              child: SegmentedToggle(
                pal: pal,
                options: const ['Light', 'Dark'],
                active: state.isDark ? 'Dark' : 'Light',
                onSelect: (o) => state.setTheme(o == 'Dark'),
              ),
            ),
          ),
          GlassDivider(pal: pal),
          SettingBlock(
            pal: pal,
            icon: Icons.blur_on, color: kAccent2,
            title: 'Glass intensity',
            subtitle: 'Frost strength of all surfaces',
            control: SizedBox(
              width: 120,
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(activeTrackColor: kAccent),
                child: Slider(
                  min: 0.4, max: 1.0,
                  value: state.glassIntensity,
                  onChanged: (v) => state.setGlassIntensity(v),
                ),
              ),
            ),
          ),
        ],
      ),
    );

    // ── Backend URL ───────────────────────────────────────────────────────────
    final backend = GlassCard(
      pal: pal, intensity: gi,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Backend',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: pal.text)),
          const SizedBox(height: 4),
          SettingBlock(
            pal: pal,
            icon: Icons.cloud_outlined, color: kAccent,
            title: 'FastAPI URL',
            subtitle: 'Where your Python ML backend runs',
            control: const SizedBox.shrink(),
          ),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            decoration: BoxDecoration(
              color: pal.insetColor(),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: pal.borderColor(0.7)),
            ),
            child: TextField(
              controller: _urlCtrl,
              style: TextStyle(fontSize: 13, color: pal.text),
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'http://10.0.2.2:8000',
                hintStyle: TextStyle(color: pal.muted),
              ),
              onSubmitted: (v) => state.setBackendUrl(v.trim()),
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: PillButton(
              pal: pal, label: 'Save URL',
              icon: Icons.save_rounded, primary: true,
              onTap: () => state.setBackendUrl(_urlCtrl.text.trim()),
            ),
          ),
        ],
      ),
    );

    // ── Model info ────────────────────────────────────────────────────────────
    final model = GlassCard(
      pal: pal, intensity: gi,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Model',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: pal.text)),
          const SizedBox(height: 4),
          SettingBlock(
            pal: pal,
            icon: Icons.memory, color: kAccent,
            title: 'Pipeline',
            subtitle: 'SVM classifier + Whisper language ID',
            control: TypeChip(label: 'FastAPI', color: kMint),
          ),
          GlassDivider(pal: pal),
          SettingBlock(
            pal: pal,
            icon: Icons.category, color: kViolet,
            title: 'Classes',
            subtitle: 'Speech · Music · Noise',
            control: Text('3', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: pal.text)),
          ),
          GlassDivider(pal: pal),
          SettingBlock(
            pal: pal,
            icon: Icons.translate_rounded, color: kAccent2,
            title: 'Languages',
            subtitle: '${kLanguages.length} supported via Whisper',
            control: Text('${kLanguages.length}',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: pal.text)),
          ),
        ],
      ),
    );

    // ── Data ──────────────────────────────────────────────────────────────────
    final data = GlassCard(
      pal: pal, intensity: gi,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Data',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: pal.text)),
          const SizedBox(height: 4),
          SettingBlock(
            pal: pal,
            icon: Icons.download_rounded, color: kAccent,
            title: 'Export history',
            subtitle: 'Save all analyses to a text file',
            control: PillButton(
              pal: pal, label: 'Export',
              icon: Icons.download_rounded,
              onTap: widget.onExport,
            ),
          ),
          GlassDivider(pal: pal),
          SettingBlock(
            pal: pal,
            icon: Icons.delete_outline_rounded, color: kErr,
            title: 'Clear history',
            subtitle: 'Remove all ${state.history.length} stored analyses',
            control: PillButton(
              pal: pal, label: 'Clear',
              icon: Icons.delete_outline_rounded,
              onTap: widget.onClear,
            ),
          ),
        ],
      ),
    );

    return Column(children: [
      appearance,
      const SizedBox(height: 16),
      backend,
      const SizedBox(height: 16),
      model,
      const SizedBox(height: 16),
      data,
    ]);
  }
}
