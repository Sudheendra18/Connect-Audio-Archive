import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_widgets.dart';

class HomeScreen extends StatelessWidget {
  final VoidCallback onPickFile;
  const HomeScreen({super.key, required this.onPickFile});

  String _relativeTime(String ts) {
    if (ts.isEmpty) return '';
    try {
      final parts = ts.split(' ');
      final d = parts[0].split('-');
      final t = parts.length > 1 ? parts[1].split(':') : ['0', '0'];
      final when = DateTime(int.parse(d[0]), int.parse(d[1]), int.parse(d[2]),
          int.parse(t[0]), int.parse(t[1]));
      final delta = DateTime.now().difference(when);
      if (delta.inSeconds < 60)  return 'Just now';
      if (delta.inMinutes < 60)  return '${delta.inMinutes}m ago';
      if (delta.inHours < 24)    return '${delta.inHours}h ago';
      if (delta.inDays == 1)     return 'Yesterday';
      if (delta.inDays < 7)      return '${delta.inDays}d ago';
      return '${when.month}/${when.day}';
    } catch (_) { return ts; }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final pal   = AppPalette(state.isDark);
    final gi    = state.glassIntensity;

    if (state.analyzing || state.result != null) {
      return _ClassifyFlow(pal: pal, gi: gi, onPickFile: onPickFile);
    }

    final stats = state.stats();
    final total = stats['total'] as int;
    final greetingSub = total > 0
        ? "You've classified $total clip${total != 1 ? 's' : ''} so far."
        : "Choose an audio clip to run your first classification.";

    final hero = GlassCard(
      pal: pal, intensity: gi, radius: 26,
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 8, height: 8,
              decoration: BoxDecoration(color: kMint, borderRadius: BorderRadius.circular(8))),
          const SizedBox(width: 8),
          Text('SVM + Whisper ready',
              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: pal.text2)),
        ]),
        const SizedBox(height: 8),
        Text('Audio Classifier',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: pal.text)),
        Text(greetingSub,
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: pal.text2)),
        const SizedBox(height: 12),
        SizedBox(height: 72, child: Center(child: EqualizerBars(bars: 28, maxHeight: 60, seed: 11))),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: PillButton(pal: pal, label: 'Analyze Audio',
              icon: Icons.graphic_eq, primary: true, expand: true, onTap: onPickFile)),
          const SizedBox(width: 10),
          Expanded(child: PillButton(pal: pal, label: 'History',
              icon: Icons.history_rounded, expand: true,
              onTap: () => state.navigate('history'))),
        ]),
      ]),
    );

    final recentItems = state.history.take(5).toList();
    Widget recentBody;
    if (recentItems.isNotEmpty) {
      recentBody = Column(
        children: List.generate(recentItems.length * 2 - 1, (i) {
          if (i.isOdd) return Container(height: 1,
              margin: const EdgeInsets.only(left: 58), color: pal.dividerColor());
          final r = recentItems[i ~/ 2];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
            child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              IconBadge(icon: classIcon(r.audioType), color: classColor(r.audioType), size: 42, iconSize: 20),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(r.filename,
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: pal.text),
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Wrap(spacing: 8, children: [
                  TypeChip(label: r.audioType, color: classColor(r.audioType)),
                  if (r.language != null)
                    Text('· ${r.language}', style: TextStyle(fontSize: 12, color: pal.muted)),
                  if (r.duration != null)
                    Text('· ${r.duration}', style: TextStyle(fontSize: 12, color: pal.muted)),
                ]),
              ])),
              Text(_relativeTime(r.timestamp),
                  style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w500, color: pal.muted),
                  textAlign: TextAlign.right),
            ]),
          );
        }),
      );
    } else {
      recentBody = Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.graphic_eq, size: 30, color: pal.muted),
          const SizedBox(height: 10),
          Text('Nothing analyzed yet',
              style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600, color: pal.text)),
          Text('Drop an audio file to get started.',
              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500, color: pal.muted)),
        ]),
      );
    }

    final recentCard = GlassCard(pal: pal, intensity: gi,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text('Recent', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: pal.text)),
          const Spacer(),
          GestureDetector(
            onTap: () => state.navigate('history'),
            child: Row(children: [
              Text('See all', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: kAccent)),
              const Icon(Icons.arrow_forward_ios, size: 11, color: kAccent),
            ]),
          ),
        ]),
        const SizedBox(height: 6),
        recentBody,
      ]),
    );

    return Column(children: [hero, const SizedBox(height: 16), recentCard]);
  }
}

class _ClassifyFlow extends StatelessWidget {
  final AppPalette pal;
  final double gi;
  final VoidCallback onPickFile;

  const _ClassifyFlow({required this.pal, required this.gi, required this.onPickFile});

  @override
  Widget build(BuildContext context) {
    final state     = context.watch<AppState>();
    final hasFile   = state.fileName != null;
    final fileLabel = state.fileName ?? 'No clip selected';
    final eqSeed    = hasFile ? (state.fileName.hashCode & 255) : 3;

    final studioCenter = InsetCard(pal: pal, radius: 22, padding: const EdgeInsets.all(20),
      child: Column(children: [
        SizedBox(height: 100, child: Center(
          child: EqualizerBars(bars: 28, maxHeight: 90, seed: eqSeed, animated: state.analyzing),
        )),
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(state.analyzing ? Icons.sync_rounded : (hasFile ? Icons.audiotrack : Icons.upload_file),
              size: 15, color: state.analyzing || hasFile ? kAccent : pal.muted),
          const SizedBox(width: 8),
          Flexible(child: Text(
            state.analyzing ? 'Analyzing…' : fileLabel,
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                color: state.analyzing ? kAccent : (hasFile ? pal.text : pal.muted)),
            overflow: TextOverflow.ellipsis,
          )),
        ]),
      ]),
    );

    Widget actionRow;
    if (state.analyzing) {
      actionRow = Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        const SizedBox(width: 22, height: 22,
            child: CircularProgressIndicator(strokeWidth: 2.5, color: kAccent)),
        const SizedBox(width: 10),
        Text('Analyzing…', style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: pal.text2)),
      ]);
    } else {
      actionRow = Row(children: [
        Expanded(child: PillButton(pal: pal, label: 'Choose file',
            icon: Icons.folder_open, expand: true, onTap: onPickFile)),
        if (hasFile) ...[
          const SizedBox(width: 12),
          Expanded(child: PillButton(pal: pal, label: 'Re-analyze',
              icon: Icons.refresh, primary: true, expand: true, onTap: onPickFile)),
        ],
      ]);
    }

    final classifyCard = GlassCard(pal: pal, intensity: gi, padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          IconBadge(icon: Icons.multitrack_audio, color: kAccent, size: 40),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Audio Studio', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: pal.text)),
            Text('WAV · MP3 · OGG · FLAC · M4A',
                style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w500, color: pal.muted)),
          ]),
        ]),
        const SizedBox(height: 14),
        studioCenter,
        const SizedBox(height: 14),
        actionRow,
      ]),
    );

    if (state.result == null) return classifyCard;

    final label    = state.result!['audio_type'] as String? ?? 'Noise';
    final language = state.result!['language'] as String?;
    final hasLang  = language != null;

    Widget metaBlock(String lbl, String val) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(lbl, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w500, color: pal.muted)),
      const SizedBox(height: 3),
      Text(val, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: pal.text)),
    ]);

    final resultCard = GlassCard(pal: pal, intensity: gi, padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('DETECTED', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
            color: pal.muted, letterSpacing: 1.5)),
        const SizedBox(height: 14),
        Row(children: [
          IconBadge(icon: classIcon(label), color: classColor(label), size: 58, iconSize: 28),
          const SizedBox(width: 16),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: pal.text)),
            Text(hasLang ? 'Language: $language' : 'Not speech',
                style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: pal.text2)),
          ]),
        ]),
        const SizedBox(height: 20),
        SizedBox(height: 78, child: Center(
          child: EqualizerBars(bars: 30, maxHeight: 70, seed: label.hashCode & 255))),
        const SizedBox(height: 20),
        GlassDivider(pal: pal),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          metaBlock('Duration', state.duration ?? 'N/A'),
          metaBlock('Type', label),
          metaBlock('Language', hasLang ? language : '—'),
        ]),
      ]),
    );

    return Column(children: [classifyCard, const SizedBox(height: 16), resultCard]);
  }
}
