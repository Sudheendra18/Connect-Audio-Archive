import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';

import 'models/app_state.dart';
import 'services/api_service.dart';
import 'theme/app_theme.dart';
import 'widgets/glass_widgets.dart';
import 'screens/home_screen.dart';
import 'screens/history_screen.dart';
import 'screens/analytics_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/about_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.init();
  runApp(
    ChangeNotifierProvider.value(value: state, child: const ResonanceApp()),
  );
}

class ResonanceApp extends StatelessWidget {
  const ResonanceApp({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<AppState>().isDark;
    return MaterialApp(
      title: 'Resonance',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: kAccent,
        useMaterial3: true,
        brightness: isDark ? Brightness.dark : Brightness.light,
      ),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {

  static const _navItems = [
    ('home',      'Home',      Icons.home_rounded),
    ('history',   'History',   Icons.history_rounded),
    ('analytics', 'Analytics', Icons.insights_rounded),
    ('settings',  'Settings',  Icons.settings_rounded),
    ('about',     'About',     Icons.info_rounded),
  ];

  static const _titles = {
    'home':      ('Home',      'Your audio intelligence at a glance'),
    'history':   ('History',   'Every classification you\'ve run'),
    'analytics': ('Analytics', 'Trends across your audio history'),
    'settings':  ('Settings',  'Tune the workspace to your taste'),
    'about':     ('About',     'Models, stack & supported languages'),
  };

  Future<void> _pickAndAnalyze() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['wav', 'mp3', 'flac', 'ogg', 'm4a', 'aac'],
      dialogTitle: 'Choose an audio clip',
    );
    if (!mounted) return;
    if (result == null || result.files.isEmpty) return;
    final file = result.files.first;
    if (file.path == null) return;
    await _runAnalysis(file.path!, file.name);
  }

  Future<void> _runAnalysis(String path, String name) async {
    final state = context.read<AppState>();
    state.startAnalysis(path, name);
    try {
      final api = ApiService(state.backendUrl);
      final res = await api.analyzeAudio(path);
      // Duration comes back from server inside res if backend sends it
      final dur = res['duration'] as String?;
      state.setResult(res, dur);
    } catch (e) {
      state.setError(e.toString());
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Analysis failed: $e',
              style: const TextStyle(color: Colors.white)),
          backgroundColor: kErr,
        ));
      }
    }
  }

  Future<void> _doExport() async {
    final state   = context.read<AppState>();
    final content = state.exportText();
    try {
      final dir = await getApplicationDocumentsDirectory();
      final now = DateTime.now();
      final ts  = '${now.year}${_p2(now.month)}${_p2(now.day)}_'
                  '${_p2(now.hour)}${_p2(now.minute)}${_p2(now.second)}';
      final file = File('${dir.path}/audio_history_$ts.txt');
      await file.writeAsString(content);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Saved: ${file.path}',
              style: const TextStyle(color: Colors.white)),
          backgroundColor: kMint,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Export failed: $e',
              style: const TextStyle(color: Colors.white)),
          backgroundColor: kErr,
        ));
      }
    }
  }

  void _doClear() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear all history?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              context.read<AppState>().clearHistory();
              Navigator.pop(context);
            },
            style: TextButton.styleFrom(foregroundColor: kErr),
            child: const Text('Delete all'),
          ),
        ],
      ),
    );
  }

  String _p2(int v) => v.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final state  = context.watch<AppState>();
    final pal    = AppPalette(state.isDark);
    final screen = state.currentScreen;
    final titles = _titles[screen]!;

    Widget body;
    switch (screen) {
      case 'home':
        body = HomeScreen(key: const ValueKey('home'), onPickFile: _pickAndAnalyze);
      case 'history':
        body = const HistoryScreen();
      case 'analytics':
        body = const AnalyticsScreen();
      case 'settings':
        body = SettingsScreen(onExport: _doExport, onClear: _doClear);
      case 'about':
        body = const AboutScreen();
      default:
        body = const SizedBox.shrink();
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AuroraBackground(
        pal: pal,
        child: SafeArea(
          child: Column(children: [
            // Top bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(titles.$1,
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: pal.text)),
                      Text(titles.$2,
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: pal.text2)),
                    ]),
                  ),
                  GestureDetector(
                    onTap: () => state.setTheme(!state.isDark),
                    child: Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(pal.isDark ? 0.06 : 0.55),
                        borderRadius: BorderRadius.circular(100),
                        border: Border.all(color: pal.borderColor(1.0), width: 1.2),
                      ),
                      child: Icon(state.isDark ? Icons.dark_mode : Icons.light_mode,
                          size: 20, color: pal.text2),
                    ),
                  ),
                ],
              ),
            ),

            // Screen
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
                child: body,
              ),
            ),

            // Bottom nav
            _BottomNav(pal: pal, current: screen,
                onSelect: (k) => state.navigate(k)),
          ]),
        ),
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  final AppPalette pal;
  final String current;
  final void Function(String) onSelect;

  static const _items = AppShell._navItems;

  const _BottomNav({required this.pal, required this.current, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: pal.blur, sigmaY: pal.blur),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(pal.glass * 1.4),
            border: Border(top: BorderSide(color: pal.borderColor(1.0), width: 1.2)),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(pal.shadow * 0.7),
                  blurRadius: 24, offset: const Offset(0, -6)),
            ],
          ),
          child: Row(
            children: _items.map((item) {
              final (key, label, icon) = item;
              final active = current == key;
              return Expanded(
                child: GestureDetector(
                  onTap: () => onSelect(key),
                  behavior: HitTestBehavior.opaque,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(icon, size: 24, color: active ? kAccent : pal.muted),
                      const SizedBox(height: 3),
                      Text(label, style: TextStyle(
                        fontSize: 10,
                        fontWeight: active ? FontWeight.w600 : FontWeight.w500,
                        color: active ? kAccent : pal.muted,
                      )),
                    ]),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
