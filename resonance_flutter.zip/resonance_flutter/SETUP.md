# Resonance — Flutter Setup Guide

## Project Structure

```
resonance_flutter/
├── lib/
│   ├── main.dart                  # App entry point + shell + nav
│   ├── models/
│   │   └── app_state.dart         # State management (ChangeNotifier)
│   ├── services/
│   │   └── api_service.dart       # HTTP calls to FastAPI
│   ├── theme/
│   │   └── app_theme.dart         # Aurora Glass color system
│   ├── widgets/
│   │   └── glass_widgets.dart     # GlassCard, EqualizerBars, PillButton …
│   └── screens/
│       ├── home_screen.dart
│       ├── history_screen.dart
│       ├── analytics_screen.dart
│       ├── settings_screen.dart
│       └── about_screen.dart
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml    # Permissions + cleartext traffic
├── backend.py                     # FastAPI backend (runs on your PC)
└── pubspec.yaml
```

---

## Step 1 — Install prerequisites (one-time)

### 1a. Flutter SDK

1. Go to https://docs.flutter.dev/get-started/install/windows/mobile
2. Download Flutter SDK, extract to `C:\flutter`
3. Add `C:\flutter\bin` to your PATH
4. Run `flutter doctor` — fix any issues it reports

### 1b. Android Studio (for Android SDK + emulator)

1. Download from https://developer.android.com/studio
2. Install and open Android Studio
3. Go to **SDK Manager** → install:
   - Android SDK Platform 34
   - Android SDK Build-Tools 34
4. Create an AVD (emulator): **Device Manager** → **Create Virtual Device**
   - Pick Pixel 6, API 34

### 1c. VS Code extensions

Install these from the Extensions panel (Ctrl+Shift+X):
- **Flutter** (by Dart Code) — this also installs the Dart extension
- **Dart** (by Dart Code)

---

## Step 2 — Open project in VS Code

```bash
code resonance_flutter
```

VS Code will detect the Flutter project automatically.

Press **Ctrl+Shift+P** → `Flutter: Get Packages` (or run in terminal):
```bash
flutter pub get
```

---

## Step 3 — Run on emulator (for development)

1. Start your Android emulator from Android Studio Device Manager
2. In VS Code, bottom-right corner — select your emulator device
3. Press **F5** or run:

```bash
flutter run
```

The app will hot-reload on every save (**Ctrl+S**). Press **r** in the terminal to hot-reload manually.

---

## Step 4 — Run the FastAPI backend

Copy `backend.py` into your AudioLens folder (same folder as `audio_pipeline.py`):

```bash
cd path/to/AudioLens
pip install fastapi uvicorn python-multipart
uvicorn backend:app --host 0.0.0.0 --port 8000 --reload
```

### Connect the app to your backend

**Emulator** (default): `http://10.0.2.2:8000`
- This is the special Android emulator IP that maps to your PC's localhost
- Already set as default — no change needed

**Physical Android device**:
1. Connect your phone to the same WiFi as your PC
2. Find your PC's IP: `ipconfig` → look for IPv4 (e.g. `192.168.1.5`)
3. In the app → Settings → Backend URL → set `http://192.168.1.5:8000`

---

## Step 5 — Build release APK

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`

**Install on your phone:**
```bash
flutter install
```
Or copy the APK to your phone and tap to install (enable "Install unknown apps" in phone settings).

---

## Hot tips for VS Code

| Action | Shortcut |
|--------|----------|
| Run app | F5 |
| Hot reload | Ctrl+S (auto) or `r` in terminal |
| Hot restart | Shift+R in terminal |
| Open emulator | Ctrl+Shift+P → "Flutter: Launch Emulator" |
| Flutter widget inspector | Run → click the Flutter icon in debug toolbar |

---

## Troubleshooting

**`flutter doctor` shows issues:**
- Android SDK missing → install Android Studio
- Android licenses → run `flutter doctor --android-licenses`

**App can't reach backend:**
- Check `uvicorn` is running: `http://localhost:8000/health` should return `{"status":"ok"}`
- Emulator: make sure URL is `http://10.0.2.2:8000` (not localhost)
- Physical device: make sure phone and PC are on same WiFi

**File picker doesn't work on Android 13+:**
- Grant "Files and media" permission when prompted
- If denied: Settings → Apps → Resonance → Permissions → Files

**Build fails with Gradle errors:**
- Run `flutter clean` then `flutter pub get` then retry
