"""Profanity detection subpackage."""

from .profanity_detector import detect_profanity

__all__ = ["detect_profanity"]
