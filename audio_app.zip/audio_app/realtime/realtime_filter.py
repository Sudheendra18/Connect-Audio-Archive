"""
realtime_filter.py
===================
Real-time profanity filter with a fixed playback delay ("broadcast delay").

Audio flow:  mic -> ring buffer -> [analysis thread checks profanity] -> speaker (delayed)

Profanity checking (Whisper translate + toxicity classifier) takes real
wall-clock time to run, so we can't know whether a piece of audio is safe
*before* it would normally be played. Instead every second of audio is held
back by PLAYBACK_DELAY_SECONDS before it reaches the speaker. That gives the
analysis thread a head start: by the time a segment is due to play, its
verdict (safe / muted) is already known.

Swap the input source later
----------------------------
capture_loop() currently pulls PCM from the microphone via sounddevice.
To feed this from an Auracast BIS receiver instead, replace capture_loop()
with a reader that pulls float32 PCM frames from wherever that pipeline
delivers them (e.g. the stdout of `bumble-auracast receive --output stdout`)
and append them to `buffer` the same way capture_loop() does. Nothing else
in this file needs to change.

Requirements
------------
    pip install sounddevice numpy
    # Linux also needs the system PortAudio library:
    sudo apt install libportaudio2

Usage
-----
    python realtime/realtime_filter.py
    Ctrl+C to stop.
"""

import sys
import os
import time
import threading
import collections
import numpy as np
import sounddevice as sd

# ── Make the parent folder (audio_app root) importable ───────────────────────
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from audio_pipeline import translate_array_to_english, check_profanity


# ═════════════════════════════════════════════════════════════════════════════
# CONFIG — tune these for your hardware / model speed
# ═════════════════════════════════════════════════════════════════════════════

SAMPLE_RATE             = 16000   # Whisper wants 16 kHz mono
CHANNELS                = 1
SEGMENT_SECONDS         = 1.0     # size of one capture chunk
WINDOW_SECONDS          = 4.0     # audio handed to Whisper per analysis pass
HOP_SECONDS             = 2.0     # how often a new analysis pass starts
PLAYBACK_DELAY_SECONDS  = 8.0     # must be >= time to capture + analyze one window

# If PLAYBACK_DELAY_SECONDS is too short for your machine, segments will
# routinely reach the speaker before they've been analyzed, and — because
# this filter fails CLOSED — will be muted just for being unverified.
# If you see a lot of unexpected muting, raise this value, or switch to a
# smaller/faster Whisper model ("base"/"tiny") or a GPU.

SEGMENT_SAMPLES = int(SEGMENT_SECONDS * SAMPLE_RATE)


# ═════════════════════════════════════════════════════════════════════════════
# Shared state
# ═════════════════════════════════════════════════════════════════════════════

class Segment:
    """One SEGMENT_SECONDS chunk of captured audio."""
    __slots__ = ("seq", "samples", "muted", "analyzed", "captured_at")

    def __init__(self, seq, samples):
        self.seq         = seq
        self.samples     = samples   # float32 numpy array, mono
        self.muted       = False     # set True if flagged as profane
        self.analyzed    = False     # set True once a verdict is known
        self.captured_at = time.time()


buffer      = collections.deque()   # Segment objects, oldest first
buffer_lock = threading.Lock()
next_seq    = 0
stop_event  = threading.Event()


# ═════════════════════════════════════════════════════════════════════════════
# Capture — mic -> buffer
# ═════════════════════════════════════════════════════════════════════════════

def capture_loop():
    """
    Pull audio from the microphone in SEGMENT_SECONDS chunks and append
    each chunk to `buffer`. Swap this function's body to read from a
    different PCM source later (see module docstring).
    """
    global next_seq

    def _callback(indata, frames, time_info, status):
        global next_seq
        if status:
            print(f"  [capture] {status}", file=sys.stderr)
        mono = indata[:, 0].copy() if indata.ndim > 1 else indata.copy()
        with buffer_lock:
            buffer.append(Segment(next_seq, mono))
            next_seq += 1

    with sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        blocksize=SEGMENT_SAMPLES,
        dtype="float32",
        callback=_callback,
    ):
        while not stop_event.is_set():
            time.sleep(0.1)


# ═════════════════════════════════════════════════════════════════════════════
# Analysis — sliding window -> profanity verdict
# ═════════════════════════════════════════════════════════════════════════════

def analysis_loop():
    """
    Every HOP_SECONDS, gather the oldest still-unanalyzed WINDOW_SECONDS of
    audio, run it through the pipeline, and tag every segment in that
    window with the verdict.
    """
    window_segments_needed = max(1, int(WINDOW_SECONDS / SEGMENT_SECONDS))

    while not stop_event.is_set():
        time.sleep(HOP_SECONDS)

        with buffer_lock:
            unanalyzed = [s for s in buffer if not s.analyzed]
            window = unanalyzed[:window_segments_needed]

        if len(window) < window_segments_needed:
            continue  # not enough fresh audio yet — try again next hop

        audio = np.concatenate([s.samples for s in window])

        try:
            translated = translate_array_to_english(audio, SAMPLE_RATE)
            result = check_profanity(translated)
            is_profane = result["is_profane"]
        except Exception as ex:
            print(f"  [analysis] error: {ex} — muting window as a precaution", file=sys.stderr)
            translated = ""
            is_profane = True  # fail closed: mute rather than risk playing unverified audio

        with buffer_lock:
            for s in window:
                s.muted = is_profane
                s.analyzed = True

        if is_profane:
            print(f'  \u26a0 profanity detected — muting segments '
                  f'{window[0].seq}-{window[-1].seq}  ("{translated[:60]}")')


# ═════════════════════════════════════════════════════════════════════════════
# Playback — delayed buffer -> speaker
# ═════════════════════════════════════════════════════════════════════════════

def playback_loop():
    """
    Pop segments off the front of the buffer once they're older than
    PLAYBACK_DELAY_SECONDS and play them — silenced if muted, or if a
    verdict never arrived in time (fail closed).
    """
    with sd.OutputStream(
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        dtype="float32",
    ) as out:
        while not stop_event.is_set():
            ready = None
            with buffer_lock:
                if buffer and (time.time() - buffer[0].captured_at) >= PLAYBACK_DELAY_SECONDS:
                    ready = buffer.popleft()

            if ready is None:
                time.sleep(0.02)
                continue

            if ready.muted or not ready.analyzed:
                out.write(np.zeros_like(ready.samples))
            else:
                out.write(ready.samples)


# ═════════════════════════════════════════════════════════════════════════════
# Entry point
# ═════════════════════════════════════════════════════════════════════════════

def main():
    print(f"  Buffering {PLAYBACK_DELAY_SECONDS:.0f}s before playback so profanity "
          f"checks can complete.")
    print("  Speak into the mic — Ctrl+C to stop.\n")

    threads = [
        threading.Thread(target=capture_loop,  daemon=True),
        threading.Thread(target=analysis_loop, daemon=True),
        threading.Thread(target=playback_loop, daemon=True),
    ]
    for t in threads:
        t.start()

    try:
        while True:
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\n  Stopping…")
        stop_event.set()
        for t in threads:
            t.join(timeout=2)


if __name__ == "__main__":
    main()
