import sys
import os
import joblib
import whisper
import librosa
import numpy as np
import pandas as pd

# ── Profanity detector (lives in profanity/ subfolder) ───────────────────────
# Import the *package* (`profanity/__init__.py`), not the submodule directly.
# The package exposes `detect_profanity` lazily via __getattr__, so merely
# importing it here does NOT load the heavy toxicity transformer model.
#
# The previous version did `sys.path.insert(..., "profanity")` and then
# `from profanity_detector import detect_profanity`, which bypasses that
# lazy loader entirely and runs profanity_detector.py's top-level code
# (which calls `transformers.pipeline(...)`, loading a full multilingual
# toxicity model) immediately at import time. Since main.py imports
# audio_pipeline before showing any UI, that model load — on top of the
# SVM/scaler/Whisper loads right below — was blocking app startup and
# everything else (including audio playback) behind it, even though
# profanity checking is only used on-demand from the "Check Content
# Safety" button. Importing the package instead defers that cost to the
# first real call to check_profanity().
_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
try:
    import profanity as _profanity_pkg
    _PROFANITY_READY = True
    _PROFANITY_ERR   = None
except Exception as _pe:
    _PROFANITY_READY = False
    _PROFANITY_ERR   = str(_pe)

# ── Paths ─────────────────────────────────────────────────────────────────────
# svm_model.pkl and scaler.pkl now live in the models/ subfolder
MODEL_PATH  = os.path.join(os.path.dirname(__file__), "models", "svm_model.pkl")
SCALER_PATH = os.path.join(os.path.dirname(__file__), "models", "scaler.pkl")

# ── Label maps ────────────────────────────────────────────────────────────────
LABELS = {
    0: "Music",
    1: "Noise",
    2: "Speech",
}

LANG_MAP = {
    "en": "English",
    "fr": "French",
    "de": "German",
    "hi": "Hindi",
    "kn": "Kannada",
    "ko": "Korean",
    "ml": "Malayalam",
    "es": "Spanish",
    "ta": "Tamil",
    "te": "Telugu",
    "ur": "Urdu",
}

SR       = 16000
DURATION = 10

# ── Load models once at import time ──────────────────────────────────────────
print("Loading SVM...")
svm = joblib.load(MODEL_PATH)

print("Loading Scaler...")
scaler = joblib.load(SCALER_PATH)

print("Loading Whisper Small...")
whisper_model = whisper.load_model("small")

print("All models loaded.\n")


# ═════════════════════════════════════════════════════════════════════════════
# FEATURE EXTRACTION
# ═════════════════════════════════════════════════════════════════════════════

def extract_features(audio: np.ndarray, sr: int) -> list:
    """Extract 57 Librosa features used by the SVM classifier."""
    features = []

    mfcc = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=20)
    features.extend(np.mean(mfcc, axis=1))   # 20 values
    features.extend(np.std(mfcc,  axis=1))   # 20 values

    chroma = librosa.feature.chroma_stft(y=audio, sr=sr)
    features.extend(np.mean(chroma, axis=1)) # 12 values

    features.append(np.mean(librosa.feature.spectral_centroid(y=audio, sr=sr)))
    features.append(np.mean(librosa.feature.spectral_bandwidth(y=audio, sr=sr)))
    features.append(np.mean(librosa.feature.spectral_rolloff(y=audio, sr=sr)))
    features.append(np.mean(librosa.feature.zero_crossing_rate(audio)))
    features.append(np.mean(librosa.feature.rms(y=audio)))  # 5 values  → total 57

    return features


# ═════════════════════════════════════════════════════════════════════════════
# SVM CLASSIFICATION
# ═════════════════════════════════════════════════════════════════════════════

def classify_audio(audio_path: str) -> str:
    """Return 'Music', 'Noise', or 'Speech'."""
    audio, _ = librosa.load(audio_path, sr=SR, mono=True, duration=DURATION)

    target_length = SR * DURATION
    if len(audio) < target_length:
        audio = np.pad(audio, (0, target_length - len(audio)))

    features = extract_features(audio, SR)
    df = pd.DataFrame([features], columns=[f"f{i+1}" for i in range(57)])
    scaled = scaler.transform(df)

    return LABELS[svm.predict(scaled)[0]]


# ═════════════════════════════════════════════════════════════════════════════
# WHISPER — LANGUAGE DETECTION
# ═════════════════════════════════════════════════════════════════════════════

def detect_language(audio_path: str) -> str:
    """Detect the spoken language and return its English name."""
    audio = whisper.pad_or_trim(whisper.load_audio(audio_path))
    mel   = whisper.log_mel_spectrogram(audio).to(whisper_model.device)
    _, probs = whisper_model.detect_language(mel)
    code = max(probs, key=probs.get)
    return LANG_MAP.get(code, code)


# ═════════════════════════════════════════════════════════════════════════════
# WHISPER — TRANSCRIPTION  (original language)
# ═════════════════════════════════════════════════════════════════════════════

def transcribe_audio(audio_path: str) -> str:
    """
    Transcribe the audio file in its original language using Whisper.
    Returns the full transcript as a single string.
    """
    result = whisper_model.transcribe(
        audio_path,
        task="transcribe",   # keep original language
        verbose=False,
    )
    return result["text"].strip()


# ═════════════════════════════════════════════════════════════════════════════
# WHISPER — TRANSLATION TO ENGLISH
# ═════════════════════════════════════════════════════════════════════════════

def translate_to_english(audio_path: str) -> str:
    """
    Translate the audio file to English using Whisper's built-in translation.
    Works for all 99 languages Whisper supports.
    If the source is already English, the output equals the transcription.
    Returns the translated text as a single string.
    """
    result = whisper_model.transcribe(
        audio_path,
        task="translate",    # always outputs English
        verbose=False,
    )
    return result["text"].strip()


def translate_array_to_english(audio_array: np.ndarray, sr: int = SR) -> str:
    """
    Same as translate_to_english(), but takes an in-memory float32 mono
    numpy array instead of a file path. Used for real-time / streaming
    audio where there's no file on disk (see realtime/realtime_filter.py).

    ``audio_array`` must already be mono float32 sampled at ``sr`` Hz.
    Whisper expects 16 kHz — capture your stream at SR directly to avoid
    a resampling step here.
    """
    if sr != SR:
        raise ValueError(f"translate_array_to_english expects {SR} Hz audio, got {sr} Hz")

    result = whisper_model.transcribe(
        audio_array,
        task="translate",
        verbose=False,
    )
    return result["text"].strip()


# ═════════════════════════════════════════════════════════════════════════════
# PROFANITY DETECTION
# ═════════════════════════════════════════════════════════════════════════════

def check_profanity(english_text: str) -> dict:
    """
    Run profanity detection on English text.
    Returns the profanity_detector result dict, or a safe fallback if the
    profanity module failed to load.
    """
    if not _PROFANITY_READY:
        return {
            "is_profane":  False,
            "category":    "unavailable",
            "score":       0.0,
            "all_scores":  {},
            "error":       _PROFANITY_ERR,
        }

    if not english_text or not english_text.strip():
        return {
            "is_profane": False,
            "category":   "Safe",
            "score":      0.0,
            "all_scores": {},
        }

    try:
        return _profanity_pkg.detect_profanity(english_text)
    except Exception as e:
        # First real use is exactly when the lazy model load can fail
        # (missing transformers/torch, no internet for the model download,
        # etc.) — report it instead of crashing the analysis.
        return {
            "is_profane": False,
            "category":   "unavailable",
            "score":      0.0,
            "all_scores": {},
            "error":      str(e),
        }


# ═════════════════════════════════════════════════════════════════════════════
# MAIN PIPELINE
# ═════════════════════════════════════════════════════════════════════════════

def analyze_audio(audio_path: str) -> dict:
    """
    Fast pipeline — runs on every file upload:
      1. Classify audio type  (SVM)
      2. If Speech or Music: detect language (Whisper language-detect only)

    Transcription, translation, and profanity detection are NOT run here.
    They are triggered on-demand from the UI when the user taps
    "Check Content Safety".

    Returns
    -------
    dict with keys:
        audio_type : "Speech" | "Music" | "Noise"
        language   : detected language name, or "Not Applicable"
    """
    audio_type = classify_audio(audio_path)

    result = {
        "audio_type": audio_type,
        "language":   "Not Applicable",
    }

    if audio_type in ("Speech", "Music"):
        result["language"] = detect_language(audio_path)

    return result
