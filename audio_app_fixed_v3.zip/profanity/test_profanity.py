"""
test_profanity.py
=================
Two modes:

  1. Text mode (default)
     Run the profanity detector directly on sentences you type.

  2. Audio mode
     Pass an audio file path as a command-line argument.
     The full pipeline runs: classify → transcribe → translate → profanity check.

Usage
-----
  # Text mode
  python profanity/test_profanity.py

  # Audio mode  (path relative to audio_app root)
  python profanity/test_profanity.py path/to/audio.wav
"""

import sys
import os

# ── Make the parent folder (audio_app root) importable ───────────────────────
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "profanity"))

from profanity_detector import detect_profanity


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _print_result(result: dict, header: str = "") -> None:
    print()
    if header:
        print(f"  {header}")
    print("  " + "─" * 42)
    print(f"  Profanity  : {'⚠  YES' if result['is_profane'] else '✓  NO'}")
    print(f"  Category   : {result['category']}")
    print(f"  Score      : {result['score']}%")
    if result.get("error"):
        print(f"  ⚠ Error    : {result['error']}")
    print()
    print("  All Scores:")
    for label, score in result.get("all_scores", {}).items():
        bar   = "█" * int(score * 20)
        print(f"    {label:22} {score:.4f}  {bar}")
    print("  " + "─" * 42)
    print()


# ─────────────────────────────────────────────────────────────────────────────
# Mode 1 — Text mode
# ─────────────────────────────────────────────────────────────────────────────

def run_text_mode() -> None:
    print()
    print("╔══════════════════════════════════════════╗")
    print("║       Profanity Detection — Text Mode    ║")
    print("╚══════════════════════════════════════════╝")
    print("  Type a sentence and press Enter.")
    print("  Enter  q  to quit.\n")

    while True:
        try:
            text = input("  > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Bye!")
            break

        if text.lower() == "q":
            print("  Bye!")
            break

        if not text:
            continue

        result = detect_profanity(text)
        _print_result(result, header=f'Text: "{text[:60]}"')


# ─────────────────────────────────────────────────────────────────────────────
# Mode 2 — Audio mode
# ─────────────────────────────────────────────────────────────────────────────

def run_audio_mode(audio_path: str) -> None:
    print()
    print("╔══════════════════════════════════════════╗")
    print("║       Profanity Detection — Audio Mode   ║")
    print("╚══════════════════════════════════════════╝")

    if not os.path.exists(audio_path):
        print(f"\n  ✗ File not found: {audio_path}")
        sys.exit(1)

    print(f"\n  File : {os.path.basename(audio_path)}")
    print("  Running full pipeline (classify → transcribe → translate → profanity)…\n")

    # Import here so the heavy models only load in audio mode
    from audio_pipeline import analyze_audio

    result = analyze_audio(audio_path)

    print(f"  Audio Type     : {result['audio_type']}")
    print(f"  Language       : {result['language']}")
    print()

    if result["transcription"]:
        print(f"  Transcription  : {result['transcription']}")
    else:
        print("  Transcription  : (none — not speech or music)")

    if result["translation"]:
        print(f"  Translation    : {result['translation']}")
    else:
        print("  Translation    : (none)")

    if result["profanity"] is not None:
        _print_result(result["profanity"], header="Profanity Analysis (on English translation):")
    else:
        print("\n  Profanity check skipped (audio type is not Speech).\n")


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) > 1:
        run_audio_mode(sys.argv[1])
    else:
        run_text_mode()
