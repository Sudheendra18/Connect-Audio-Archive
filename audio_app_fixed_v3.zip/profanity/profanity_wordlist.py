"""
profanity_wordlist.py
=====================
A fast, word-precise bleep list — the complement to the ML toxicity model.

Why two mechanisms:

  * The ML model (`profanity_detector.py`) judges whether a *sentence* is toxic.
    Great for nuance and context, but it gives a sentence-level verdict, so the
    best it can localize is "beep this whole window".

  * This wordlist matches individual tokens. When Whisper gives us word
    timestamps, a wordlist hit tells us EXACTLY which word (and therefore which
    milliseconds) to beep — so we bleep just the swear, not the surrounding 3-4
    seconds. It's also instant (a set lookup), which keeps latency down.

The engine uses BOTH: wordlist for precise bleeping, model as a safety net for
obscured/contextual profanity the wordlist misses (then it beeps the window).

Coverage
--------
The in-repo list below is a compact, functional core (mostly English). For
production, drop full word files into a folder and pass `--wordlist-dir`:
one UTF-8 file per language code (`en.txt`, `te.txt`, `hi.txt`, `ta.txt`, …),
one word/phrase per line, '#' for comments. The community-standard
"List of Dirty, Naughty, Obscene, and Otherwise Bad Words" (LDNOOBW) ships
exactly this format for dozens of languages and slots straight in.

Normalization folds common leetspeak/obfuscation (f4ck, sh1t, @ss, b00b) so
trivial evasions still match. Matching is whole-token by default to avoid the
"Scunthorpe problem" (false hits on innocent substrings); a small hard core is
also matched as a substring because it has no benign embedding.
"""

from __future__ import annotations

import os
import re

# ── Core list (compact; extend via --wordlist-dir for real deployments) ──────
# Kept deliberately short and to common profanity; this is a content filter,
# so the target words must be present for it to do its job.
_CORE_EN = {
    "fuck", "fucker", "fucking", "motherfucker", "shit", "bullshit", "bitch",
    "bastard", "asshole", "dickhead", "cunt", "prick", "slut", "whore",
    "wanker", "bollocks", "dick", "cock", "pussy", "nigger", "nigga", "faggot",
    "retard", "twat", "jerkoff",
}

# Words with no benign embedding -> safe to catch as substrings too
_HARD_CORE = {"fuck", "shit", "cunt", "nigger", "faggot", "motherfuck"}

# Multi-token phrases (checked on the normalized token stream)
_PHRASES = {
    ("son", "of", "a", "bitch"),
    ("piece", "of", "shit"),
}

_LEET = str.maketrans({
    "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t",
    "8": "b", "9": "g", "@": "a", "$": "s", "!": "i", "|": "i",
})


def normalize(token: str) -> str:
    """Lowercase, fold leetspeak, strip non-letters, collapse 3+ repeats."""
    t = token.lower().translate(_LEET)
    t = re.sub(r"[^a-z]", "", t)
    t = re.sub(r"(.)\1{2,}", r"\1\1", t)   # fuuuuck -> fuuck -> (still matches core via substring)
    return t


class Wordlist:
    def __init__(self, extra_dir: str | None = None):
        self.words: set[str] = set(_CORE_EN)
        self.hard_core: set[str] = set(_HARD_CORE)
        self.phrases: set[tuple[str, ...]] = set(_PHRASES)
        self._norm_words = {normalize(w) for w in self.words}
        self._norm_hard = {normalize(w) for w in self.hard_core}
        if extra_dir:
            self.load_dir(extra_dir)

    def load_dir(self, path: str) -> None:
        if not os.path.isdir(path):
            print(f"[wordlist] dir not found, ignoring: {path}")
            return
        added = 0
        for fn in os.listdir(path):
            if not fn.lower().endswith(".txt"):
                continue
            with open(os.path.join(path, fn), encoding="utf-8") as f:
                for line in f:
                    w = line.strip()
                    if not w or w.startswith("#"):
                        continue
                    parts = w.split()
                    if len(parts) == 1:
                        self.words.add(w.lower())
                        self._norm_words.add(normalize(w))
                        added += 1
                    else:
                        self.phrases.add(tuple(normalize(p) for p in parts))
                        added += 1
        print(f"[wordlist] loaded {added} extra entries from {path}")

    def is_profane_token(self, token: str) -> bool:
        n = normalize(token)
        if not n:
            return False
        if n in self._norm_words:
            return True
        # substring check only against the hard core (no benign embeddings)
        return any(h in n for h in self._norm_hard)

    def match_words(self, words) -> list:
        """
        Given a list of objects with .text/.start/.end (transcription.Word),
        return the sublist whose tokens are profane, including any that form a
        banned multi-token phrase.
        """
        flagged = []
        norms = [normalize(w.text) for w in words]

        # single tokens
        for w, n in zip(words, norms):
            if n and (n in self._norm_words or any(h in n for h in self._norm_hard)):
                flagged.append(w)

        # phrases -> flag every word in a matching run
        for phrase in self.phrases:
            L = len(phrase)
            for i in range(len(norms) - L + 1):
                if tuple(norms[i:i + L]) == phrase:
                    for w in words[i:i + L]:
                        if w not in flagged:
                            flagged.append(w)
        return flagged
