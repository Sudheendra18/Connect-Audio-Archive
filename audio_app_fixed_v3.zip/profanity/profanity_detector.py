from transformers import pipeline

print("Loading Profanity Detection Model...")

classifier = pipeline(
    task="text-classification",
    model="unitary/multilingual-toxic-xlm-roberta",
    top_k=None,
)

print("Profanity Model Loaded!\n")

OFFENSIVE_LABELS = [
    "toxic",
    "obscene",
    "insult",
    "threat",
    "identity_attack",
    "sexual_explicit",
]

PROFANITY_THRESHOLD = 0.70  # 70 % confidence → flagged


def detect_profanity(text: str) -> dict:
    """
    Analyse ``text`` for toxic content.

    Parameters
    ----------
    text : str
        The English (or multilingual) text to analyse.

    Returns
    -------
    dict
        is_profane  : bool   — True when any offensive label ≥ threshold
        category    : str    — highest-scoring offensive label, or "Safe"
        score       : float  — that label's score as a percentage (0–100)
        all_scores  : dict   — {label: score} for every label the model returns
    """
    if not text or not text.strip():
        return {
            "is_profane": False,
            "category":   "Safe",
            "score":      0.0,
            "all_scores": {},
        }

    predictions = classifier(text)[0]

    all_scores = {item["label"]: round(item["score"], 4) for item in predictions}

    max_score = 0.0
    category  = "Safe"

    for label in OFFENSIVE_LABELS:
        if label in all_scores and all_scores[label] > max_score:
            max_score = all_scores[label]
            category  = label

    return {
        "is_profane": max_score >= PROFANITY_THRESHOLD,
        "category":   category,
        "score":      round(max_score * 100, 2),
        "all_scores": all_scores,
    }


def score_texts(texts: list) -> list:
    """
    Batched toxicity scoring: one classifier call over many short texts.

    Returns, per input text, the highest offensive-label probability (0..1).
    Used by the realtime filter to LOCALIZE a window-level toxicity hit down
    to the individual word(s) that carry it — so only those words get beeped
    rather than the entire block. Empty/blank texts score 0.0 without ever
    touching the model.
    """
    idx_map = [i for i, t in enumerate(texts) if t and t.strip()]
    scores = [0.0] * len(texts)
    if not idx_map:
        return scores
    predictions = classifier([texts[i].strip() for i in idx_map])
    for i, preds in zip(idx_map, predictions):
        best = 0.0
        for item in preds:
            if item["label"] in OFFENSIVE_LABELS and item["score"] > best:
                best = float(item["score"])
        scores[i] = best
    return scores
