"""
livetest.py
===========
Threaded LIVE-engine smoke test — no sound hardware, no Whisper needed.

Drives RealtimeEngine end-to-end with a fake realtime source and a fake
jitter-buffered sink that consumes at (accelerated) real time. Asserts:

  * ZERO audio loss: played sample count == captured sample count
  * the playback cushion actually builds (verdicts queue early)
  * beeps are word-precise, not whole-block
  * no segment is ever forced through unverified

Run:  python realtime/livetest.py
"""
import os, sys, time, threading
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for p in (HERE, ROOT, os.path.join(ROOT, "profanity")):
    sys.path.insert(0, p)

from config import parse_args
import realtime_filter


class FakeRealtimeSource:
    """Yields 1s tone segments at (accelerated) real time."""
    def __init__(self, cfg, seconds=10, speedup=4.0):
        self.cfg = cfg; self.seconds = seconds; self.speedup = speedup

    def __iter__(self):
        sr, n = self.cfg.sample_rate, self.cfg.segment_samples
        for i in range(self.seconds):
            t = (np.arange(n) + i * n) / sr
            time.sleep(self.cfg.segment / self.speedup)
            yield (0.25 * np.sin(2 * np.pi * 200 * t)).astype(np.float32)


class FakeJitterSink:
    """Consumes at accelerated real time; reports queued_seconds."""
    def __init__(self, sr, speedup=4.0):
        self.sr = sr; self.count = 0; self.lock = threading.Lock()
        self.chunks = []; self.max_cushion = 0.0
        self._stop = False
        self._t = threading.Thread(target=self._drain, args=(speedup,), daemon=True)
        self._t.start()

    def _drain(self, speedup):
        per_tick = int(self.sr * 0.05 * speedup)
        while not self._stop:
            time.sleep(0.05)
            with self.lock:
                self.count = max(0, self.count - per_tick)

    def write(self, samples):
        with self.lock:
            self.count += len(samples)
            self.chunks.append(samples.copy())
            self.max_cushion = max(self.max_cushion, self.count / self.sr)

    def queued_seconds(self):
        with self.lock:
            return self.count / self.sr

    def close(self):
        self._stop = True


def main():
    # speed the clock up 4x by shrinking delay-sensitive params accordingly
    cfg = parse_args([
        "--backend", "mock", "--vad", "off", "--force-language", "en",
        "--segment", "1", "--block", "2", "--context", "0", "--lookahead", "0",
        "--delay", "1.0", "--no-model-net", "--stats-interval", "0",
        "--max-unverified-wait", "2.0",
    ])
    cfg._extra["mock_bad_token"] = "shit"  # must be in the wordlist to beep
    analyzer = realtime_filter.build(cfg)
    engine = realtime_filter.RealtimeEngine(cfg, analyzer)
    source = FakeRealtimeSource(cfg, seconds=10, speedup=4.0)
    sink = FakeJitterSink(cfg.sample_rate, speedup=4.0)
    engine.run(source, sink)

    total = sum(len(c) for c in sink.chunks)
    expect = 10 * cfg.segment_samples
    print(f"played={total} expected={expect} "
          f"forced={engine._forced_unverified} unverified={engine._unverified} "
          f"beeped={engine._beeped_samples / cfg.sample_rate:.2f}s "
          f"max_cushion={sink.max_cushion:.2f}s")
    assert total == expect, "AUDIO LOSS: played sample count != captured"
    assert engine._forced_unverified == 0, "forced unverified occurred"
    assert engine._beeped_samples > 0, "no beeps applied"
    # word-precision: mock flags one ~0.35s word per 2s block -> beeped
    # fraction must be far below whole-block
    frac = engine._beeped_samples / total
    assert frac < 0.5, f"beeped fraction too high ({frac:.2f}) — not word-precise"
    print("LIVE SMOKE TEST: OK")


if __name__ == "__main__":
    main()
