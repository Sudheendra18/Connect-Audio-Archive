"""Real-time profanity filter package."""
