"""
audio_io.py
===========
Everything that touches raw audio bytes: the censor beep, the pluggable input
sources, the speaker sink, and small wav read/write helpers.

Input sources (the Auracast hook lives here)
--------------------------------------------
Every source is an iterator yielding float32 mono chunks of `segment_samples`.
Swapping the capture path for an Auracast BIS receiver later means adding one
class here (read PCM frames from `bumble-auracast receive --output stdout`) —
nothing in the engine changes. `StdinPCMSource` already does exactly this for
any process that writes raw float32 PCM to stdout:

    bumble-auracast receive --output stdout | \
        python -m realtime.realtime_filter --input stdin
"""

from __future__ import annotations

import sys
import math
import struct
import time
import wave
import threading
import collections
import numpy as np


# ═════════════════════════════════════════════════════════════════════════════
# Censor beep
# ═════════════════════════════════════════════════════════════════════════════

def make_beep(n_samples: int, sample_rate: int, freq: float = 1000.0,
              gain: float = 0.5, fade_ms: float = 5.0) -> np.ndarray:
    """A sine 'bleep' of exactly n_samples with short cosine fades (no clicks)."""
    if n_samples <= 0:
        return np.zeros(0, dtype=np.float32)
    t = np.arange(n_samples, dtype=np.float32) / sample_rate
    tone = (gain * np.sin(2.0 * np.pi * freq * t)).astype(np.float32)
    fade = min(int(sample_rate * fade_ms / 1000.0), n_samples // 2)
    if fade > 0:
        env = 0.5 * (1.0 - np.cos(np.linspace(0.0, np.pi, fade, dtype=np.float32)))
        tone[:fade] *= env
        tone[-fade:] *= env[::-1]
    return tone


def apply_beep_ranges(samples: np.ndarray, ranges, sample_rate: int,
                      freq: float, gain: float) -> np.ndarray:
    """
    Return a copy of `samples` with every (start, end) local sample range
    replaced by a beep tone. Ranges are clamped to bounds and may overlap.
    """
    if not ranges:
        return samples
    out = samples.copy()
    for a, b in ranges:
        a = max(0, int(a))
        b = min(len(out), int(b))
        if b > a:
            out[a:b] = make_beep(b - a, sample_rate, freq, gain)
    return out


# ═════════════════════════════════════════════════════════════════════════════
# WAV helpers
# ═════════════════════════════════════════════════════════════════════════════

def read_wav_mono(path: str, target_sr: int) -> np.ndarray:
    """
    Load a wav as float32 mono at target_sr. Uses stdlib `wave` + numpy for
    16-bit PCM (no external deps); for anything else it tries soundfile.
    """
    try:
        with wave.open(path, "rb") as w:
            n_ch = w.getnchannels()
            sw = w.getsampwidth()
            sr = w.getframerate()
            raw = w.readframes(w.getnframes())
        if sw == 2:
            data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        elif sw == 4:
            data = np.frombuffer(raw, dtype=np.int32).astype(np.float32) / 2147483648.0
        elif sw == 1:
            data = (np.frombuffer(raw, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
        else:
            raise ValueError(f"unsupported sample width {sw}")
        if n_ch > 1:
            data = data.reshape(-1, n_ch).mean(axis=1)
        if sr != target_sr:
            data = _resample(data, sr, target_sr)
        return data.astype(np.float32)
    except (wave.Error, EOFError):
        import soundfile as sf  # optional, for non-PCM/other formats
        data, sr = sf.read(path, dtype="float32", always_2d=False)
        if data.ndim > 1:
            data = data.mean(axis=1)
        if sr != target_sr:
            data = _resample(data, sr, target_sr)
        return data.astype(np.float32)


def write_wav_mono(path: str, samples: np.ndarray, sample_rate: int) -> None:
    clipped = np.clip(samples, -1.0, 1.0)
    pcm = (clipped * 32767.0).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(pcm.tobytes())


def _resample(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    """One-shot linear resample (whole files). For streams use StreamingResampler."""
    if sr_in == sr_out or x.size == 0:
        return x
    n_out = int(round(x.size * sr_out / sr_in))
    xp = np.linspace(0.0, 1.0, x.size, endpoint=False)
    fp = np.linspace(0.0, 1.0, n_out, endpoint=False)
    return np.interp(fp, xp, x).astype(np.float32)


class StreamingResampler:
    """
    Continuous linear resampler for chunked streams.

    The old per-chunk approach resampled every chunk independently and then
    padded/trimmed it to a fixed length. That loses (or fabricates) a few
    samples at EVERY chunk boundary and creates a small phase discontinuity
    (a click) at each join — over a long capture that's steady, audible
    degradation and cumulative timing drift.

    This class instead treats the input as one endless signal: it keeps the
    unconsumed tail of the previous chunk and a fractional read position, so
    the interpolation grid is perfectly continuous across chunk boundaries.
    No samples are ever dropped or invented; output length per call varies by
    at most one sample and the long-run output/input ratio is exactly
    sr_out/sr_in.
    """

    def __init__(self, sr_in: int, sr_out: int):
        self.sr_in = int(sr_in)
        self.sr_out = int(sr_out)
        self.identity = self.sr_in == self.sr_out
        self._buf = np.zeros(0, dtype=np.float32)  # unconsumed input samples
        self._t = 0.0  # next output position, in input samples, rel. to _buf[0]

    def process(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=np.float32).ravel()
        if self.identity:
            return x
        if x.size:
            self._buf = np.concatenate([self._buf, x]) if self._buf.size else x
        n = self._buf.size
        if n < 2:
            return np.zeros(0, dtype=np.float32)
        step = self.sr_in / self.sr_out
        max_t = n - 1  # last interpolatable position
        if self._t > max_t:
            return np.zeros(0, dtype=np.float32)
        n_out = int(math.floor((max_t - self._t) / step)) + 1
        if n_out <= 0:
            return np.zeros(0, dtype=np.float32)
        t = self._t + step * np.arange(n_out, dtype=np.float64)
        idx = t.astype(np.int64)
        frac = (t - idx).astype(np.float32)
        nxt = np.minimum(idx + 1, n - 1)
        y = self._buf[idx] * (1.0 - frac) + self._buf[nxt] * frac
        # advance and drop fully-consumed input, keeping the fractional tail
        self._t += step * n_out
        drop = min(int(self._t), n - 1)
        self._buf = self._buf[drop:]
        self._t -= drop
        return y.astype(np.float32, copy=False)


class ChunkAssembler:
    """
    Re-slice an arbitrary stream of chunks into EXACT fixed-size segments.

    Capture callbacks and resamplers hand us variable-length pieces; the
    engine's timing math needs every buffered segment to be exactly
    `segment_samples` long. Instead of padding/trimming each piece (which
    loses audio), we accumulate and cut precisely — every input sample ends
    up in exactly one output segment, in order.
    """

    def __init__(self, n: int):
        self.n = int(n)
        self._parts: list[np.ndarray] = []
        self._count = 0

    def push(self, x: np.ndarray) -> list[np.ndarray]:
        x = np.asarray(x, dtype=np.float32).ravel()
        if x.size:
            self._parts.append(x)
            self._count += x.size
        out: list[np.ndarray] = []
        while self._count >= self.n:
            buf = np.concatenate(self._parts) if len(self._parts) > 1 else self._parts[0]
            out.append(buf[: self.n].copy())
            rest = buf[self.n:]
            self._parts = [rest] if rest.size else []
            self._count = int(rest.size)
        return out

    def flush(self) -> np.ndarray | None:
        """Final partial segment, zero-padded to full size (end of stream only)."""
        if self._count == 0:
            return None
        buf = np.concatenate(self._parts) if len(self._parts) > 1 else self._parts[0]
        self._parts, self._count = [], 0
        if buf.size < self.n:
            buf = np.pad(buf, (0, self.n - buf.size))
        return buf[: self.n].astype(np.float32, copy=False)


class SampleFifo:
    """
    Thread-safe float32 sample FIFO — the jitter buffer between the engine's
    playback thread (producer) and the PortAudio output callback (consumer).

    `pull(n)` always returns exactly n samples, zero-filling on underrun and
    reporting how many real samples it had, so the audio callback can never
    block or crash the stream — a late verdict becomes a short silence
    instead of a device stall.
    """

    def __init__(self):
        self._chunks: collections.deque[np.ndarray] = collections.deque()
        self._count = 0
        self._lock = threading.Lock()

    def push(self, x: np.ndarray) -> None:
        x = np.asarray(x, dtype=np.float32).ravel()
        if not x.size:
            return
        with self._lock:
            self._chunks.append(x)
            self._count += x.size

    def pull(self, n: int) -> tuple[np.ndarray, int]:
        out = np.zeros(n, dtype=np.float32)
        got = 0
        with self._lock:
            while got < n and self._chunks:
                head = self._chunks[0]
                take = min(n - got, head.size)
                out[got:got + take] = head[:take]
                got += take
                if take == head.size:
                    self._chunks.popleft()
                else:
                    self._chunks[0] = head[take:]
                self._count -= take
        return out, got

    def sample_count(self) -> int:
        with self._lock:
            return self._count

    def clear(self) -> None:
        with self._lock:
            self._chunks.clear()
            self._count = 0


# ═════════════════════════════════════════════════════════════════════════════
# Input sources — iterators of float32 mono chunks
# ═════════════════════════════════════════════════════════════════════════════

class MicSource:
    """
    Live microphone via sounddevice — CALLBACK based, not blocking reads.

    Why the change: the old blocking `stream.read()` ran on a normal Python
    thread that competes with Whisper transcription for the CPU and the GIL.
    Whenever that thread was scheduled late, PortAudio's small input ring
    buffer overflowed and the driver silently threw microphone samples away
    (the `overflowed` flag was even being discarded). That is exactly the
    "audio missing from the packets before verification" failure: the loss
    happens at capture, before the buffer ever sees the samples.

    Now PortAudio's own high-priority callback thread does the only
    time-critical work — copy the incoming frames into a deque — which takes
    microseconds and is effectively immune to GIL starvation from the
    analysis thread. The Python iterator drains that deque at its leisure,
    runs the continuous StreamingResampler (no per-chunk pad/trim loss, no
    boundary clicks) and cuts exact `segment_samples` segments with
    ChunkAssembler. Every captured sample ends up in exactly one segment.

    Loss is now *observable* instead of silent: `overflows` counts driver
    overflow reports, `dropped_samples` counts anything discarded because the
    safety cap was hit (only possible if the consumer stalls for >30s).

    Most consumer mics/drivers (esp. Windows/Bluetooth) don't really run at
    16 kHz — we still open the stream at the device's native rate and
    resample ourselves so every segment truly spans cfg.segment seconds.
    """

    _QUEUE_CAP_SECONDS = 30.0  # safety valve; never hit in normal operation

    def __init__(self, cfg):
        import sounddevice as sd
        self._sd = sd
        self.cfg = cfg

        try:
            dev_index = sd.default.device[0]  # (input, output)
            info = sd.query_devices(dev_index)
            native_sr = int(round(info.get("default_samplerate") or cfg.sample_rate))
        except Exception:
            native_sr = cfg.sample_rate

        self._native_sr = native_sr
        self._q: collections.deque[np.ndarray] = collections.deque()
        self._q_samples = 0
        self._q_lock = threading.Lock()
        self._data_evt = threading.Event()
        self._cap = int(self._QUEUE_CAP_SECONDS * native_sr)

        # loss visibility (read by the engine's stats line)
        self.overflows = 0        # driver-side input overflows reported
        self.dropped_samples = 0  # samples we had to discard (cap breach)

        def _callback(indata, frames, time_info, status):
            # Runs on PortAudio's realtime thread: keep it tiny & non-blocking.
            if status and getattr(status, "input_overflow", False):
                self.overflows += 1
            mono = indata[:, 0].copy() if indata.ndim > 1 else indata.copy()
            with self._q_lock:
                if self._q_samples + mono.size <= self._cap:
                    self._q.append(mono)
                    self._q_samples += mono.size
                else:
                    self.dropped_samples += mono.size
            self._data_evt.set()

        self.stream = sd.InputStream(
            samplerate=native_sr, channels=cfg.channels,
            blocksize=0,                 # let PortAudio pick its callback size
            dtype="float32",
            latency=getattr(cfg, "input_latency", "high"),
            callback=_callback,
        )

    def __iter__(self):
        resampler = StreamingResampler(self._native_sr, self.cfg.sample_rate)
        assembler = ChunkAssembler(self.cfg.segment_samples)
        self.stream.start()
        try:
            while True:
                self._data_evt.wait(timeout=0.25)
                self._data_evt.clear()
                with self._q_lock:
                    pending = list(self._q)
                    self._q.clear()
                    self._q_samples = 0
                for raw in pending:
                    for seg in assembler.push(resampler.process(raw)):
                        yield seg
        finally:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass


class WavFileSource:
    """
    Read a wav in `segment_samples` chunks. If `realtime` is True, sleeps to
    emulate real-time arrival (so you can watch the delay/beeping behave as it
    would live); if False, yields as fast as possible (fast offline test).
    """
    def __init__(self, cfg, realtime: bool = False):
        self.cfg = cfg
        self.realtime = realtime
        self.audio = read_wav_mono(cfg.input_file, cfg.sample_rate)

    def __iter__(self):
        import time
        n = self.cfg.segment_samples
        for i in range(0, len(self.audio), n):
            chunk = self.audio[i:i + n]
            if len(chunk) < n:  # pad final chunk so segments stay uniform
                chunk = np.pad(chunk, (0, n - len(chunk)))
            if self.realtime:
                time.sleep(self.cfg.segment)
            yield chunk


class StdinPCMSource:
    """
    Read raw float32 little-endian PCM from stdin in fixed chunks. This is the
    generic Auracast / external-pipeline hook: any producer that writes float32
    PCM to stdout feeds the filter with no code change.
    """
    def __init__(self, cfg):
        self.cfg = cfg

    def __iter__(self):
        n = self.cfg.segment_samples
        nbytes = n * 4  # float32
        buf = sys.stdin.buffer
        while True:
            raw = buf.read(nbytes)
            if not raw:
                break
            if len(raw) < nbytes:
                raw = raw + b"\x00" * (nbytes - len(raw))
            yield np.frombuffer(raw, dtype="<f4").astype(np.float32).copy()


def make_source(cfg, realtime_file: bool = False):
    if cfg.input == "mic":
        return MicSource(cfg)
    if cfg.input == "file":
        if not cfg.input_file:
            raise SystemExit("--input file requires --file PATH")
        return WavFileSource(cfg, realtime=realtime_file)
    if cfg.input == "stdin":
        return StdinPCMSource(cfg)
    raise SystemExit(f"unknown input source: {cfg.input}")


# ═════════════════════════════════════════════════════════════════════════════
# Output sink
# ═════════════════════════════════════════════════════════════════════════════

class SpeakerSink:
    """
    Play float32 mono chunks to the default output device — through a JITTER
    BUFFER driven by a PortAudio callback, not blocking writes.

    Why the change: the old blocking `stream.write()` meant the device only
    ever had a couple hundred milliseconds of audio queued. The engine's
    playback thread gated each 1s segment on wall-clock age, so ANY analysis
    verdict arriving late by more than that tiny device buffer drained the
    stream and produced an audible gap — the "plays fine, then stalls a few
    seconds after initialization" symptom (the first speech pass is always
    the slowest one).

    Now `write()` never blocks: it resamples (continuously, no boundary
    clicks) and pushes into a SampleFifo. PortAudio's callback pulls exactly
    what it needs; if the FIFO ever runs dry it emits silence with short
    fade-out/fade-in ramps (no clicks) and counts an underrun instead of
    stalling the stream clock. `queued_seconds()` tells the engine how much
    audio is already scheduled, which lets it queue verdicts EARLY and build
    a cushion that absorbs analysis jitter up to the full broadcast delay.

    Records which physical device it actually opened (name + host API) so the
    caller can show "you should be hearing this on <device>".
    """

    _FADE_MS = 4.0  # ramp length around underrun gaps

    def __init__(self, cfg):
        import sounddevice as sd
        self._sd = sd
        self.cfg = cfg
        try:
            dev_index = sd.default.device[1]  # (input, output)
            info = sd.query_devices(dev_index)
        except Exception:
            dev_index, info = None, {}
        self.device_index = dev_index
        self.device_name = info.get("name", "default output device")
        self.device_samplerate = info.get("default_samplerate")

        # Bluetooth codecs (SBC/AAC/aptX) glitch easily if the driver has to
        # resample AND keep up with a small buffer at the same time — we
        # resample to the device's native rate ourselves and ask PortAudio
        # for a bigger buffer via latency="high".
        self._src_sr = cfg.sample_rate
        self._out_sr = cfg.sample_rate
        if self.device_samplerate and abs(self.device_samplerate - cfg.sample_rate) > 1:
            self._out_sr = int(round(self.device_samplerate))
        self._resample_out = self._out_sr != self._src_sr
        self._resampler = StreamingResampler(self._src_sr, self._out_sr)

        self._fifo = SampleFifo()
        self._fade = max(1, int(self._out_sr * self._FADE_MS / 1000.0))
        self._in_gap = True          # start "in a gap" so first audio fades in
        self.underruns = 0           # times the fifo ran dry mid-stream
        self._started_feeding = False
        self._closing = False

        self._latency = getattr(cfg, "output_latency", "high")
        self._open_stream()

    # ── stream management ────────────────────────────────────────────────────
    def _open_stream(self) -> None:
        def _callback(outdata, frames, time_info, status):
            out, got = self._fifo.pull(frames)
            if got < frames and self._started_feeding and not self._closing:
                if not self._in_gap:
                    self.underruns += 1
                    if got > 0:  # fade out into the gap — no click
                        f = min(self._fade, got)
                        out[got - f:got] *= np.linspace(1.0, 0.0, f, dtype=np.float32)
                self._in_gap = True
            elif got > 0 and self._in_gap:
                f = min(self._fade, got)  # fade back in out of the gap
                out[:f] *= np.linspace(0.0, 1.0, f, dtype=np.float32)
                self._in_gap = False
            outdata[:] = out.reshape(-1, 1).repeat(outdata.shape[1], axis=1)

        self.stream = self._sd.OutputStream(
            samplerate=self._out_sr, channels=self.cfg.channels,
            dtype="float32", latency=self._latency, callback=_callback)
        self.stream.start()

    def write(self, samples: np.ndarray) -> None:
        data = self._resampler.process(samples) if self._resample_out \
            else np.asarray(samples, dtype=np.float32).ravel()
        self._fifo.push(data)
        self._started_feeding = True
        # A Bluetooth device dropping out and reconnecting mid-stream
        # shouldn't take the engine down — if the stream died, reopen it.
        try:
            if not self.stream.active:
                try:
                    self.stream.close()
                except Exception:
                    pass
                self._open_stream()
        except Exception:
            pass

    def queued_seconds(self) -> float:
        """Audio already handed to the device path but not yet played (s)."""
        return self._fifo.sample_count() / float(self._out_sr)

    def describe(self) -> str:
        rate_note = ""
        if self._resample_out:
            rate_note = f" (resampled {self._src_sr}→{self._out_sr} Hz for this device)"
        return f"{self.device_name}{rate_note}"

    def close(self) -> None:
        # let the jitter buffer drain so the tail of the session is heard
        deadline = time.time() + min(self.queued_seconds() + 0.5, 15.0)
        while self._fifo.sample_count() > 0 and time.time() < deadline:
            time.sleep(0.05)
        self._closing = True
        try:
            self.stream.stop()
            self.stream.close()
        except Exception:
            pass


class WavWriterSink:
    """Accumulate played audio and write one censored wav at the end."""
    def __init__(self, cfg):
        self.cfg = cfg
        self._chunks: list[np.ndarray] = []

    def write(self, samples: np.ndarray) -> None:
        self._chunks.append(samples.copy())

    def close(self) -> None:
        if self._chunks and self.cfg.output_file:
            full = np.concatenate(self._chunks)
            write_wav_mono(self.cfg.output_file, full, self.cfg.sample_rate)
            print(f"[output] censored audio written to {self.cfg.output_file} "
                  f"({len(full)/self.cfg.sample_rate:.1f}s)")


class FanoutSink:
    """Write to several sinks at once (e.g. speaker + wav file)."""
    def __init__(self, sinks):
        self.sinks = [s for s in sinks if s is not None]

    def write(self, samples: np.ndarray) -> None:
        for s in self.sinks:
            s.write(samples)

    def queued_seconds(self) -> float:
        """Deepest queue among member sinks (file sinks are instantaneous)."""
        q = 0.0
        for s in self.sinks:
            fn = getattr(s, "queued_seconds", None)
            if fn is not None:
                try:
                    q = max(q, float(fn()))
                except Exception:
                    pass
        return q

    def close(self) -> None:
        for s in self.sinks:
            s.close()


class DebugTapSink:
    """
    Continuously writes exactly what was sent to playback (post-beep) into a
    rolling wav file on disk, so "where can I hear it" has a concrete answer
    that doesn't depend on the live speaker working: open the file afterwards
    and listen to precisely what the filter produced, beeps included.

    Rolls over to a fresh file every `max_seconds` of audio so a long session
    doesn't grow one huge file; keeps the last `keep_files` rollovers.
    """
    def __init__(self, cfg, out_dir: str, max_seconds: float = 120.0, keep_files: int = 3):
        import os as _os
        import glob as _glob
        import time as _time
        self._os, self._glob, self._time = _os, _glob, _time
        self.cfg = cfg
        self.out_dir = out_dir
        self.max_samples = int(max_seconds * cfg.sample_rate)
        self.keep_files = keep_files
        _os.makedirs(out_dir, exist_ok=True)
        self._n = 0
        self._writer: wave.Wave_write | None = None
        self.current_path: str | None = None
        self._rollover()

    def _open_writer(self, path: str) -> "wave.Wave_write":
        w = wave.open(path, "wb")
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(self.cfg.sample_rate)
        return w

    def _rollover(self) -> None:
        if self._writer is not None:
            self._writer.close()
        stamp = self._time.strftime("%Y%m%d-%H%M%S")
        self._file_counter = getattr(self, "_file_counter", 0) + 1
        self.current_path = self._os.path.join(
            self.out_dir, f"live_monitor_{stamp}_{self._file_counter:04d}.wav")
        self._writer = self._open_writer(self.current_path)
        self._n = 0
        old = sorted(self._glob.glob(self._os.path.join(self.out_dir, "live_monitor_*.wav")))
        for p in old[:-self.keep_files]:
            try:
                self._os.remove(p)
            except OSError:
                pass

    def write(self, samples: np.ndarray) -> None:
        clipped = np.clip(samples, -1.0, 1.0)
        pcm = (clipped * 32767.0).astype(np.int16)
        self._writer.writeframes(pcm.tobytes())
        self._n += len(samples)
        if self._n >= self.max_samples:
            self._rollover()

    def close(self) -> None:
        if self._writer is not None:
            self._writer.close()
            self._writer = None
