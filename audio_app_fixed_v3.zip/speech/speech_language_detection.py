import whisper

LANG_MAP = {
    "en": "English",
    "fr": "French",
    "de": "German",
    "hi": "Hindi",
    "kn": "Kannada",
    "ko": "Korean",
    "ml": "Malayalam",
    "es": "Spanish",
    "ta": "Tamil",
    "te": "Telugu",
    "ur": "Urdu"
}

print("Loading Whisper Small...")
model = whisper.load_model("small")
print("Model Loaded\n")

while True:

    audio_path = input(
        "Enter audio path (or q to quit): "
    ).strip()

    if audio_path.lower() == "q":
        break

    audio = whisper.load_audio(audio_path)
    audio = whisper.pad_or_trim(audio)

    mel = whisper.log_mel_spectrogram(audio).to(model.device)

    _, probs = model.detect_language(mel)

    language = max(
        probs,
        key=probs.get
    )

    print(
        "\nPrediction:",
        LANG_MAP.get(
            language,
            language
        )
    )
