Put your two trained files here:

  svm_model.pkl
  scaler.pkl

audio_pipeline.py now loads them from this folder:
  MODEL_PATH  = os.path.join(os.path.dirname(__file__), "models", "svm_model.pkl")
  SCALER_PATH = os.path.join(os.path.dirname(__file__), "models", "scaler.pkl")

(These are your existing trained model files — just move/copy them here,
no need to retrain.)
