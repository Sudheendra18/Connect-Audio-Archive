"""Local on-device persistence (Flet 0.85.3 — uses SharedPreferences control)."""
import flet as ft
from models import AppState

HISTORY_KEY    = "analysis_history"
THEME_KEY      = "dark_mode"
BACKEND_URL_KEY = "backend_url"

_prefs: ft.SharedPreferences | None = None


def get_prefs(page: ft.Page) -> ft.SharedPreferences:
    """Get (or lazily create + register) the single SharedPreferences control.

    SharedPreferences is a Control in 0.85.3 — it takes no constructor args
    and must be mounted on the page (like FilePicker/AudioRecorder) before
    its async methods can be used.
    """
    global _prefs
    if _prefs is None:
        _prefs = ft.SharedPreferences()
        page.overlay.append(_prefs)
    return _prefs


async def load_state(page: ft.Page, state: AppState) -> None:
    prefs = get_prefs(page)

    history_json = await prefs.get(HISTORY_KEY)
    if isinstance(history_json, str):
        state.history = state.history_from_json(history_json)

    dark = await prefs.get(THEME_KEY)
    state.dark_mode = bool(dark) if dark is not None else True   # default dark

    backend_url = await prefs.get(BACKEND_URL_KEY)
    if isinstance(backend_url, str) and backend_url:
        state.backend_url = backend_url


async def save_history(page: ft.Page, state: AppState) -> None:
    prefs = get_prefs(page)
    await prefs.set(HISTORY_KEY, state.history_to_json())


async def save_theme(page: ft.Page, state: AppState) -> None:
    prefs = get_prefs(page)
    await prefs.set(THEME_KEY, state.dark_mode)


async def save_backend_url(page: ft.Page, state: AppState) -> None:
    prefs = get_prefs(page)
    await prefs.set(BACKEND_URL_KEY, state.backend_url)


async def clear_history(page: ft.Page, state: AppState) -> None:
    state.history = []
    prefs = get_prefs(page)
    await prefs.remove(HISTORY_KEY)
