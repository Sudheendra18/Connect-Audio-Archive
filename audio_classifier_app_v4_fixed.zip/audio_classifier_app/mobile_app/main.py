"""Audio Classifier — app entry point (Flet 0.85.3 compatible)."""
import flet as ft
from flet_audio_recorder import AudioRecorder

from models import AppState
import storage as storage_mod
import theme as th
from screens import home, upload, record, result, history, analytics, settings, about


def main(page: ft.Page):
    page.title = "Audio Classifier"
    page.theme = th.make_theme()
    page.dark_theme = th.make_theme()
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = th.SURFACE_0
    page.padding = 0

    state = AppState()

    file_picker = ft.FilePicker()
    audio_recorder = AudioRecorder()
    page.overlay.extend([file_picker, audio_recorder])

    def route_change(e: ft.RouteChangeEvent):
        page.views.clear()
        route = page.route

        if route == "/upload":
            page.views.append(upload.build_view(page, state, file_picker))
        elif route == "/record":
            page.views.append(record.build_view(page, state, audio_recorder))
        elif route == "/result":
            page.views.append(result.build_view(page, state))
        elif route == "/history":
            page.views.append(history.build_view(page, state))
        elif route == "/analytics":
            page.views.append(analytics.build_view(page, state))
        elif route == "/settings":
            page.views.append(settings.build_view(page, state))
        elif route == "/about":
            page.views.append(about.build_view(page, state))
        else:
            page.views.append(home.build_view(page, state))

        page.update()

    def view_pop(e: ft.ViewPopEvent):
        page.views.pop()
        top_view = page.views[-1]
        page.push_route(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop

    async def boot():
        await storage_mod.load_state(page, state)
        page.theme_mode = ft.ThemeMode.DARK if state.dark_mode else ft.ThemeMode.LIGHT
        # Use push_route instead of deprecated go() for 0.85+
        page.push_route(page.route if page.route and page.route != "/" else "/")

    page.run_task(boot)


if __name__ == "__main__":
    ft.run(main)
